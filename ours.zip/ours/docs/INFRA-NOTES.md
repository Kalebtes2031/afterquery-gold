# INFRA NOTES

## CURRENT POC1 INFRA

This is a simple infrastrucutre which should be able to handle the current POC1 requirements.
The DB is on RDS and chat services is on IVS which hopefully should offload the most difficult pieces to the AWS platform
instead of hosting ourselves.

System:

- AWS RDS PG 17
- AWS IVS Chat
- AWS Redis
- Plain EC2 instance behind a AWS ALB with SSL

## OPTIMIZATIONS: STAGE 2

- Add another RDS replica
- Add another Redis replica
- Add another EC2 instance behind the ALB

## OPTIMIZATIONS: STAGE 3

- Move from EC2 to ECS
- Add setup scripts to Teraform

## OPTIMIZATIONS: STAGE 4

- Add auto deploy from CI/CD pipeline.  Can be done from Github Actions.

## OPTIMIZATIONS: STAGE 5

- If traffic gets realy big, might need to move to K8S/EKS.
