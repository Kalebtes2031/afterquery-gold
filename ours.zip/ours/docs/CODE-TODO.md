# TODO

## ACCESSIBLITY

- The entire app needs a comprehensive accessibility audit.
  - Tools like Lighthouse, Axe are better than nothing, but ideally it's good to do a real a11y check
    from a user who is visually impaired using actual screen reader software.  This can sometimes be done
    inhouse or there are also agencies who can help with this.

## LOGGING AND ERROR HANDLING

- Unified logging system.  Look into Sentry.
- Catchall error handling in a backend middleware.

## TESTS

See [TESTS-TODO.md](./TESTS-TODO.md) for more details.

## API VALIDATION

- Schema validation for API interactions between frontend and backend.
  - Either Zod or Typebox could be good.
    - Zod is probably easier to work with and has better community support.
    - Typebox is faster and supports not TS consumers.

## IVS INTEGRATION

- Schema validation for IVS interactions
  - Not sure if needed, but worth researching.
  - Maybe Typebox or AJV

## GENERAL AUTH

- Eventualy need to move to a robust auth solution.  Clerk or Auth0 could be good idea.

## KNOWN BUGS

- <https://linear.app/flourid/issue/OUR-198/poc1-chat-qa-testing> @ QA18

## SYSTEM DESIGN OPTIMIZATIONS

- The chat history is currently being pulled from Redis.  This is fine for POC1, but we will want to see if this can
  be moved to IVS.  This might mean reconciling chat ids to pull history.  This would also require to make sure reactions
  are working with those past messages.

## BACKEND CODE OPTIMIZATIONS

- `ivs_chat_client.ts`:
  - Can possibly remove most of the try/catch blocks and just let errors pass through.

## FRONTEND CODE OPTIMIZATIONS

- `ChatInputRenderer.tsx`:
  - `renderContent()` optimizations:
    - Move some string handling into external
    - Decouple logic from rendering
    - Make functional style
- `ChatMessage.tsx`
  - `processTextContent()` optimizations:
    - Move some string handling into external
    - Decouple logic from rendering
    - Make functional style
- `EmojiPopover.tsx`:
  - `getCurrentEmojis()` can be decoupled from rendering.
- `GifPicker.tsx`:
  - `handleItemClick()` can be decoupled from rendering.
- `NicknameEntry.tsx`:
  - `isValidNickname()` can be decoupled from rendering.
- `useChat.ts`:
  - `useChat()`:
    - Each function in here can be decoupled out of hook and some moved into smaller files.
    - Token handling and session management can be decoupled from rendering.
- `ApiService.ts`:
  - If wanted, can replace axios with fetch. Opinions differ on this.
