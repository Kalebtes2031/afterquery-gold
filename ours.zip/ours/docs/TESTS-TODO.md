# TESTS TODO

## PHASE 1: E2E TESTS

Stack:

- Playwright
- Artillery
- GH Actions

Tests:
Both desktop and mobile:

- Render Homepage (`/`)
- Render app (`/stream/demo`)
  - Play video
  - Render chat
    - Can register handle
    - Can see past messages
    - Can post message with text
    - Can post message with gif
    - Can post message with emote
    - Can add reaction to message
    - Can see reactions incrementing
    - Can see messages updating in realtime
    - Can submit message with keyboard
    - Can submit message with mouse
    - Can click `scroll to bottom`

## PHASE 2: LOAD TESTS

Stack:

- Artillery

Tests:

- Homepage load (`/`)
  - Page: 5k page views per 1 minute
- App load (`/stream/demo`)
  - Page: 5k page views per 1 minute
  - Chat: Post 5k messages per 1 minute
  - Chat: Add 5k reactions per 1 minute
  - Chat: See 5k messages per 1 minute
  - Chat: Add 5k reactions per 1 minute
  - Chat: See 5k reactions per 1 minute
  - Chat: 1k concurrent chat users all posting within 1 minute

## PHASE 3: ENDPOINT TESTS

For each endpoint:

- Each error condition
- Each success condition

Stack:

- Artillery
- GH Actions
- Jest

Tests:

- Auth
  - `POST /auth/login`
  - `GET /auth/profile`
- Channels
  - `GET /channels/:channelId/users`
- Chat
  - `POST /chat/connect-registered`
  - `POST /chat/connect-temporary`
  - `POST /chat/connect-readonly`
  - `POST /chat/leave`
  - `POST /chat/activity`
- Index
  - `GET /index`
- Messages
  - `GET /messages/:channelId`
  - `POST /messages`
- Nicknames
  - `GET /nicknames/:nickname`
  - `POST /nicknames`
  - `DELETE /nicknames/:nickname`
- Rooms
  - `GET /rooms/:roomId`
  - `POST /rooms`
  - `DELETE /rooms/:roomId`

## PHASE 4: FRONTEND UNIT TESTS

Stack:

- Vitest
- GH Actions

Tests:

- `components/organisms/ActiveChatBoxRefactored.tsx`
  - GIF/Emote parsing and handling
  - Message input handling
  - Message submission handling
- `components/organisms/ChatInterface.tsx`
  - Message reaction handling
  - Message submission handling
- `components/organisms/LiveChatCard.tsx`
  - GIF/Emote parsing and handling
  - Message input handling
  - Message submission handling

## PHASE 5: ACCESSIBILITY TESTS

Stack:

- Lighthouse
- GH Actions

Tests:

- Homepage (`/`)
- App (`/stream/demo`)
