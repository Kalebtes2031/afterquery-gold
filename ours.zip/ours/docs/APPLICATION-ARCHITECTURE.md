# OURS — Application Architecture

This document explains how the OURS platform is structured and how major parts interact at runtime. It covers the monorepo layout, runtime data flow, key services, storage, and configuration used in local development and production.

## 1) High‑Level Overview

- React 19 SPA connects directly to Amazon IVS Chat over WebSocket for real‑time chat and events.
- An Express.js backend issues IVS Chat tokens, manages user sessions, exposes REST APIs, and mirrors real‑time signals to persistent/ephemeral stores.
- Redis provides fast, ephemeral state (sessions, recent messages, reaction indices).
- PostgreSQL (via Sequelize) persists registered users, rooms, and owner mappings.
- Shared package holds cross‑package types/utilities (currently minimal).

```mermaid
flowchart LR
  subgraph Client[Browser: React 19]
    UI[UI (Pages/Templates/Organisms)]
    Hook[useChat + Contexts]
    Svc[Services: ApiService/Auth/IvsChat]
  end

  subgraph Backend[Express.js]
    API[/REST: /api/chat, /api/rooms, /api/messages, /api/auth/]
    IVS[IVS Chat SDK client]
  end

  subgraph Data[State & Persistence]
    R[(Redis)]
    PG[(PostgreSQL)]
  end

  UI --> Hook --> Svc --> API
  Svc -. WebSocket (token) .-> IVS
  API --> IVS
  API <--> R
  API <--> PG
```

## 2) Monorepo Layout

- `packages/frontend/` — React 19 + Vite, Tailwind, React Router 7, Playwright.
- `packages/backend/` — Express.js + AWS IVS Chat SDK + Sequelize (Postgres) + Redis.
- `packages/shared/` — Shared types (currently stubbed).

Root TypeScript project references link all three workspaces. Path aliases (resolved by Vite/TSConfig) use `#ours/*` and all imports include file extensions.

## 3) Frontend Architecture

Key technologies: React 19, TypeScript, Vite, Tailwind, React Router 7, @tanstack/react-query.

- Atomic design directories: `components/atoms`, `molecules`, `organisms`, `templates`, `pages`.
- Contexts/Hooks:
  - `ChatContext` + `useChat` orchestrate connection state, messages, events, and user/session lifecycles.
  - `useChatEventHandlers` centralizes IVS message/event handling and reaction aggregation in memory.
- Services:
  - `ApiService` (Axios) adds `Authorization` header from `sessionStorage` and exposes typed `get/post/...` helpers.
  - `AuthService` calls backend `POST /api/chat/connect-*` endpoints to obtain IVS WebSocket tokens and room metadata; caches token expiry locally.
  - `IVSChatService` opens a WebSocket to IVS Chat using the token as subprotocol; emits `message`, `event`, and `connectionStatusChange` through a lightweight `EventEmitter`.
  - `MessagesService` loads and stores recent messages via backend REST (Redis‑backed).
  - `ReactionService` (frontend) delegates reaction toggles/queries to backend endpoints.
- Routing: `App.tsx` wires routes like `/`, `/home`, `/stream/:streamId`, `/performer` and wraps with `KeyboardProvider`, `StreamProvider`, and `ChatProvider`.

Frontend architecture details live in `packages/frontend/ARCHITECTURE.md` and are aligned with this document.

## 4) Backend Architecture

Express app (`src/app.ts`) initializes on startup:

- Loads configuration and middleware (JSON, URL‑encoded, cookies, static files, `morgan`).
- Boots database (`initializeDatabase`), seeds sample data in development, and starts a cleanup service.
- Mounts routers under `/api/*`:
  - `/api/chat` — connect registered/temporary/read‑only users, leave, and heartbeat.
  - `/api/rooms` — room metadata, reaction toggle/queries, IVS event webhook and server‑side event dispatch.
  - `/api/messages` — store + fetch recent messages (Redis list per channel).
  - `/api/auth` — demo login + protected profile (JWT via `jose`, `requireAuth`).

### 4.1 IVS Chat Integration

- `services/ivs_chat_client.ts` wraps `@aws-sdk/client-ivschat` and provides:
  - `createChatToken` with attributes (nickname, userType, channelRole, chatUserId, isRegistered) and configured capabilities (e.g., SEND_MESSAGE, DELETE_MESSAGE, DISCONNECT_USER for owners/moderators/admins).
  - `sendEvent` for server‑emitted IVS events (e.g., reactions broadcast to all connected clients).
  - Room helpers and credential validation.

### 4.2 Session & Ephemeral State (Redis)

- `session/redis.ts` centralizes a Redis client.
- `session/operations/*` manages:
  - Users: availability, channel membership, activity heartbeat.
  - Messages: capped, TTL’d per‑channel lists for fast recent‑history fetch.
  - Reactions: per‑message/user indices, recent room activity, and counts.

### 4.3 Persistence (PostgreSQL via Sequelize)

- Models: `User` (registered users), `Room`, `RoomOwner`, `Reaction` (available), with migrations via `sequelize.sync` in dev.
- Current runtime paths use Postgres for registered users, rooms, and room ownership; reactions are presently handled in Redis for speed. A database implementation for reactions exists but is not wired by default.

## 5) Real‑Time Data Flow

### 5.1 Join Chat (Temporary User)

```mermaid
sequenceDiagram
  participant UI as Frontend
  participant API as Backend /api/chat
  participant IVS as Amazon IVS Chat

  UI->>API: POST /api/chat/connect-temporary {nickname, channelId}
  API->>IVS: CreateChatToken(capabilities=[SEND_MESSAGE])
  API-->>UI: {token, endpoint, roomId, user}
  UI->>IVS: WebSocket connect (subprotocol = token)
  IVS-->>UI: Messages/Events stream
```

### 5.2 Anonymous Read‑Only Join

```mermaid
sequenceDiagram
  UI->>API: POST /api/chat/connect-readonly {channelId}
  API->>IVS: CreateChatToken(capabilities=[])
  API-->>UI: {token, endpoint}
  UI->>IVS: WebSocket connect (receive‑only)
```

### 5.3 Send Message + Store Recent History

```mermaid
sequenceDiagram
  UI->>IVS: SEND_MESSAGE over WebSocket
  IVS-->>UI: MESSAGE (fan‑out)
  UI->>API: POST /api/messages (store recent)
  API->>Redis: LPUSH + LTRIM (TTL 24h)
```

### 5.4 Toggle Reaction (Hybrid: Redis + IVS Events)

```mermaid
sequenceDiagram
  UI->>API: POST /api/rooms/:roomId/messages/:messageId/reactions {userId,reaction}
  API->>Redis: add/remove reaction, recompute counts
  API->>IVS: sendEvent("reaction", {type, messageId, userId, reaction})
  IVS-->>All UIs: EVENT reaction (fan‑out)
  UI: updates local message reaction aggregates
```

Notes:

- Backend also exposes queries for per‑message and recent room reactions.
- A Postgres implementation for reaction persistence exists but is not enabled by default; Redis path is used at runtime for low‑latency fan‑out and aggregation.

## 6) Storage Model

- Redis
  - `channel:{id}:messages` — capped recent message list per channel (TTL 24h).
  - Reaction indices/sets and sorted sets for quick counts and recent activity.
  - User session map and channel membership sets for presence.
- PostgreSQL (via Sequelize)
  - `registered_users` — registered accounts, roles, tokens, activity.
  - `rooms` — logical roomId → IVS room ARN mapping.
  - `room_owners` — ownership mapping for elevated IVS token capabilities.
  - `reactions` — table and ops available; optional when Redis is primary.

## 7) API Surface (Selected)

- Chat
  - `POST /api/chat/connect-temporary`
  - `POST /api/chat/connect-readonly`
  - `POST /api/chat/connect-registered` (JWT required)
  - `POST /api/chat/leave`, `POST /api/chat/activity`
- Messages
  - `GET /api/messages/:channelId`
  - `POST /api/messages`
- Rooms/Reactions
  - `POST /api/rooms/:roomId/messages/:messageId/reactions`
  - `GET /api/rooms/:roomId/messages/:messageId/reactions?userId=...`
  - `GET /api/rooms/:roomId/reactions?limit=50`
  - `POST /api/rooms/:roomId/events` (server‑side IVS event)

## 8) Configuration

Environment variables (see `.env.example`):

- IVS: `IVS_AWS_REGION`, `IVS_AWS_ACCESS_KEY_ID`, `IVS_AWS_SECRET_ACCESS_KEY`
- JWT: `JWT_SECRET`
- Redis: `REDIS_URL`
- Postgres: `DATABASE_URL`
- Backend host/port: `HOST`, `PORT`
- Frontend to backend: `VITE_REACT_APP_API_HOST` (and `VITE_API_URL`)

Local development provides `docker-compose.yml` for Postgres 17 and Redis.

## 9) Build, Tooling, and Conventions

- TypeScript monorepo with project references; strict compiler options across packages.
- Vite aliases:
  - `#ours/frontend/*` → `packages/frontend/src/*`
  - `#ours/backend/*` → `packages/backend/src/*`
  - `#ours/shared/*` → `packages/shared/src/*`
- Biome for lint/format. Filenames are underscore_case by convention; imports include file extensions.

## 10) Deployment Model

- Frontend builds to static assets suitable for CDN/edge delivery.
- Backend runs as a Node process behind an HTTP gateway with access to Redis, Postgres, and AWS IVS.
- Production requires valid AWS credentials and a Redis instance; Postgres is required for registered user/room persistence.

## 11) Related Docs

- Frontend specifics: `packages/frontend/ARCHITECTURE.md`
- Reaction system background: `packages/backend/REACTION_SYSTEM.md` (conceptual; the live path currently favors Redis for reactions).

## 12) Key Design Decisions

- Use IVS Chat for real‑time fan‑out; avoid running our own WebSocket server.
- Keep hot data (sessions, recent messages, reaction counters) in Redis for speed and simplicity.
- Persist identity/ownership in Postgres; maintain a DB path for reactions but keep it optional.
- Token issuance and capability control stay server‑side; clients never hold AWS credentials.
