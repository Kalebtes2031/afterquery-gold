# User Management Strategy for Live Chat

This document outlines the implementation strategy for user identification and state management in a live chat system using Amazon IVS Chat and Redis.

## User Identification

### Temporary Nicknames System

#### 1. Nickname Registration Flow
```
User Request → Nickname Validation → Token Generation → IVS Chat Token → Chat Access
```

**Steps:**
1. **Client requests nickname**: User submits desired nickname through frontend
2. **Server validation**: Check nickname availability against Redis cache and reserved list
3. **Temporary registration**: Store user session in Redis with TTL (Time To Live)
4. **IVS token generation**: Create Amazon IVS Chat token with user metadata
5. **Chat access granted**: User joins chat with temporary identity

#### 2. Nickname Availability Logic
```javascript
// Pseudo-code for nickname validation
async function validateNickname(requestedName) {
  // Check if nickname is reserved (admins/channel owners)
  if (await isReservedNickname(requestedName)) {
    return { available: false, reason: 'reserved' };
  }
  
  // Check if currently in use
  if (await redis.exists(`user:${requestedName}`)) {
    return { available: false, reason: 'in_use' };
  }
  
  return { available: true };
}
```

#### 3. Reserved Users (Admins/Channel Owners)
- **Database storage**: Maintain list of protected nicknames
- **Authentication required**: Simple token/password verification
- **Special privileges**: Moderation powers, permanent presence
- **Visual distinction**: Badges, colors, or special formatting

### Amazon IVS Chat Integration

#### 1. Token Generation Strategy
```javascript
// IVS Chat token with user metadata
const chatToken = await ivs.createChatToken({
  roomIdentifier: channelId,
  userId: temporaryUserId, // Generate unique ID
  capabilities: ['SEND_MESSAGE', 'DISCONNECT_USER'], // Based on user type
  attributes: {
    nickname: validatedNickname,
    userType: 'temporary', // or 'admin'
    joinedAt: Date.now(),
    sessionId: generateSessionId()
  },
  sessionDurationInMinutes: 60 // Auto-expire tokens
});
```

#### 2. Session Management with IVS
- **Token-based sessions**: IVS handles connection state
- **Metadata in attributes**: Store user info in token attributes
- **Auto-expiration**: Tokens expire automatically, forcing re-authentication
- **Reconnection handling**: Generate new tokens for returning users

## State Management

### Production Environment (Redis)

#### 1. User Session Storage

##### Data Structure
```javascript
// Redis key pattern: user:{nickname}
const userSession = {
  sessionId: 'unique-session-id',
  nickname: 'user_nickname',
  userType: 'temporary', // or 'admin'
  channelId: 'stream-channel-id',
  joinedAt: timestamp,
  lastActivity: timestamp,
  chatUserId: 'ivs-generated-user-id',
  connectionStatus: 'active' // 'active', 'idle', 'disconnected'
};
```

##### Redis Operations
```javascript
// Store user session with TTL (30 minutes)
await redis.setex(`user:${nickname}`, 1800, JSON.stringify(userSession));

// Update last activity
await redis.hset(`user:${nickname}`, 'lastActivity', Date.now());

// Check if user exists
const exists = await redis.exists(`user:${nickname}`);
```

#### 2. Channel State Management

##### Active Users Tracking
```javascript
// Redis key pattern: channel:{channelId}:users
// Use Redis Sets for active users per channel
await redis.sadd(`channel:${channelId}:users`, nickname);
await redis.expire(`channel:${channelId}:users`, 3600);

// Get all active users in channel
const activeUsers = await redis.smembers(`channel:${channelId}:users`);
```

##### User Count Tracking
```javascript
// Real-time user count per channel
await redis.incr(`channel:${channelId}:count`);
await redis.expire(`channel:${channelId}:count`, 3600);
```

#### 3. Cleanup and Maintenance

##### Automatic Session Cleanup
```javascript
// Background job to clean expired sessions
async function cleanupExpiredSessions() {
  const pattern = 'user:*';
  const keys = await redis.keys(pattern);
  
  for (const key of keys) {
    const ttl = await redis.ttl(key);
    if (ttl === -1) { // Key exists but no TTL set
      await redis.expire(key, 1800); // Set default TTL
    }
  }
}

// Run cleanup every 5 minutes
setInterval(cleanupExpiredSessions, 300000);
```

##### Inactive User Detection
```javascript
async function removeInactiveUsers() {
  const allUsers = await redis.keys('user:*');
  const now = Date.now();
  const inactivityThreshold = 30 * 60 * 1000; // 30 minutes
  
  for (const userKey of allUsers) {
    const userData = await redis.get(userKey);
    const user = JSON.parse(userData);
    
    if (now - user.lastActivity > inactivityThreshold) {
      await removeUserFromChat(user.nickname, user.channelId);
    }
  }
}
```

### Localhost Development Environment (In-Memory Storage)

For local development without Redis infrastructure, implement an in-memory storage fallback:

#### 1. Memory Store Implementation
```javascript
// In-memory store for localhost development
class LocalMemoryStore {
  constructor() {
    this.users = new Map();
    this.channels = new Map();
    this.cleanupInterval = null;
    this.startCleanup();
  }

  // User session methods
  async setUser(nickname, userData, ttlSeconds = 1800) {
    const expiresAt = Date.now() + (ttlSeconds * 1000);
    this.users.set(nickname, { ...userData, expiresAt });
    return 'OK';
  }

  async getUser(nickname) {
    const userData = this.users.get(nickname);
    if (!userData) return null;
    
    if (Date.now() > userData.expiresAt) {
      this.users.delete(nickname);
      return null;
    }
    
    return userData;
  }

  async userExists(nickname) {
    const userData = await this.getUser(nickname);
    return userData !== null;
  }

  async deleteUser(nickname) {
    return this.users.delete(nickname);
  }

  // Channel methods
  async addUserToChannel(channelId, nickname) {
    if (!this.channels.has(channelId)) {
      this.channels.set(channelId, new Set());
    }
    this.channels.get(channelId).add(nickname);
  }

  async removeUserFromChannel(channelId, nickname) {
    if (this.channels.has(channelId)) {
      this.channels.get(channelId).delete(nickname);
    }
  }

  async getChannelUsers(channelId) {
    return this.channels.has(channelId) 
      ? Array.from(this.channels.get(channelId))
      : [];
  }

  // Cleanup expired entries
  startCleanup() {
    this.cleanupInterval = setInterval(() => {
      const now = Date.now();
      for (const [nickname, userData] of this.users.entries()) {
        if (now > userData.expiresAt) {
          this.users.delete(nickname);
          // Remove from all channels
          for (const [channelId, users] of this.channels.entries()) {
            users.delete(nickname);
          }
        }
      }
    }, 60000); // Cleanup every minute
  }

  destroy() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
  }
}
```

#### 2. Environment-based Store Selection
```javascript
// Store factory based on environment
function createStore() {
  if (process.env.NODE_ENV === 'development' && !process.env.REDIS_URL) {
    console.log('Using in-memory store for localhost development');
    return new LocalMemoryStore();
  } else {
    console.log('Using Redis store for production');
    return new RedisStore();
  }
}

// Usage in application
const store = createStore();

// Unified interface for both stores
async function validateNickname(requestedName) {
  if (await isReservedNickname(requestedName)) {
    return { available: false, reason: 'reserved' };
  }
  
  if (await store.userExists(requestedName)) {
    return { available: false, reason: 'in_use' };
  }
  
  return { available: true };
}
```

#### 3. Development Configuration
```javascript
// Environment detection and configuration
const config = {
  development: {
    useMemoryStore: !process.env.REDIS_URL,
    sessionTTL: 1800, // 30 minutes
    cleanupInterval: 60000, // 1 minute
    maxUsersPerChannel: 100
  },
  production: {
    useMemoryStore: false,
    redisUrl: process.env.REDIS_URL,
    sessionTTL: 1800,
    cleanupInterval: 300000, // 5 minutes
    maxUsersPerChannel: 1000
  }
};
```

#### 4. Development Benefits
- **No external dependencies**: Run immediately without Redis setup
- **Faster development**: No network latency for local operations
- **Easy debugging**: Direct access to in-memory data structures
- **Consistent API**: Same interface as Redis implementation
- **Automatic cleanup**: Built-in expiration and garbage collection

## Implementation Flow

### 1. User Join Process
1. **Frontend**: User enters nickname and channel
2. **Backend**: Validate nickname availability
3. **Store**: Save temporary user session (Redis or Memory)
4. **IVS**: Generate chat token with user metadata
5. **Frontend**: Connect to IVS Chat with token
6. **Backend**: Add user to channel's active users set

### 2. User Activity Tracking
1. **IVS Events**: Listen for message and connection events
2. **Store Update**: Update lastActivity timestamp
3. **Heartbeat**: Optional periodic activity updates
4. **Cleanup**: Remove inactive users automatically

### 3. User Disconnect Process
1. **IVS Event**: Detect user disconnect
2. **Store**: Remove user session and channel membership
3. **Cleanup**: Make nickname available for reuse
4. **Notification**: Optional disconnect notification to other users

## Error Handling and Edge Cases

### Nickname Conflicts
- **Race conditions**: Use atomic operations (Redis) or synchronous checks (Memory)
- **Reconnection scenarios**: Allow same user to reclaim nickname within grace period
- **Suggestion system**: Provide alternative nicknames when conflicts occur

### Network Issues
- **Reconnection grace period**: Hold nickname for 2-3 minutes after disconnect
- **Token refresh**: Handle expired tokens gracefully
- **State synchronization**: Reconcile store state with IVS connection state

### Scaling Considerations
- **Production**: Redis clustering for distributed load
- **Development**: Memory store limitations for single instance only
- **Connection pooling**: Manage store connections efficiently
- **Rate limiting**: Prevent abuse of nickname registration
- **Monitoring**: Track user counts, connection patterns, and system health

## Security Considerations

### Anti-Abuse Measures
- **Rate limiting**: Limit nickname changes per IP/session
- **Profanity filtering**: Validate nicknames against inappropriate content
- **Reserved words**: Prevent use of system/admin terms
- **Length limits**: Enforce reasonable nickname length constraints

### Data Privacy
- **Minimal data storage**: Only store necessary session information
- **Automatic cleanup**: Ensure user data is removed after sessions expire
- **No persistent tracking**: Avoid storing user behavior across sessions

This strategy provides a robust foundation for managing temporary users while maintaining flexibility for channel owners and administrators, with support for both production Redis deployments and localhost development environments.