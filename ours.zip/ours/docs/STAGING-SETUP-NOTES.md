# STAGING SETUP NOTES

## PM2

Install:

```shell
sudo npm install -g pm2
```

Startup:

```shell
pm2 start npm --name "ours-backend" -- run start
pm2 startup
pm2 save
```

## NGINX

Config:

```nginx
server {
  listen 0.0.0.0:80;
  server_name ours-preview.ours.space;

  location /api/ {
    proxy_pass http://localhost:4000;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_cache_bypass $http_upgrade;
  }

  location /assets/ {
    alias /var/www/ours/packages/frontend/dist/assets/;
  }

  location / {
    root /var/www/ours/packages/frontend/dist/;
    index index.html;
    try_files $uri $uri/ /index.html;
  }
}
```
