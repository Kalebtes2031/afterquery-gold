# Guidelines for Developers When Using AI Code Agents

1. In the prompt, start with the goal of the task first, then explain the details. The leading tokens are the most impactful.
2. Don’t pre-emptively put items in the `AGENTS.md`/`CLAUDE.md` files. Wait until problems surface, then add them to the file.
3. Be aware of overly defensive coding by agents. They are notorious for this, and it creates buggy code.
4. Never leave important architecture decisions only to the AI. It can be an assistant, but it should not make those decisions for you.
5. Review and understand 100% of all AI code that you push. If it writes code you don’t understand, take the time to learn and understand it.
6. Ask the team before cutting corners. Don’t assume which corners are acceptable to cut.
7. Don’t add new package dependencies without a very good reason. Don’t let the AI add dependencies you didn’t ask for.
8. These AI agents/models are recommended.  Sometimes it's good to use both at same time:
   - Codex CLI / gpt-5-codex-high
   - Claude Code CLI / sonnet-4.5
9. Do not use these AI agents:
   - Gemini
   - Cursor Agent
