/**
 * Allowed:
 *
 * - `\p{L}`: Letters any language
 * - `\p{N}`: Numbers any language
 * - `\p{M}`: Combining marks
 * - `\u002E`: Dot
 * - `\u005F`: Underscore
 * - `\u002D`: Hyphen
 * - 3-24 characters
 */
export const isValidNickname = (nickname: string) => {
  const patt = /^[\p{L}\p{M}\p{N}\u002E\u005F\u002D]{3,24}$/u;
  const normalizedNickname = nickname.normalize("NFC");
  const isValid = patt.test(normalizedNickname);
  return isValid;
};

export const invalidNicknameMessage =
  "Invalid nickname.  Nickname must be 3-24 characters. " +
  "Allowed characters are: Letters, numbers, hyphen, period, and underscore.";
