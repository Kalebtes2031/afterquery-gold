import type { Locator, Page } from "@playwright/test";
import { expect, test } from "@playwright/test";
import { getEnvVar } from "#ours/e2e/config_utils.ts";

const youtubeVideoId = getEnvVar("E2E_YT_VIDEO_ID");
const clerkEmail = getEnvVar("E2E_CLERK_EMAIL");
const clerkPassword = getEnvVar("E2E_CLERK_PASSWORD");

const signIn = async (page: Page) => {
  await page.getByPlaceholder("Enter your email address").fill(clerkEmail);
  await page.getByRole("button", { name: "Continue", exact: true }).click();
  await page.getByPlaceholder("Enter your password").fill(clerkPassword);
  await page.getByRole("button", { name: "Continue", exact: true }).click();
};

const openMyStreamsPage = async (page: Page) => {
  await expect(page).toHaveURL(/\/my-streams/);
  await expect(page.getByRole("heading", { name: /my streams/i })).toBeVisible({ timeout: 60000 });
};

const createStream = async (page: Page, title: string, streamSlug: string) => {
  const titleInput = page.getByLabel("Stream Title");
  await expect(titleInput).toBeVisible({ timeout: 60000 });
  await titleInput.fill(title);
  const slugInput = page.getByLabel("Stream Name (URL)");
  await expect(slugInput).toBeVisible({ timeout: 60000 });
  await slugInput.fill(streamSlug);
  const streamTypeSelect = page.getByLabel("Stream Type");
  await expect(streamTypeSelect).toBeVisible({ timeout: 60000 });
  await streamTypeSelect.selectOption("youtube");
  const youtubeInput = page.getByLabel("YouTube Video ID");
  await expect(youtubeInput).toBeVisible({ timeout: 60000 });
  await youtubeInput.fill(youtubeVideoId);
  const createButton = page.getByRole("button", { name: "Create Stream", exact: true });
  await expect(createButton).toBeEnabled();
  await createButton.click();
  await expect(page.getByText(`URL: /streams/${streamSlug}`)).toBeVisible({ timeout: 60000 });
};

const openStreamFromDashboard = async (page: Page, streamSlug: string, streamTitle: string) => {
  const streamLink = page.locator(`a[href="/stream/${streamSlug}"]`).first();
  await expect(streamLink).toBeVisible({ timeout: 60000 });
  await streamLink.click();
  await page.waitForURL(`**/stream/${streamSlug}`, { timeout: 60000 });
  await expect(page.getByRole("heading", { name: streamTitle, level: 2 })).toBeVisible({ timeout: 60000 });
};

const joinChatWithHandle = async (page: Page, nickname: string) => {
  const handleInput = page.getByPlaceholder(/Enter your handle/i);
  await expect(handleInput).toBeVisible({ timeout: 60000 });
  await handleInput.fill(nickname);
  const startChattingButton = page.getByRole("button", { name: /start chatting/i });
  await expect(startChattingButton).toBeEnabled({ timeout: 60000 });
  await startChattingButton.click();
  const chatInput = page.locator('[contenteditable="true"]').first();
  await expect(chatInput).toBeVisible({ timeout: 60000 });
  return { chatInput };
};

const sendChatMessage = async (page: Page, chatInput: Locator, message: string) => {
  await chatInput.click();
  await page.keyboard.type(message);
  await page.keyboard.press("Enter");
  await expect(page.getByText(message)).toBeVisible({ timeout: 60000 });
};

test.describe("Stream Experience", () => {
  test("creates a stream and sends chat messages", async ({ page }) => {
    test.setTimeout(60000);
    await page.goto("/login");
    await signIn(page);
    await openMyStreamsPage(page);
    const uniqueSuffix = Date.now().toString(36);
    const streamTitle = `Playwright Stream ${uniqueSuffix}`;
    const streamSlug = `playwright-stream-${uniqueSuffix}`;
    await createStream(page, streamTitle, streamSlug);
    await openStreamFromDashboard(page, streamSlug, streamTitle);
    const nickname = `clubber${uniqueSuffix}`;
    const { chatInput } = await joinChatWithHandle(page, nickname);
    const firstMessage = `First message ${uniqueSuffix}`;
    await sendChatMessage(page, chatInput, firstMessage);
    const secondMessage = `Second message ${uniqueSuffix}`;
    await sendChatMessage(page, chatInput, secondMessage);
  });
});
