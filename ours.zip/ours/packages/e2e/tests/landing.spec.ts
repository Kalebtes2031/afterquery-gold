import type { Page } from "@playwright/test";
import { expect, test } from "@playwright/test";

const instagramUrl = "https://www.instagram.com/what_is_ours/";

const navigateToLanding = async (page: Page) => {
  await page.goto("/");
};

test.describe("Landing Experience", () => {
  test.beforeEach(async ({ page }) => {
    await navigateToLanding(page);
  });

  test("shows footer links including privacy policy", async ({ page }) => {
    const currentYear = new Date().getFullYear().toString();
    await expect(page.getByText(/privacy policy/i)).toBeVisible();
    await expect(page.getByText(`© ${currentYear} OURS. All Rights Reserved`)).toBeVisible();
  });

  test("provides instagram community link", async ({ page }) => {
    const instagramLink = page.locator('a[href="https://www.instagram.com/what_is_ours/"]').first();
    await expect(instagramLink).toBeVisible();
    await expect(instagramLink).toHaveAttribute("href", instagramUrl);
    await expect(instagramLink).toHaveAttribute("target", "_blank");
  });
});
