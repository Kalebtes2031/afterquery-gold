import { readFileSync } from "node:fs";
import path from "node:path";
import { devices } from "@playwright/test";
import dotenv from "dotenv";

const getLinuxDistroName = () => {
  const content = readFileSync("/etc/os-release", "utf-8");
  const line = content
    .split("\n")
    .map((value) => value.trim())
    .find((value) => value.startsWith("NAME="));
  if (line === undefined) {
    return null;
  }
  return line.replace("NAME=", "").replace(/"/g, "").toLowerCase();
};

const detectHostOs = () => {
  if (process.platform === "darwin") {
    return "macos";
  }
  if (process.platform === "win32") {
    return "windows";
  }
  if (process.platform === "linux") {
    const distroName = getLinuxDistroName();
    if (distroName?.includes("ubuntu")) {
      return "linux_ubuntu";
    }
    return "linux_unknown";
  }
  return null;
};

type BrowserNames = "chrome" | "galaxy" | "iphone" | "safari";

const getBrowserMapping = () => {
  return <Record<BrowserNames, string>>{
    chrome: "Desktop Chrome",
    galaxy: "Galaxy S24",
    iphone: "iPhone 15",
    safari: "Desktop Safari",
  };
};

const getOsMapping = () => {
  return <Record<string, BrowserNames[]>>{
    linux_ubuntu: ["chrome", "galaxy"],
    linux_unknown: ["chrome"],
    windows: ["chrome", "galaxy"],
    macos: ["chrome", "galaxy", "iphone", "safari"],
  };
};

export const makeProjects = () => {
  const os = detectHostOs();
  if (os === null) {
    throw new Error("Unsupported host OS");
  }
  const browserMapping = getBrowserMapping();
  const osMapping = getOsMapping();
  const projects = osMapping[os].map((browser) => ({
    name: browser,
    use: { ...devices[browserMapping[browser]] },
  }));
  return projects;
};

export const getEnvVar = (key: string) => {
  if (!(key in process.env) || process.env[key] === "" || process.env[key] === undefined || process.env[key] === null) {
    throw new Error(`${key} must be defined in .env`);
  }
  return process.env[key];
};

export const loadEnv = () => {
  dotenv.config({ path: path.resolve(process.cwd(), ".env") });
  getEnvVar("E2E_CLERK_EMAIL");
  getEnvVar("E2E_CLERK_PASSWORD");
  getEnvVar("E2E_YT_VIDEO_ID");
  getEnvVar("E2E_BASE_URL");
};
