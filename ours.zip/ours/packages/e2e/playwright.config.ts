import { defineConfig } from "@playwright/test";
import { loadEnv, makeProjects } from "#ours/e2e/config_utils.ts";

loadEnv();

export default defineConfig({
  testDir: "./tests/",
  fullyParallel: true,
  forbidOnly: Boolean(process.env.CI),
  retries: process.env.CI !== undefined ? 2 : 0,
  workers: process.env.CI !== undefined ? 1 : undefined,
  outputDir: "test-results",
  use: {
    baseURL: process.env.E2E_BASE_URL,
    trace: "on-first-retry",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },
  projects: makeProjects(),
});
