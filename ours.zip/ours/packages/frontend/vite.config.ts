import path from "node:path";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig, loadEnv } from "vite";
import { getProxyConfig } from "./vite.proxy.config.ts";

const envVars = loadEnv(process.env.NODE_ENV ?? "development", __dirname);
const getEnvVar = (key: string) => {
  if (!(key in envVars) || envVars[key] === "" || envVars[key] === undefined || envVars[key] === null) {
    throw new Error(`Environment variable ${key} is not set or is empty`);
  }
  return envVars[key];
};
const proxyUrl = getEnvVar("VITE_PROXY_URL");

// https://vite.dev/config/
export default defineConfig({
  envDir: __dirname,
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "#ours/frontend": path.resolve(__dirname, "./src"),
      "#ours/shared": path.resolve(__dirname, "../shared/src"),
    },
  },
  build: {
    chunkSizeWarningLimit: 10485760, // 10 megabytes
  },
  server: {
    proxy: getProxyConfig(proxyUrl),
    allowedHosts: ["de6aa59cacff.ngrok.app"],
    port: 5173,
    host: true,
    cors: true,
    open: true,
  },
});
