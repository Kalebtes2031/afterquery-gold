# Frontend Architecture Documentation

## Overview

The OURS frontend is a modern React 19 application built with TypeScript and Vite, following atomic design principles and functional programming paradigms. It serves as a streaming platform with early access functionality, live streaming capabilities, and real-time features.

## Technology Stack

### Core Technologies

- **React 19.1.0** - Latest React with improved concurrent features
- **TypeScript 5.8.3** - Static type checking with strict configuration
- **Vite 6.3.5** - Fast build tool and development server
- **React Router DOM 7.6.0** - Client-side routing

### UI & Styling

- **Tailwind CSS 4.1.7** - Utility-first CSS framework with Vite plugin
- **React Icons 5.5.0** - SVG icon library

### Testing & Quality

- **Playwright 1.54.1** - End-to-end testing framework
- **Artillery** - Load testing and performance testing
- **Biome** - Linting and formatting (inherited from root)

## Project Structure

```
packages/frontend/
├── src/
│   ├── components/           # Component library following atomic design
│   │   ├── atoms/           # Basic building blocks
│   │   ├── molecules/       # Simple component combinations
│   │   ├── organisms/       # Complex UI sections
│   │   ├── pages/           # Top-level page components
│   │   └── templates/       # Page layout templates
│   ├── contexts/            # React Context providers
│   ├── types/               # TypeScript type definitions
│   ├── assets/              # Static assets (images, icons)
│   ├── App.tsx              # Main application component
│   └── main.tsx             # Application entry point
├── tests/
│   ├── e2e/                 # End-to-end tests
│   ├── load/                # Performance/load tests
│   └── fixtures/            # Test data
├── public/                  # Static public assets
└── configuration files
```

## Architecture Patterns

### Atomic Design System

The component architecture follows Brad Frost's atomic design methodology:

#### Atoms (`src/components/atoms/`)

Basic building blocks that cannot be broken down further:

- `BodyText.tsx` - Text content component
- `Buttons.tsx` - Button variants
- `Heading.tsx` - Header text components
- `Icons.tsx` - Icon wrapper components
- `Logo.tsx` - Brand logo component
- `UserAvatar.tsx` - User profile image component
- `FundsAvailable.tsx` - Financial display component
- `HashTag.tsx` - Tag component
- `IconButton.tsx` - Clickable icon component
- `Subtitle.tsx` - Secondary text component
- `WhatIsOursLogo.tsx` - Specific brand logo variant

#### Molecules (`src/components/molecules/`)

Simple combinations of atoms that function together:

- `ActionBar.tsx` - Action button groups
- `FormField.tsx` - Input field with label
- `HashTags.tsx` - Collection of hashtag components
- `MediaHeader.tsx` - Media content headers
- `StreamPlayer.tsx` - Video player component
- `TipOptions.tsx` - Tipping option selectors
- `TipSubmitForm.tsx` - Tip submission form
- `WordsInterval.tsx` - Animated text intervals
- `EarlyAccessBenefits.tsx` - Benefits display
- `EarlyAccessSignUpSuccess.tsx` *(retired)* - Early access flow temporarily disabled
- `StreamTippers.tsx` - Stream tip display

#### Organisms (`src/components/organisms/`)

Complex UI sections combining molecules and atoms:

- `Header.tsx` - Main navigation header
- `Footer.tsx` - Site footer
- `EarlyAccessBanner.tsx` - Landing page banner
- `StreamCard.tsx` - Stream preview card
- `StreamVideoCard.tsx` - Video content card
- `StreamTip.tsx` - Tipping interface
- `LiveChatCard.tsx` - Live chat interface
- `StreamActivitiesGraphCard.tsx` - Activity visualization

#### Templates (`src/components/templates/`)

Page-level layout structures:

- `EarlySignupTemplate.tsx` - Early access page layout
- `HomeTemplate.tsx` - Home page layout
- `StreamTemplate.tsx` - Stream page layout

#### Pages (`src/components/pages/`)

Top-level route components:

- `EarlySignup.tsx` - Early access landing page
- `Home.tsx` - Main application home
- `Stream.tsx` - Individual stream page

### Functional Programming Approach

The codebase follows functional programming principles as outlined in CLAUDE.md:

- **Pure Functions**: Components are implemented as pure functions
- **Immutable State**: No mutable variables or state mutations
- **React Hooks**: Extensive use of `React.memo()`, `useCallback()`, and `useMemo()`
- **No Side Effects**: Functions avoid side effects where possible

### Type Safety

TypeScript configuration (`tsconfig.app.json`) enforces strict typing:

```typescript
// Key TypeScript settings
{
  "strict": true,
  "noUnusedLocals": true,
  "noUnusedParameters": true,
  "noFallthroughCasesInSwitch": true,
  "noUncheckedSideEffectImports": true
}
```

## State Management

### Context API

Currently uses React Context for state management:

- **StreamContext** (`src/contexts/StreamContext.tsx`):
  - Manages stream IDs array
  - Provides `useStreamContext` hook
  - Currently marked as placeholder/unused

### Type Definitions

Comprehensive TypeScript interfaces in `src/types/index.ts`:

- Component props interfaces
- Event handler types
- Data structure definitions
- Form field specifications

## Routing Architecture

React Router DOM 7.6.0 configuration in `App.tsx`:

```typescript
<Routes>
  <Route path="/" element={<EarlySignup />} />
  <Route path="/home" element={<Home />} />
  <Route path="/stream/:streamId" element={<Stream />} />
</Routes>
```

### Route Features

- **Conditional Header**: Header hidden on landing page (`/`)
- **Dynamic Routes**: Stream pages with parameter-based routing
- **Stream Context**: All routes wrapped in StreamProvider

## Build Configuration

### Vite Configuration (`vite.config.ts`)

```typescript
export default defineConfig({
  plugins: [
    react(),           // React support
    tailwindcss()      // Tailwind CSS integration
  ],
});
```

### Import Aliases

Path aliases configured for clean imports:

```json
{
  "#ours/frontend/*": "./src/*",
  "#ours/shared/*": "../shared/src/*"
}
```

## Testing Strategy

### End-to-End Testing (Playwright)

- **Multi-browser**: Chrome, Firefox, Safari, Mobile Chrome, Mobile Safari
- **CI/CD Ready**: Parallel execution, retry logic, artifacts
- **Test Coverage**:
  - `landing.spec.ts` - Landing page marketing experience  
  - `stream.spec.ts` - Streaming features

### Load Testing (Artillery)

Comprehensive performance testing:

- **Phases**: Warm-up (5 users/s), Load test (10 users/s), Stress test (20 users/s)
- **Scenarios**: Homepage, Stream pages, API endpoints
- **Metrics**: Response times, throughput, error rates

### Test Configuration

```yaml
# Artillery load test phases
phases:
  - duration: 60, arrivalRate: 5   # Warm up
  - duration: 120, arrivalRate: 10 # Load test  
  - duration: 60, arrivalRate: 20  # Stress test
```

## Development Workflow

### Scripts Available

```json
{
  "dev": "vite",                    // Development server
  "build": "tsc -b && vite build", // Production build
  "typecheck": "tsc --noEmit",      // Type checking
  "preview": "vite preview",        // Preview build
  "test:e2e": "playwright test",    // E2E tests
  "test:load": "artillery run"      // Load tests  
}
```

### Code Quality Standards

- **File Naming**: snake_case convention enforced
- **Import Style**: Absolute paths with file extensions required
- **Component Standards**: All components use React.memo() with display names
- **No Comments**: Minimal commenting philosophy (code should be self-documenting)

## Key Features

### Early Access System

- Landing page marketing content
- Banner, benefit highlights, and community footer
- Responsive design for mobile/desktop

### Streaming Platform

- Live stream viewing interface
- Real-time chat functionality
- Tipping/monetization features
- Stream activity analytics

### User Interface

- Mobile-first responsive design
- Tailwind CSS utility classes
- Consistent atomic design system
- Accessible components

## Performance Considerations

### Build Optimization

- Vite's fast HMR (Hot Module Replacement)
- TypeScript compilation with build info caching
- Tree shaking and bundle optimization

### Runtime Performance  

- React 19's improved concurrent features
- Memoization patterns throughout components
- Lazy loading considerations for routes

## Deployment

### Build Process

1. TypeScript compilation (`tsc -b`)
2. Vite production build
3. Static asset optimization
4. Bundle analysis and optimization

### Environment Configuration

- Development server on `localhost:5173`
- Production builds optimized for static hosting
- Vercel deployment configuration (`vercel.json`)

## Future Considerations

### State Management Evolution

- Current StreamContext marked as placeholder
- Potential migration to more robust state management
- Consider Zustand or Redux Toolkit for complex state

### Testing Enhancement

- Unit testing framework integration
- Component testing strategies  
- Visual regression testing

### Performance Monitoring

- Bundle size monitoring
- Runtime performance metrics
- User experience analytics

## Integration Points

### Backend Integration

- Prepared for API integration with `#ours/backend/*` alias
- Form submission endpoints ready
- Authentication system preparation

### Shared Libraries

- Common utilities via `#ours/shared/*`
- Type sharing between frontend/backend
- Consistent data models
