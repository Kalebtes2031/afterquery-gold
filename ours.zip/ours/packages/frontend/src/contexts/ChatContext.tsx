import { useAuth } from "@clerk/clerk-react";
import type { ReactNode } from "react";
import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import { type UseChatReturn, useChat } from "#ours/frontend/hooks/useChat.ts";
import { clearTemporaryUserSession, clearUserSession, saveUserToken } from "#ours/frontend/utils/sessionUtils.ts";

interface ChatController {
  setChannelId: (channelId: string) => void;
  setUserToken: (token?: string) => void;
  clearChannel: () => void;
}

type ChatContextValue = UseChatReturn & ChatController;

const ChatContext = createContext<ChatContextValue | null>(null);

export const useChatContext = () => {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error("useChatContext must be used within a ChatProvider");
  }
  return context;
};

type ChatProviderInternalProps = {
  children: ReactNode;
  backendUrl: string;
  channelId: string;
  userToken?: string;
  expectRegistered: boolean;
  clerkLoaded: boolean;
  setChannelId: (v: string) => void;
  setUserToken: (v?: string) => void;
};

const ChatProviderInternal = React.memo(function ChatProviderInternal({
  children,
  backendUrl,
  channelId,
  userToken,
  expectRegistered,
  clerkLoaded,
  setChannelId,
  setUserToken,
}: ChatProviderInternalProps) {
  const chat = useChat({ backendUrl, channelId, userToken, expectRegistered, clerkLoaded });

  const value = useMemo<ChatContextValue>(() => {
    const clearChannel = () => {
      setUserToken(undefined);
      setChannelId("");
    };
    return {
      ...chat,
      setChannelId,
      setUserToken,
      clearChannel,
    };
  }, [chat, setChannelId, setUserToken]);

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
});

ChatProviderInternal.displayName = "ChatProviderInternal";

export const ChatProvider = React.memo(function ChatProvider({
  children,
  backendUrl,
}: {
  children: ReactNode;
  backendUrl: string;
}) {
  const { isSignedIn, isLoaded, getToken } = useAuth();
  const [channelId, setChannelId] = useState<string>("");
  const [userToken, setUserToken] = useState<string | undefined>(undefined);

  useEffect(() => {
    let cancelled = false;
    const syncToken = async () => {
      if (!isLoaded) {
        return;
      }
      if (!isSignedIn) {
        setUserToken(undefined);
        clearTemporaryUserSession();
        clearUserSession();
        return;
      }
      try {
        const token = await getToken();
        if (cancelled) {
          return;
        }
        if (token && token !== userToken) {
          setUserToken(token);
          saveUserToken(token);
        }
      } catch {
        if (!cancelled) {
          setUserToken(undefined);
        }
      }
    };

    void syncToken();

    return () => {
      cancelled = true;
    };
  }, [isLoaded, isSignedIn, getToken, userToken]);

  return (
    <ChatProviderInternal
      key={channelId || "none"}
      backendUrl={backendUrl}
      channelId={channelId}
      userToken={userToken}
      expectRegistered={isSignedIn === true}
      clerkLoaded={isLoaded === true}
      setChannelId={setChannelId}
      setUserToken={setUserToken}
    >
      {children}
    </ChatProviderInternal>
  );
});

ChatProvider.displayName = "ChatProvider";
