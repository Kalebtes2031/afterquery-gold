import React, { createContext, useContext, useEffect, useState } from "react";

interface KeyboardContextValue {
  keyboardVisible: boolean;
  keyboardHeight: number;
  isMobile: boolean;
  inputFocused: boolean;
  setInputFocused: (focused: boolean) => void;
}

const KeyboardContext = createContext<KeyboardContextValue | undefined>(undefined);

interface KeyboardProviderProps {
  children: React.ReactNode;
}

export const KeyboardProvider = React.memo(({ children }: KeyboardProviderProps) => {
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const [keyboardHeight, setKeyboardHeight] = useState(0);
  const [isMobile, setIsMobile] = useState(false);
  const [inputFocused, setInputFocused] = useState(false);

  useEffect(() => {
    // Check if device is mobile
    const checkIsMobile = () => {
      const mobile = globalThis.innerWidth < 640; // sm breakpoint
      setIsMobile(mobile);
      return mobile;
    };

    // Initial check
    checkIsMobile();

    // Listen for resize events to update mobile status
    const handleResize = () => {
      checkIsMobile();
    };

    globalThis.addEventListener("resize", handleResize);

    return () => {
      globalThis.removeEventListener("resize", handleResize);
    };
  }, []);

  useEffect(() => {
    if (!isMobile || !globalThis.visualViewport) return;

    const handleViewportChange = () => {
      const viewport = globalThis.visualViewport;
      if (!viewport) return;

      const currentKeyboardHeight = globalThis.innerHeight - viewport.height;
      const isKeyboardVisible = currentKeyboardHeight > 100; // 100px minimum threshold

      setKeyboardVisible(isKeyboardVisible);
      setKeyboardHeight(currentKeyboardHeight);
    };

    globalThis.visualViewport.addEventListener("resize", handleViewportChange);

    return () => {
      globalThis.visualViewport?.removeEventListener("resize", handleViewportChange);
    };
  }, [isMobile]);

  const value: KeyboardContextValue = {
    keyboardVisible,
    keyboardHeight,
    isMobile,
    inputFocused,
    setInputFocused,
  };

  return <KeyboardContext.Provider value={value}>{children}</KeyboardContext.Provider>;
});

KeyboardProvider.displayName = "KeyboardProvider";

export const useKeyboard = (): KeyboardContextValue => {
  const context = useContext(KeyboardContext);
  if (context === undefined) {
    throw new Error("useKeyboard must be used within a KeyboardProvider");
  }
  return context;
};

export default KeyboardProvider;
