/** 
  This context is currently not in use
  PLACEHOLDER 
 */

import type { ReactNode } from "react";
import React, { createContext, useContext, useState } from "react";
import { apiService } from "#ours/frontend/services/ApiService.ts";

interface DevUser {
  token: string;
}

interface StreamContextType {
  streamId: string[];
  setStreamId: React.Dispatch<React.SetStateAction<string[]>>;
  devUser: DevUser | null;
  simulatedLogin: (email: string, password: string) => Promise<DevUser>;
  clearSimulatedUserSession: () => void;
}

const StreamContext = createContext<StreamContextType | undefined>(undefined);

export const useStreamContext = () => {
  const context = useContext(StreamContext);
  if (!context) {
    throw new Error("useStreamContext must be used within a StreamProvider");
  }
  return context;
};

interface StreamProviderProps {
  children: ReactNode;
}

export const StreamProvider = React.memo(({ children }: StreamProviderProps) => {
  const [streamId, setStreamId] = useState<string[]>([]);
  const [devUser, setDevUser] = useState<DevUser | null>(null);

  const simulatedLogin = async (email: string, password: string): Promise<DevUser> => {
    const payload = (await apiService.post("/auth/login", { email, password })) as { token: string };

    const user: DevUser = {
      token: payload?.token as string,
    };
    setDevUser(user);
    return user;
  };

  const clearSimulatedUserSession = () => {
    setDevUser(null);
  };

  const value: StreamContextType = {
    streamId,
    setStreamId,
    devUser,
    simulatedLogin,
    clearSimulatedUserSession,
  };

  return <StreamContext.Provider value={value}>{children}</StreamContext.Provider>;
});

StreamProvider.displayName = "StreamProvider";
