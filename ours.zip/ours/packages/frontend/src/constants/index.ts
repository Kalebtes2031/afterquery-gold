export const CHAT_REACTIONS = {
  HEART: "HEART",
  HANDS_UP: "HANDS_UP",
  FIRE: "FIRE",
  MUSIC: "MUSIC",
  SURPRISED: "SURPRISED",
};

export const CHAT_EVENTS = {
  REACTION: "reaction",
  MESSAGE: "MESSAGE",
};

export type ChatEventsTypes = typeof CHAT_EVENTS;

export const CHAT_REACTION_EVENTS = {
  REACTION_ADD: "reaction_add",
  REACTION_REMOVE: "reaction_remove",
};

export const CHAT_USER_TYPES = {
  TEMPORARY: "temporary",
  REGULAR: "regular",
  ARTIST: "artist",
  ADMIN: "admin",
  MODERATOR: "moderator",
  ANONYMOUS: "anonymous",
};

export const CHAT_CHANNEL_ROLES = {
  OWNER: "owner",
  VIEWER: "viewer",
};

export const VIDEO_EMBED_URLS = {
  youtube: (videoId: string) =>
    `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&controls=1&rel=0&modestbranding=1`,
  vimeo: (videoIdOrUrl: string) => {
    // Handle Vimeo Live Event URLs: https://vimeo.com/event/5436364/729f955773
    const liveEventMatch = videoIdOrUrl.match(/vimeo\.com\/event\/(\d+)\/([a-f0-9]+)/);
    if (liveEventMatch) {
      const [, eventId, embedHash] = liveEventMatch;
      return `https://vimeo.com/event/${eventId}/embed/${embedHash}?autoplay=1&muted=1&controls=1`;
    }

    // Handle regular Vimeo video URLs: https://vimeo.com/123456789
    const regularVideoMatch = videoIdOrUrl.match(/vimeo\.com\/(\d+)/);
    if (regularVideoMatch) {
      return `https://player.vimeo.com/video/${regularVideoMatch[1]}?autoplay=1&muted=1&controls=1&title=0&byline=0&portrait=0`;
    }

    // Assume it's just a video ID if no URL pattern matched
    return `https://player.vimeo.com/video/${videoIdOrUrl}?autoplay=1&muted=1&controls=1&title=0&byline=0&portrait=0`;
  },
};
