import QRCode from "qrcode";
import { useCallback, useEffect, useState } from "react";

export type PaymentType = "venmo" | "cashapp" | "paypal";

export interface PaymentMethod {
  paymentType: PaymentType;
  handle: string;
}

export interface UsePaymentReturn {
  selectedPayment: PaymentType;
  setSelectedPayment: (payment: PaymentType) => void;
  copied: boolean;
  qrCodeDataUrl: string;
  availablePaymentTypes: PaymentType[];
  getPaymentHandle: () => string;
  handleCopy: () => void;
}

export const usePayment = (paymentMethods?: PaymentMethod[]): UsePaymentReturn => {
  const [selectedPayment, setSelectedPayment] = useState<PaymentType>("cashapp");
  const [copied, setCopied] = useState(false);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>("");

  const getPaymentHandle = useCallback(() => {
    if (!paymentMethods || paymentMethods.length === 0) {
      return "No payment methods available";
    }

    const selectedMethod = paymentMethods.find((pm) => pm.paymentType === selectedPayment);
    return selectedMethod ? selectedMethod.handle : "No handle available";
  }, [paymentMethods, selectedPayment]);

  const availablePaymentTypes = paymentMethods ? paymentMethods.map((pm) => pm.paymentType) : [];

  useEffect(() => {
    if (availablePaymentTypes.length > 0 && !availablePaymentTypes.includes(selectedPayment)) {
      setSelectedPayment(availablePaymentTypes[0]);
    }
  }, [availablePaymentTypes, selectedPayment]);

  useEffect(() => {
    const generateQRCode = async () => {
      const handle = getPaymentHandle();
      if (handle && handle !== "No payment methods available" && handle !== "No handle available") {
        try {
          let qrData = handle;
          if (selectedPayment === "cashapp") {
            qrData = `https://cash.app/${handle}`;
          } else if (selectedPayment === "venmo") {
            qrData = `https://venmo.com/${handle}?txn=pay`;
          } else if (selectedPayment === "paypal") {
            qrData = `https://paypal.me/${handle}`;
          }

          const dataUrl = await QRCode.toDataURL(qrData, {
            width: 160,
            margin: 1,
            color: {
              dark: "#000000",
              light: "#FFFFFF",
            },
          });
          setQrCodeDataUrl(dataUrl);
        } catch (error) {
          console.error("Error generating QR code:", error);
        }
      }
    };

    generateQRCode();
  }, [getPaymentHandle, selectedPayment]);

  const fallbackCopyTextToClipboard = useCallback((text: string) => {
    const textArea = document.createElement("textarea");
    textArea.value = text;

    textArea.style.position = "fixed";
    textArea.style.left = "-999999px";
    textArea.style.top = "-999999px";
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();

    try {
      document.execCommand("copy");
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Fallback: Oops, unable to copy", err);
    }

    document.body.removeChild(textArea);
  }, []);

  const handleCopy = useCallback(() => {
    const text = getPaymentHandle();

    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard
        .writeText(text)
        .then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 2000);
        })
        .catch(() => {
          fallbackCopyTextToClipboard(text);
        });
    } else {
      fallbackCopyTextToClipboard(text);
    }
  }, [getPaymentHandle, fallbackCopyTextToClipboard]);

  return {
    selectedPayment,
    setSelectedPayment,
    copied,
    qrCodeDataUrl,
    availablePaymentTypes,
    getPaymentHandle,
    handleCopy,
  };
};
