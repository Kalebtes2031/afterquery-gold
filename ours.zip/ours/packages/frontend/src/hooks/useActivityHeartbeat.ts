import { useCallback, useRef } from "react";
import type { AuthService } from "#ours/frontend/services/AuthService.ts";
import { extendUserSession } from "#ours/frontend/utils/sessionUtils.ts";

export function useActivityHeartbeat(channelId: string, authServiceRef: React.MutableRefObject<AuthService>) {
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const start = useCallback(
    (nickname: string) => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }

      intervalRef.current = setInterval(async () => {
        try {
          await authServiceRef.current.updateActivity(nickname);
          extendUserSession(channelId);
        } catch (error) {
          console.error("Error updating activity:", error);
        }
      }, 30000);
    },
    [channelId, authServiceRef],
  );

  const stop = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  return { start, stop };
}
