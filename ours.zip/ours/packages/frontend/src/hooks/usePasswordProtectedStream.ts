import { useQuery, useQueryClient } from "@tanstack/react-query";
import { isAxiosError } from "axios";
import { useCallback, useEffect, useMemo, useState } from "react";
import { apiService } from "#ours/frontend/services/ApiService.ts";
import type { Stream } from "#ours/frontend/types/index.ts";

interface UsePasswordProtectedStreamProps {
  streamId: string;
}

interface UsePasswordProtectedStreamReturn {
  // Stream data
  streamData: Stream | undefined;
  isLoading: boolean;
  error: unknown;

  // Password modal state
  showPasswordModal: boolean;
  passwordError: string;
  isVerifyingPassword: boolean;

  // Actions
  handlePasswordSubmit: (password: string) => Promise<void>;
  handlePasswordModalClose: () => void;
}

export function usePasswordProtectedStream({
  streamId,
}: UsePasswordProtectedStreamProps): UsePasswordProtectedStreamReturn {
  const queryClient = useQueryClient();
  const [password, setPassword] = useState<string>("");
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordError, setPasswordError] = useState<string>("");
  const [isVerifyingPassword, setIsVerifyingPassword] = useState(false);

  const streamQueryKey = useMemo(() => ["GET_STREAM_DATA", streamId, password] as const, [streamId, password]);

  const fetchStream = useCallback(
    async (streamPassword: string): Promise<Stream> => {
      if (!streamId) {
        throw new Error("Stream ID is required");
      }

      const params = streamPassword ? { password: streamPassword } : undefined;
      const response = await apiService.get<{ stream: Stream }>(`/api/streams/${streamId}`, params);
      return response.stream;
    },
    [streamId],
  );

  const {
    data: streamData,
    isLoading,
    error,
  } = useQuery({
    queryKey: streamQueryKey,
    queryFn: () => fetchStream(password),
    enabled: !!streamId,
    retry: (failureCount, fetchError) => {
      if (isAxiosError(fetchError) && fetchError.response?.status === 401) {
        return false;
      }
      return failureCount < 3;
    },
  });

  // Show / hide password modal based solely on confirmed streamData
  // Avoid closing the modal while a fetch is in-flight or when streamData is undefined (e.g. 401)
  useEffect(() => {
    if (!streamData) return; // keep existing state until we know more
    if (streamData.requiresPassword && !showPasswordModal) {
      setShowPasswordModal(true);
    } else if (!streamData.requiresPassword && showPasswordModal) {
      setShowPasswordModal(false);
    }
  }, [streamData, showPasswordModal]);

  // Handle password submission
  const handlePasswordSubmit = useCallback(
    async (submittedPassword: string) => {
      if (!streamId) {
        return;
      }

      setIsVerifyingPassword(true);
      setPasswordError("");

      try {
        await queryClient.fetchQuery({
          queryKey: ["GET_STREAM_DATA", streamId, submittedPassword] as const,
          queryFn: () => fetchStream(submittedPassword),
        });

        setPassword(submittedPassword);
        setPasswordError("");
      } catch (submitError: unknown) {
        if (isAxiosError(submitError) && submitError.response?.status === 401) {
          setPasswordError("Invalid password. Please try again.");
        } else {
          setPasswordError("An error occurred. Please try again.");
        }
      } finally {
        setIsVerifyingPassword(false);
      }
    },
    [fetchStream, queryClient, streamId],
  );

  const handlePasswordModalClose = () => {
    setShowPasswordModal(false);
    window.history.back();
  };

  return {
    streamData,
    isLoading,
    error,
    showPasswordModal,
    passwordError,
    isVerifyingPassword,
    handlePasswordSubmit,
    handlePasswordModalClose,
  };
}
