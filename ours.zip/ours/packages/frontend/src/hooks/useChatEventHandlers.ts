import { useEffect } from "react";
import { CHAT_REACTION_EVENTS } from "#ours/frontend/constants/index.ts";
import type {
  ChatEvent,
  ChatMessage,
  ConnectionStatus,
  IVSChatService,
} from "#ours/frontend/services/IvsChatService.ts";
import { isChatEventReaction } from "#ours/frontend/services/IvsChatService.ts";

type SetState<T> = React.Dispatch<React.SetStateAction<T>>;

export function useChatEventHandlers(args: {
  chatServiceRef: React.MutableRefObject<IVSChatService>;
  maxMessages: number;
  setMessages: SetState<ChatMessage[]>;
  setEvents: SetState<ChatEvent[]>;
  setConnectionStatus: SetState<ConnectionStatus>;
  setError: (msg: string) => void;
  seenMessagesRef: React.MutableRefObject<Set<string>>;
}) {
  const { chatServiceRef, maxMessages, setMessages, setEvents, setConnectionStatus, setError, seenMessagesRef } = args;

  useEffect(() => {
    const chatService = chatServiceRef.current;

    const handleMessage = (message: ChatMessage) => {
      if (seenMessagesRef.current.has(message.id)) {
        // Deduplicate messages
        // console.warn(`Duplicate message ignored: ${message.id}`);
        return;
      }

      seenMessagesRef.current.add(message.id);
      setMessages((prev) => {
        const newMessages = [...prev, message];
        return newMessages.slice(-maxMessages);
      });

      if (seenMessagesRef.current.size > 1000) {
        const messagesArray = Array.from(seenMessagesRef.current);
        const toKeep = messagesArray.slice(-500);
        seenMessagesRef.current = new Set(toKeep);
      }
    };

    const updateMessageReactions = (
      messages: ChatMessage[],
      messageId: string,
      reaction: string,
      type: string,
      userId: string,
    ): ChatMessage[] => {
      const messageIndex = messages.findIndex((msg) => msg.id === messageId);
      if (messageIndex === -1) return messages;

      const newMessages = [...messages];
      const message = { ...newMessages[messageIndex] };

      if (!message.reactions) message.reactions = [];

      const reactionIndex = message.reactions.findIndex((r) => r.reaction === reaction);

      if (type === CHAT_REACTION_EVENTS.REACTION_ADD) {
        if (reactionIndex >= 0) {
          const existingReaction = { ...message.reactions[reactionIndex] };
          if (!existingReaction.users?.includes(userId)) {
            existingReaction.count += 1;
            existingReaction.users = [...(existingReaction.users || []), userId];
            message.reactions[reactionIndex] = existingReaction;
          }
        } else {
          message.reactions.push({
            reaction,
            count: 1,
            users: [userId],
          });
        }
      } else if (type === CHAT_REACTION_EVENTS.REACTION_REMOVE && reactionIndex >= 0) {
        const existingReaction = { ...message.reactions[reactionIndex] };
        existingReaction.users = existingReaction.users?.filter((id) => id !== userId) || [];
        existingReaction.count = existingReaction.users.length;

        if (existingReaction.count === 0) {
          message.reactions.splice(reactionIndex, 1);
        } else {
          message.reactions[reactionIndex] = existingReaction;
        }
      }

      newMessages[messageIndex] = message;
      return newMessages;
    };

    const handleEvent = (event: ChatEvent) => {
      setEvents((prev) => [...prev, event]);
      if (isChatEventReaction(event)) {
        setMessages((prev) =>
          updateMessageReactions(
            prev,
            event.attributes.messageId,
            event.attributes.reaction,
            event.attributes.type,
            event.attributes.userId,
          ),
        );
      }
    };

    const handleConnectionStatusChange = (status: ConnectionStatus) => {
      setConnectionStatus(status);
      if (status.state === "error") {
        console.warn("Chat service error:", status.message);
        setError("Reconnecting...");
      }
    };

    const handleError = (error: Error) => {
      console.error("Chat service error:", error);
      setError(error.message);
    };

    chatService.on("message", handleMessage);
    chatService.on("event", handleEvent);
    chatService.on("connectionStatusChange", handleConnectionStatusChange);
    chatService.on("error", handleError);

    return () => {
      chatService.off("message", handleMessage);
      chatService.off("event", handleEvent);
      chatService.off("connectionStatusChange", handleConnectionStatusChange);
      chatService.off("error", handleError);
    };
  }, [chatServiceRef, maxMessages, setMessages, setEvents, setConnectionStatus, setError, seenMessagesRef]);
}
