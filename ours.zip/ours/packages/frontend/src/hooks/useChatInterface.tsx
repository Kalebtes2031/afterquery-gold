import { useMemo } from "react";
import { ActiveChatBoxRefactored } from "#ours/frontend/components/organisms/ActiveChatBox.tsx";
import { ReadOnlyChatIntro } from "#ours/frontend/components/organisms/ReadOnlyChatIntro.tsx";
import type { UserInfo } from "#ours/frontend/types/chat.ts";

interface ChatInterfaceProps {
  isReadOnlyMode: boolean;
  hostName: string;
  newMessage: string | null;
  canSendMessages: boolean;
  currentUser: UserInfo | null;
  getInputStyle: {
    backgroundColor: string;
    color?: string;
  };
  getButtonStyle: {
    backgroundColor: string;
    color: string;
  };
  handleMessageChange: (value: string) => void;
  handleReceiveInput: (e: React.FormEvent) => void;
  handleGifSelect: (gifUrl: string) => void;
  handleEmojiSelect: (emoji: string) => void;
  closeChatConnection: () => void;
}

export const useChatInterface = (props: ChatInterfaceProps) => {
  const {
    isReadOnlyMode,
    hostName,
    newMessage,
    canSendMessages,
    currentUser,
    getInputStyle,
    getButtonStyle,
    handleMessageChange,
    handleReceiveInput,
    closeChatConnection,
  } = props;

  return useMemo(() => {
    if (isReadOnlyMode) {
      return (
        <ReadOnlyChatIntro
          hostName={hostName}
          newMessage={newMessage}
          getInputStyle={getInputStyle}
          getButtonStyle={getButtonStyle}
          handleMessageChange={handleMessageChange}
          handleReceiveInput={handleReceiveInput}
        />
      );
    }

    return (
      <ActiveChatBoxRefactored
        newMessage={newMessage}
        canSendMessages={canSendMessages}
        currentUser={currentUser}
        getInputStyle={getInputStyle}
        getButtonStyle={getButtonStyle}
        handleMessageChange={handleMessageChange}
        handleReceiveInput={handleReceiveInput}
        closeChatConnection={closeChatConnection}
      />
    );
  }, [
    isReadOnlyMode,
    hostName,
    newMessage,
    canSendMessages,
    currentUser,
    getInputStyle,
    getButtonStyle,
    handleMessageChange,
    handleReceiveInput,
    closeChatConnection,
  ]);
};
