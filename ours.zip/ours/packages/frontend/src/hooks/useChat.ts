import { useQuery } from "@tanstack/react-query";
import { useCallback, useEffect, useRef, useState } from "react";
import { CHAT_USER_TYPES } from "#ours/frontend/constants/index.ts";
import { useActivityHeartbeat } from "#ours/frontend/hooks/useActivityHeartbeat.ts";
import { useChatEventHandlers } from "#ours/frontend/hooks/useChatEventHandlers.ts";
// Removed direct event constants usage; event handling moved to useChatEventHandlers
import {
  AuthService,
  type JoinChatRequest,
  type NicknameAvailabilityResponse,
  type RoomInfo,
  type TokenResponse,
} from "#ours/frontend/services/AuthService.ts";
import {
  type ChatEvent,
  type ChatMessage,
  type ConnectionStatus,
  IVSChatService,
} from "#ours/frontend/services/IvsChatService.ts";
import { messagesService } from "#ours/frontend/services/MessagesService.ts";
import { reactionService } from "#ours/frontend/services/ReactionService.ts";
import type { ChatConfig, UserInfo } from "#ours/frontend/types/chat.ts";
import type { UserType } from "#ours/frontend/types/index.ts";
import {
  clearTemporaryUserSession,
  clearUserSession,
  extendUserSession,
  getUserToken,
  loadUserSession,
  type StoredUserSession,
  saveUserSession,
} from "#ours/frontend/utils/sessionUtils.ts";

export type UseChatReturn = {
  messages: ChatMessage[];
  events: ChatEvent[];
  connectionStatus: ConnectionStatus;
  currentRoom: RoomInfo | null;
  isConnected: boolean;
  canSendMessages: boolean;
  currentUser: UserInfo | null;
  isReadOnlyMode: boolean;
  checkNicknameAvailability: (nickname: string, userType?: UserType) => Promise<NicknameAvailabilityResponse>;
  connectWithNickName: ({
    nickname,
    userType,
    authToken,
  }: {
    nickname: string;
    userType?: UserType;
    authToken?: string;
  }) => Promise<boolean>;
  connectWithToken: ({ userToken }: { userToken: string }) => Promise<boolean>;
  connectReadOnly: () => Promise<boolean | null>;
  leaveChat: () => Promise<void>;
  switchToReadOnly: () => Promise<boolean | null>;
  sendMessage: (content: string, attributes?: Record<string, string>) => Promise<boolean>;
  sendEvent: (eventName: string, attributes: Record<string, string>) => Promise<boolean>;
  deleteMessage: (messageId: string, reason?: string) => Promise<boolean>;
  disconnectUser: (userId: string, reason?: string) => Promise<boolean>;
  clearMessages: () => void;
  toggleReaction: (messageId: string, reaction: string, userId: string, streamId: string) => Promise<void>;
  roomInfo: { roomId?: string; userId?: string; username?: string };
  isLoading: boolean;
  error: string | null;
};

export const useChat = (config: ChatConfig) => {
  const authServiceRef = useRef<AuthService>(new AuthService());
  const chatServiceRef = useRef<IVSChatService>(new IVSChatService());
  const MAX_MESSAGES = 800;
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [events, setEvents] = useState<ChatEvent[]>([]);
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>({ state: "disconnected" });
  const [currentRoom, setCurrentRoom] = useState<RoomInfo | null>(null);
  const [currentUser, setCurrentUser] = useState<UserInfo | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isReadOnlyMode, setIsReadOnlyMode] = useState(false);

  const { start: startActivityHeartbeat, stop: stopActivityHeartbeat } = useActivityHeartbeat(
    config.channelId,
    authServiceRef,
  );

  const seenMessagesRef = useRef<Set<string>>(new Set());

  const executeWithLoading = useCallback(async <T>(operation: () => Promise<T>): Promise<T> => {
    setIsLoading(true);
    setError(null);
    const result = await operation();
    setIsLoading(false);
    return result;
  }, []);

  // Load messages from backend
  const loadMessagesFromBackend = useCallback(async () => {
    console.log(`Loading messages for channel: ${config.channelId}`);
    const response = await messagesService.getChannelMessages(config.channelId);
    console.log("Messages response length:", response.success, response.error);

    if (response.success && response.messages) {
      console.log(`Found ${response.messages.length} messages`);
      // Convert backend messages to ChatMessage format
      const chatMessages: ChatMessage[] = response.messages.map((msg) => ({
        id: msg.id,
        content: msg.content,
        userId: msg.userId,
        username: msg.username,
        timestamp: msg.timestamp,
        attributes: {
          userType: msg.userType || "",
          isRegistered: msg.isRegistered || "",
        },
        sender: {
          userId: msg.userId,
          attributes: {
            username: msg.username,
            userType: msg.userType || "",
            isRegistered: msg.isRegistered || "",
          },
        },
      }));

      setMessages(chatMessages);

      // Mark messages as seen to avoid duplicates
      chatMessages.forEach((msg) => {
        seenMessagesRef.current.add(msg.id);
      });
      console.log(`Loaded ${chatMessages.length} messages into state`);
    } else {
      console.log("No messages found or request failed");
    }
  }, [config.channelId]);

  const connectToIVS = useCallback(
    async (params: { roomId: string; userId: string; username: string; token: string; endpoint: string }) => {
      const chatService = chatServiceRef.current;
      await chatService.connect(params);
    },
    [],
  );

  const coerceUserType = useCallback((value?: string): UserType => {
    const hasUserType = (value2: string | undefined): value2 is UserType => {
      return value2 !== undefined && value2 !== "" && value2 in CHAT_USER_TYPES;
    };
    if (!hasUserType(value)) {
      return CHAT_USER_TYPES.TEMPORARY;
    }
    return value;
  }, []);

  useEffect(() => {
    if (error) {
      const timer = setTimeout(() => setError(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  useChatEventHandlers({
    chatServiceRef,
    maxMessages: MAX_MESSAGES,
    setMessages,
    setEvents,
    setConnectionStatus,
    setError,
    seenMessagesRef,
  });

  const resumeWithStoredToken = useCallback(
    async (storedSession: StoredUserSession) => {
      const tokenData = storedSession.tokenData;
      if (!tokenData || tokenData.token === "" || tokenData.endpoint === "") {
        return false;
      }
      if (tokenData.tokenExpirationTime) {
        const expirationMs = new Date(tokenData.tokenExpirationTime).getTime();
        if (Number.isFinite(expirationMs)) {
          const now = Date.now();
          if (expirationMs <= now + 3000) {
            return false;
          }
        }
      }
      await connectToIVS({
        roomId: storedSession.channelId,
        userId: tokenData.userId || storedSession.user.chatUserId,
        username: storedSession.user.nickname,
        token: tokenData.token,
        endpoint: tokenData.endpoint,
      });
      const chatService = chatServiceRef.current;
      const connected = await new Promise<boolean>((resolve) => {
        let settled = false;
        const handleStatus = (status: ConnectionStatus) => {
          if (settled) {
            return;
          }
          if (status.state === "connected") {
            settled = true;
            chatService.off("connectionStatusChange", handleStatus);
            resolve(true);
            return;
          }
          if (status.state === "error" || status.state === "disconnected") {
            settled = true;
            chatService.off("connectionStatusChange", handleStatus);
            resolve(false);
          }
        };
        setTimeout(() => {
          if (settled) {
            return;
          }
          settled = true;
          chatService.off("connectionStatusChange", handleStatus);
          const status = chatService.getConnectionStatus();
          resolve(status.state === "connected");
        }, 2000);
        chatService.on("connectionStatusChange", handleStatus);
      });
      if (!connected) {
        chatService.disconnect();
        return false;
      }
      setCurrentUser(storedSession.user);
      setCurrentRoom((prevRoom) => (prevRoom ? prevRoom : { id: storedSession.channelId }));
      setIsReadOnlyMode(false);
      startActivityHeartbeat(storedSession.user.nickname);
      extendUserSession(storedSession.channelId);
      return true;
    },
    [connectToIVS, startActivityHeartbeat],
  );

  // Load messages when connection is established
  useEffect(() => {
    console.log("Connection status changed to:", connectionStatus.state);
    if (connectionStatus.state === "connected") {
      console.log("Connection established, loading messages...");
      loadMessagesFromBackend();
    }
  }, [connectionStatus.state, loadMessagesFromBackend]);

  // biome-ignore lint/correctness/useExhaustiveDependencies: Adding leaveChat and removing config causes UI issues
  const restoreUserSession = useCallback(
    async (storedSession: StoredUserSession) => {
      const authService = authServiceRef.current;
      const resumed = await resumeWithStoredToken(storedSession);
      if (resumed) {
        return true;
      }
      // Try to rejoin with the same nickname (this should succeed if our session is still valid)
      const joinTempResp = await executeWithLoading(async () =>
        authService.joinChatTemporary({
          nickname: storedSession.user.nickname,
          channelId: storedSession.channelId,
          userType: coerceUserType(storedSession.user.type),
          authToken: storedSession.tokenData?.token,
          userId: storedSession.tokenData?.userId || "",
        }),
      );
      if (joinTempResp.success === false) {
        const msg = joinTempResp.reason === "in_use" ? "This username is already in use" : "Unable to join the chat";
        setError(msg);
        return false;
      }
      const tokenResponse = joinTempResp.token;
      if (tokenResponse.action === "leave") {
        await leaveChat();
        return false;
      }
      if (!tokenResponse.success || !tokenResponse.token || !tokenResponse.endpoint) {
        return false;
      }
      setCurrentUser(storedSession.user);
      if (tokenResponse.room) {
        setCurrentRoom(tokenResponse.room);
      }
      setIsReadOnlyMode(false);
      await connectToIVS({
        roomId: storedSession.channelId,
        userId: tokenResponse.userId || storedSession.user.chatUserId,
        username: storedSession.user.nickname,
        token: tokenResponse.token,
        endpoint: tokenResponse.endpoint,
      });
      saveUserSession(storedSession.user, storedSession.channelId, {
        token: tokenResponse.token,
        userId: tokenResponse.userId || storedSession.user.chatUserId,
        endpoint: tokenResponse.endpoint,
        tokenExpirationTime: tokenResponse.tokenExpirationTime || "",
      });
      startActivityHeartbeat(storedSession.user.nickname);
      return true;
    },
    [config, startActivityHeartbeat, connectToIVS, executeWithLoading, resumeWithStoredToken],
  );

  const checkNicknameAvailability = useCallback(
    async (nickname: string, userType: UserType = CHAT_USER_TYPES.TEMPORARY) => {
      const authService = authServiceRef.current;
      return await authService.checkNicknameAvailability(nickname, userType);
    },
    [],
  );

  const performConnect = useCallback(
    async (tokenResponse: TokenResponse, opts: { nickname: string; readOnly?: boolean }) => {
      if (!tokenResponse.success || !tokenResponse.token || !tokenResponse.endpoint) {
        throw new Error(tokenResponse.error || "Failed to connect to chat");
      }
      if (tokenResponse.user) {
        setCurrentUser(tokenResponse.user);
      }
      if (tokenResponse.room) {
        setCurrentRoom(tokenResponse.room);
      }
      const isReadOnly = Boolean(opts.readOnly);
      setIsReadOnlyMode(isReadOnly);
      await connectToIVS({
        roomId: config.channelId,
        userId: tokenResponse.userId || tokenResponse.user?.chatUserId || (isReadOnly ? "anonymous" : opts.nickname),
        username: isReadOnly ? "Anonymous" : opts.nickname,
        token: tokenResponse.token,
        endpoint: tokenResponse.endpoint,
      });

      if (!isReadOnly && tokenResponse.user) {
        saveUserSession(tokenResponse.user, config.channelId, {
          token: tokenResponse.token,
          userId: tokenResponse.userId || tokenResponse.user.chatUserId,
          endpoint: tokenResponse.endpoint,
          tokenExpirationTime: tokenResponse.tokenExpirationTime || "",
        });
      }
      if (!isReadOnly) {
        startActivityHeartbeat(opts.nickname);
      }
      return true;
    },
    [config.channelId, startActivityHeartbeat, connectToIVS],
  );

  // Connect in read-only mode (no nickname required) using unified flow
  const connectReadOnly = useCallback(async () => {
    if (config.channelId === "") {
      return null;
    }
    const authService = authServiceRef.current;
    const tokenResponse: TokenResponse = await executeWithLoading(() => authService.joinChatReadOnly(config.channelId));
    const result = await performConnect(tokenResponse, { nickname: "Anonymous", readOnly: true });
    return result;
  }, [config.channelId, executeWithLoading, performConnect]);

  const leaveChat = useCallback(async () => {
    const chatService = chatServiceRef.current;
    const authService = authServiceRef.current;
    stopActivityHeartbeat();
    chatService.disconnect();
    if (currentUser && !isReadOnlyMode) {
      await authService.leaveChat(currentUser.nickname, config.channelId);
    }
    clearTemporaryUserSession();
    clearUserSession();
    setCurrentRoom(null);
    setCurrentUser(null);
    setIsReadOnlyMode(false);
    setError(null);
    setConnectionStatus({ state: "disconnected" });
  }, [config.channelId, currentUser, isReadOnlyMode, stopActivityHeartbeat]);

  const switchToReadOnly = useCallback(async () => {
    if (config.channelId === "") {
      return null;
    }
    const chatService = chatServiceRef.current;
    const authService = authServiceRef.current;
    stopActivityHeartbeat();
    chatService.disconnect();
    if (currentUser && !isReadOnlyMode) {
      await authService.leaveChat(currentUser.nickname, config.channelId);
    }
    clearTemporaryUserSession();
    clearUserSession();
    setCurrentUser(null);
    setIsReadOnlyMode(false);
    setError(null);
    setConnectionStatus({ state: "disconnected" });
    await new Promise((resolve) => setTimeout(resolve, 500));
    const success = await connectReadOnly();
    return success;
  }, [config.channelId, currentUser, isReadOnlyMode, stopActivityHeartbeat, connectReadOnly]);

  const ensureCleanFromReadOnly = useCallback(async () => {
    if (isReadOnlyMode) {
      const chatService = chatServiceRef.current;
      chatService.disconnect();
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
  }, [isReadOnlyMode]);

  const connectWithNickName = useCallback(
    async ({
      nickname,
      userType = CHAT_USER_TYPES.TEMPORARY,
      authToken,
    }: {
      nickname: string;
      userType?: UserType;
      authToken?: string;
    }): Promise<boolean> => {
      const authService = authServiceRef.current;

      // Avoid additional fetch: trust joinChat to validate nickname
      await ensureCleanFromReadOnly();

      const joinRequest: JoinChatRequest = {
        nickname,
        channelId: config.channelId,
        userType,
        authToken,
        userId: currentUser?.chatUserId || "",
      };

      const joinResp = await executeWithLoading(() => authService.joinChatTemporary(joinRequest));
      if (joinResp.success === false) {
        const msg = joinResp.reason === "in_use" ? "This username is already in use" : "Unable to join the chat";
        setError(msg);
        return false;
      }
      const tokenResponse = joinResp.token;
      const result = await performConnect(tokenResponse, { nickname, readOnly: false });
      return result;
    },
    [config.channelId, performConnect, ensureCleanFromReadOnly, executeWithLoading, currentUser?.chatUserId],
  );

  const connectWithToken = useCallback(
    async ({ userToken }: { userToken: string }): Promise<boolean> => {
      await ensureCleanFromReadOnly();
      const authService = authServiceRef.current;
      const tokenResponse = await executeWithLoading(() =>
        authService.joinChatRegistered({ roomId: config.channelId, token: userToken }),
      );

      const nickname = tokenResponse.user?.nickname || "User";
      const result = await performConnect(tokenResponse, { nickname, readOnly: false });
      return result;
    },
    [config.channelId, performConnect, ensureCleanFromReadOnly, executeWithLoading],
  );

  // Send message (blocked in read-only mode)
  const sendMessage = useCallback(
    async (content: string, attributes?: Record<string, string>): Promise<boolean> => {
      if (isReadOnlyMode) {
        setError("Please choose a username to send messages");
        return false;
      }

      const chatService = chatServiceRef.current;
      const success = await chatService.sendMessage(content, attributes);

      // Store message in backend if sent successfully
      if (success && currentUser) {
        try {
          await messagesService.storeMessage({
            id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            content,
            userId: currentUser.chatUserId,
            username: currentUser.nickname,
            timestamp: new Date().toISOString(),
            channelId: config.channelId,
            userType: currentUser.type,
            isRegistered: currentUser.isRegistered ? "true" : "false",
          });
        } catch (error) {
          console.error("Error storing message in backend:", error);
          // Don't fail the message send if storage fails
        }
      }

      // Extend session on successful message send
      if (success) {
        extendUserSession(config.channelId);
      }

      return success;
    },
    [isReadOnlyMode, config.channelId, currentUser],
  );

  // Send event
  const sendEvent = useCallback(async (eventName: string, attributes: Record<string, string>): Promise<boolean> => {
    const chatService = chatServiceRef.current;
    return await chatService.sendEvent(eventName, attributes);
  }, []);

  // Delete message (admin function)
  const deleteMessage = useCallback(async (messageId: string, reason?: string): Promise<boolean> => {
    const chatService = chatServiceRef.current;
    return await chatService.deleteMessage(messageId, reason);
  }, []);

  // Disconnect user (admin function)
  const disconnectUser = useCallback(async (userId: string, reason?: string): Promise<boolean> => {
    const chatService = chatServiceRef.current;
    return await chatService.disconnectUser(userId, reason);
  }, []);

  // Clear messages
  const clearMessages = useCallback((): void => {
    setMessages([]);
    setEvents([]);
    seenMessagesRef.current.clear();
  }, []);

  // Smart connection using useQuery ONLY for initial connection
  const expectRegistered = config.expectRegistered ?? false;
  const clerkLoaded = config.clerkLoaded ?? false;

  const shouldEnableConnectionQuery = (() => {
    if (!config.channelId) {
      return false;
    }
    if (connectionStatus.state !== "disconnected") {
      return false;
    }
    if (!clerkLoaded && expectRegistered) {
      return false;
    }
    if (!expectRegistered) {
      return true;
    }
    if (config.userToken && config.userToken !== "") {
      return true;
    }
    const storedToken = getUserToken();
    return storedToken !== null && storedToken !== "";
  })();

  const { data: connectionResult } = useQuery({
    queryKey: ["chat-connection", config.channelId, config.userToken || getUserToken(), expectRegistered],
    queryFn: async () => {
      const registeredToken = config.userToken || getUserToken();
      const storedSession = loadUserSession(config.channelId);

      // 1) Try registered user token first (connect-registered)
      if (registeredToken) {
        const success = await connectWithToken({ userToken: registeredToken });
        if (success) return { type: "registered", success: true };
      }

      // 2) Try temporary session if available (connect-temporary)
      if (storedSession?.user) {
        const success = await restoreUserSession(storedSession);
        if (success) return { type: "temporary", success: true };
      }

      // 3) Fallback to read-only mode (connect-readonly)
      const success = await connectReadOnly();
      return { type: "readonly", success };
    },
    // KEY CHANGE: Only enable useQuery for initial connection, not for reconnections
    enabled: shouldEnableConnectionQuery,
    staleTime: 5 * 60 * 1000, // 5 minutes
    retry: false, // Don't retry failed connections automatically
    refetchOnWindowFocus: false,
    refetchOnMount: false,
  });

  // Unified reconnection handling: token changes + focus/network/background regain
  useEffect(() => {
    console.log("Unified reconnection effect, connectionStatus:", connectionStatus.state);

    // Flag to prevent multiple simultaneous reconnections
    let isReconnecting = false;

    const handleTokenUpgrade = async (): Promise<void> => {
      const newToken = config.userToken || getUserToken();
      const isCurrentlyRegistered = connectionResult?.type === "registered";
      const hasNewToken = newToken && !isCurrentlyRegistered;

      if (hasNewToken && connectionStatus.state === "connected") {
        console.log("Token upgrade detected, reconnecting with new token");
        isReconnecting = true;

        // Reconnect directly without using leaveChat to avoid triggering useQuery
        try {
          const chatService = chatServiceRef.current;
          chatService.disconnect(); // Disconnect only the websocket

          // Connect with new token
          const success = await connectWithToken({ userToken: newToken });
          if (!success) {
            console.error("Failed to upgrade token connection");
          }
        } catch (error) {
          console.error("Token upgrade failed:", error);
        } finally {
          isReconnecting = false;
        }
      }
    };

    const tryReconnect = async (source: string): Promise<void> => {
      console.log(
        `tryReconnect called from: ${source}, current state: ${connectionStatus.state}, isReconnecting: ${isReconnecting}`,
      );

      // Avoid reconnecting if already connected, connecting, or a reconnection is in progress
      if (connectionStatus.state === "connected" || connectionStatus.state === "connecting" || isReconnecting) {
        console.log(`Skipping reconnect from ${source} - already connected/connecting or in progress`);
        return;
      }

      console.log(`Starting reconnection from ${source}`);
      isReconnecting = true;
      try {
        const registeredToken = config.userToken || getUserToken();
        const storedSession = loadUserSession(config.channelId);

        console.log(
          `Reconnection attempt - hasToken: ${!!registeredToken}, hasStoredSession: ${!!storedSession?.user}`,
        );

        if (storedSession?.user) {
          const resumed = await resumeWithStoredToken(storedSession);
          if (resumed) {
            console.log(`Successfully reconnected with cached session from ${source}`);
            return;
          }
        }

        if (registeredToken) {
          console.log("Attempting reconnect with registered token");
          const ok = await connectWithToken({ userToken: registeredToken });
          if (ok) {
            console.log(`Successfully reconnected with token from ${source}`);
            return;
          }
        }

        if (storedSession?.user) {
          console.log("Attempting reconnect with stored session");
          const ok = await restoreUserSession(storedSession);
          if (ok) {
            console.log(`Successfully reconnected with session from ${source}`);
            return;
          }
        }

        console.log("Falling back to read-only connection");
        await connectReadOnly();
        console.log(`Successfully reconnected in read-only mode from ${source}`);
      } catch (error) {
        console.error(`Reconnection failed from ${source}:`, error);
      } finally {
        isReconnecting = false;
      }
    };

    // Event handlers for mobile reconnection
    const onOnline = () => {
      console.log("\u{1F4F6} Network back online event"); // Antenna Bars
      tryReconnect("network-online");
    };

    const onVisibility = () => {
      if (document.visibilityState === "visible") {
        console.log("Page visible again event");
        tryReconnect("visibility-change");
      }
    };

    const onFocus = () => {
      console.log("\u{1F3AF} Window focus event"); // Direct Hit
      tryReconnect("window-focus");
    };

    const onPageShow = (event: PageTransitionEvent) => {
      // pageshow with persisted=true indicates return from bfcache (Safari/iOS)
      const source = event.persisted ? "pageshow-bfcache" : "pageshow-normal";
      console.log(`\u{1F4C4} Page show event: ${source}`, { persisted: event.persisted }); // Page Facing Up
      tryReconnect(source);
    };

    // Handle token upgrade immediately
    handleTokenUpgrade();

    // Add event listeners
    globalThis.addEventListener("online", onOnline);
    document.addEventListener("visibilitychange", onVisibility);
    globalThis.addEventListener("focus", onFocus);
    globalThis.addEventListener("pageshow", onPageShow as EventListener);

    return () => {
      globalThis.removeEventListener("online", onOnline);
      document.removeEventListener("visibilitychange", onVisibility);
      globalThis.removeEventListener("focus", onFocus);
      globalThis.removeEventListener("pageshow", onPageShow as EventListener);
    };
  }, [
    connectionStatus.state,
    config.channelId,
    config.userToken,
    connectionResult?.type,
    connectWithToken,
    resumeWithStoredToken,
    restoreUserSession,
    connectReadOnly,
  ]);

  const toggleReaction = async (messageId: string, reaction: string, userId: string, streamId: string) => {
    await reactionService.toggleReaction(streamId, messageId, reaction, userId);
  };

  // Auto-cleanup on unmount
  useEffect(() => {
    return () => {
      const chatService = chatServiceRef.current;
      chatService.disconnect();
      stopActivityHeartbeat();
    };
  }, [stopActivityHeartbeat]);

  const ret: UseChatReturn = {
    // State
    messages,
    events,
    connectionStatus,
    currentRoom,
    isConnected: connectionStatus.state === "connected",
    canSendMessages: connectionStatus.state === "connected" && !isReadOnlyMode,
    currentUser,
    isReadOnlyMode,

    // Nickname management
    checkNicknameAvailability,
    connectWithNickName,
    connectWithToken,
    connectReadOnly,
    leaveChat,
    switchToReadOnly,

    // Actions
    sendMessage,
    sendEvent,
    deleteMessage,
    disconnectUser,
    clearMessages,
    toggleReaction,

    // Info
    roomInfo: chatServiceRef.current.getRoomInfo(),
    isLoading,
    error,
  };
  return ret;
};
