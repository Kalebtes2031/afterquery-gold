import { useCallback, useEffect, useRef, useState } from "react";

interface UseOnlinePresenceOptions {
  slug: string;
  enabled?: boolean;
}

interface UseOnlinePresenceReturn {
  viewerCount: number;
  isConnected: boolean;
  error: string | null;
}

export function useOnlinePresence(
  { slug, enabled = true }: UseOnlinePresenceOptions = { slug: "" },
): UseOnlinePresenceReturn {
  const [viewerCount, setViewerCount] = useState<number>(0);
  const [isConnected, setIsConnected] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const eventSourceRef = useRef<EventSource | null>(null);
  const heartbeatIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const visitorIdRef = useRef<string>("");

  // Get or create visitor ID
  const getVisitorId = useCallback((): string => {
    if (!visitorIdRef.current) {
      const stored = localStorage.getItem("visitorId");
      if (stored) {
        visitorIdRef.current = stored;
      } else {
        visitorIdRef.current = crypto.randomUUID();
        localStorage.setItem("visitorId", visitorIdRef.current);
      }
    }
    return visitorIdRef.current;
  }, []);

  // Send heartbeat to server
  const sendHeartbeat = useCallback(async () => {
    if (!enabled || !slug) return;

    // Don't send heartbeat if DNT is enabled
    if (navigator.doNotTrack === "1") {
      return;
    }

    const visitorId = getVisitorId();

    try {
      // Use sendBeacon if available, fallback to fetch
      if (navigator.sendBeacon) {
        const data = new Blob([JSON.stringify({ visitorId, slug })], { type: "application/json" });
        navigator.sendBeacon("/api/online/heartbeat", data);
      } else {
        await fetch("/api/online/heartbeat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ visitorId, slug }),
          keepalive: true,
        });
      }
    } catch (err) {
      console.error("Failed to send heartbeat:", err);
      setError("Failed to update presence");
    }
  }, [enabled, slug, getVisitorId]);

  // Setup SSE connection
  const setupSSE = useCallback(() => {
    if (!enabled || !slug) return;

    // Clean up existing connection
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    try {
      const eventSource = new EventSource(`/api/online/stream?slug=${encodeURIComponent(slug)}`);
      eventSourceRef.current = eventSource;

      eventSource.onopen = () => {
        setIsConnected(true);
        setError(null);
      };

      eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (event.type === "count" && typeof data === "number") {
            setViewerCount(data);
          } else if (event.type === "ping") {
            // Ping received, connection is alive
          }
        } catch {
          // Try to parse as plain text for count events
          if (event.type === "count") {
            const count = parseInt(event.data, 10);
            if (!Number.isNaN(count)) {
              setViewerCount(count);
            }
          }
        }
      };

      eventSource.onerror = () => {
        setIsConnected(false);
        setError("Connection lost. Reconnecting...");

        // Attempt to reconnect after 5 seconds
        setTimeout(() => {
          if (enabled && slug) {
            setupSSE();
          }
        }, 5000);
      };

      eventSource.addEventListener("count", (event) => {
        const count = parseInt(event.data, 10);
        if (!Number.isNaN(count)) {
          setViewerCount(count);
        }
      });

      eventSource.addEventListener("ping", () => {
        // Ping received, connection is alive
      });
    } catch (err) {
      console.error("Failed to setup SSE:", err);
      setError("Failed to connect to presence service");
      setIsConnected(false);
    }
  }, [enabled, slug]);

  useEffect(() => {
    if (!enabled || !slug) {
      // Clean up if disabled
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
        eventSourceRef.current = null;
      }
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current);
        heartbeatIntervalRef.current = null;
      }
      setIsConnected(false);
      setViewerCount(0);
      return;
    }

    // Check DNT (Do Not Track)
    const shouldTrack = navigator.doNotTrack !== "1";

    if (shouldTrack) {
      // Initialize tracking for users who allow it
      setupSSE();
      sendHeartbeat();

      // Setup heartbeat interval
      heartbeatIntervalRef.current = setInterval(sendHeartbeat, 15000);
    } else {
      // For DNT users, only listen to counts without sending heartbeats
      setupSSE();
      console.log("DNT enabled: receiving count updates without tracking");
    }

    // Cleanup on unmount
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
        eventSourceRef.current = null;
      }
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current);
        heartbeatIntervalRef.current = null;
      }
    };
  }, [slug, enabled, setupSSE, sendHeartbeat]);

  return {
    viewerCount,
    isConnected,
    error,
  };
}
