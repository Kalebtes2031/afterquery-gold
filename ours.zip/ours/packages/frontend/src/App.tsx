import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import React from "react";
import { Route, Routes, useLocation } from "react-router-dom";
import "#ours/frontend/App.css";
import { ProtectedRoute } from "#ours/frontend/components/molecules/ProtectedRoute.tsx";
import { Header } from "#ours/frontend/components/organisms/Header.tsx";
import ConnectYoutube from "#ours/frontend/components/pages/ConnectYoutube.tsx";
import CreateAccount from "#ours/frontend/components/pages/CreateAccountPage.tsx";
import { EarlySignup } from "#ours/frontend/components/pages/EarlySignup.tsx";
import EndStream from "#ours/frontend/components/pages/EndStream.tsx";
import { Home } from "#ours/frontend/components/pages/Home.tsx";
import { Login } from "#ours/frontend/components/pages/Login.tsx";
import { MyStreams } from "#ours/frontend/components/pages/MyStreams.tsx";
import { Stream } from "#ours/frontend/components/pages/Stream.tsx";
import { PerformerStreamingLayout } from "#ours/frontend/components/templates/PerformerStreamingLayout.tsx";
import { ChatProvider } from "#ours/frontend/contexts/ChatContext.tsx";
import { KeyboardProvider } from "#ours/frontend/contexts/KeyboardContext.tsx";
import { StreamProvider } from "#ours/frontend/contexts/StreamContext.tsx";

// import IVSPlayerTest from "./components/pages/IVSPlayerTest";

const queryClient = new QueryClient();

function App() {
  const location = useLocation();
  const hideHeader = ["/", "/login"].includes(location.pathname);
  return (
    <QueryClientProvider client={queryClient}>
      <KeyboardProvider>
        <StreamProvider>
          <ChatProvider backendUrl={import.meta.env.VITE_REACT_APP_API_HOST}>
            <div className="min-h-full">
              {!hideHeader && <Header />}
              <Routes>
                <Route path="/" element={<EarlySignup />} />
                <Route path="/login" element={<Login />} />
                <Route
                  path="/home"
                  element={
                    <ProtectedRoute>
                      <Home />
                    </ProtectedRoute>
                  }
                />
                <Route
                  path="/my-streams"
                  element={
                    <ProtectedRoute>
                      <MyStreams />
                    </ProtectedRoute>
                  }
                />
                <Route path="/stream/:streamId" element={<Stream />} />
                <Route path="/create-account" element={<CreateAccount />} />
                <Route path="/connect-youtube" element={<ConnectYoutube />} />
                <Route path="/end-stream" element={<EndStream />} />
                <Route path="/performer" element={<PerformerStreamingLayout />} />
              </Routes>
            </div>
          </ChatProvider>
        </StreamProvider>
      </KeyboardProvider>
    </QueryClientProvider>
  );
}

const MemoApp = React.memo(App);
MemoApp.displayName = "App";
export default MemoApp;
