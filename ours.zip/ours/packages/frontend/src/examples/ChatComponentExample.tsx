import React from "react";
import { useChatContext } from "#ours/frontend/contexts/ChatContext.tsx";

// Example of how a chat component should be updated to use the context
export const ChatComponentExample = React.memo(() => {
  // Instead of receiving these as props, get them from context
  const { messages, canSendMessages, sendMessage, isReadOnlyMode, currentUser } = useChatContext();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const message = formData.get("message") as string;

    if (message.trim()) {
      await sendMessage(message);
      e.currentTarget.reset();
    }
  };

  return (
    <div className="chat-component">
      <div className="messages">
        {messages.map((message) => (
          <div key={message.id} className="message">
            <strong>{message.username || "Anonymous"}:</strong> {message.content}
          </div>
        ))}
      </div>

      {!isReadOnlyMode && (
        <form onSubmit={handleSubmit}>
          <input type="text" name="message" placeholder="Type a message..." disabled={!canSendMessages} />
          <button type="submit" disabled={!canSendMessages}>
            Send
          </button>
        </form>
      )}

      {currentUser && <div className="user-info">Logged in as: {currentUser.nickname}</div>}
    </div>
  );
});

ChatComponentExample.displayName = "ChatComponentExample";
