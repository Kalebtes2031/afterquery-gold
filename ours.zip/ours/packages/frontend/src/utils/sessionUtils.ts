import type { UserInfo } from "#ours/frontend/types/chat.ts";

type TokenData = {
  token: string;
  userId: string;
  endpoint: string;
  tokenExpirationTime: string;
};

// Session persistence types and constants
export interface StoredUserSession {
  user: UserInfo;
  channelId: string;
  expiresAt: number;
  tokenData?: TokenData;
}

const SESSION_STORAGE_KEY = "ours_chat_session";
const SESSION_DURATION_MS = 24 * 60 * 60 * 1000; // 24 hours
const USER_TOKEN_KEY = "ours_user_token";

export const saveUserToken = (token: string): void => {
  localStorage.setItem(USER_TOKEN_KEY, token);
};

/**
 * Save user session to localStorage
 */
export const saveUserSession = (user: UserInfo, channelId: string, tokenData?: TokenData): void => {
  try {
    const session: StoredUserSession = {
      user,
      channelId,
      expiresAt: Date.now() + SESSION_DURATION_MS,
      tokenData,
    };
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    // console.log(`Session saved for ${user.nickname}, expires at:`, new Date(session.expiresAt));
  } catch (error) {
    console.warn("Failed to save user session to localStorage:", error);
  }
};

/**
 * Extend existing user session duration
 */
export const extendUserSession = (channelId: string): boolean => {
  try {
    const stored = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!stored) return false;

    const session: StoredUserSession = JSON.parse(stored);

    // Only extend if it's the same channel
    if (session.channelId !== channelId) return false;

    // Extend the session by 24 hours from now
    session.expiresAt = Date.now() + SESSION_DURATION_MS;
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));

    // console.log(`Session extended for ${session.user.nickname}, new expiry:`, new Date(session.expiresAt));
    return true;
  } catch (error) {
    console.warn("Failed to extend user session:", error);
    return false;
  }
};

/**
 * Load user session from localStorage
 */
export const loadUserSession = (channelId: string): StoredUserSession | null => {
  try {
    const stored = localStorage.getItem(SESSION_STORAGE_KEY);
    if (!stored) return null;

    const session: StoredUserSession = JSON.parse(stored);

    // Check if session is expired
    if (Date.now() > session.expiresAt) {
      localStorage.removeItem(SESSION_STORAGE_KEY);
      // console.log('Session expired for:', session.user?.nickname);
      return null;
    }

    // Check if session is for the same channel
    if (session.channelId !== channelId) {
      console.log("Session channel mismatch:", session.channelId, "!=", channelId);
      return null;
    }

    // console.log(`Session loaded for ${session.user.nickname}, expires at:`, new Date(session.expiresAt));
    return session;
  } catch (error) {
    console.warn("Failed to load user session from localStorage:", error);
    localStorage.removeItem(SESSION_STORAGE_KEY);
    return null;
  }
};

export const getUserToken = (): string | null => {
  return localStorage.getItem(USER_TOKEN_KEY);
};

/**
 * Clear user session from localStorage
 */
export const clearTemporaryUserSession = (): void => {
  localStorage.removeItem(SESSION_STORAGE_KEY);
};

export const clearUserSession = (): void => {
  localStorage.removeItem(USER_TOKEN_KEY);
};
