/**
 * Simple, typed EventEmitter implementation for managing service events
 */

type EventMap = Record<string, unknown[]>;

export class EventEmitter<Events extends EventMap = Record<string, unknown[]>> {
  private events: Map<keyof Events, Array<(...args: unknown[]) => void>> = new Map();

  on<K extends keyof Events>(event: K, callback: (...args: Events[K]) => void): void {
    if (!this.events.has(event)) {
      this.events.set(event, []);
    }
    // Store with a relaxed internal type while preserving external typing
    this.events.get(event)?.push(callback as unknown as (...args: unknown[]) => void);
  }

  off<K extends keyof Events>(event: K, callback: (...args: Events[K]) => void): void {
    const callbacks = this.events.get(event);
    if (callbacks) {
      const index = callbacks.indexOf(callback as unknown as (...args: unknown[]) => void);
      if (index > -1) {
        callbacks.splice(index, 1);
      }
    }
  }

  emit<K extends keyof Events>(event: K, ...args: Events[K]): void {
    const callbacks = this.events.get(event);
    if (callbacks) {
      callbacks.forEach((callback) => {
        callback(...(args as unknown[]));
      });
    }
  }

  removeAllListeners<K extends keyof Events>(event?: K): void {
    if (event) {
      this.events.delete(event);
    } else {
      this.events.clear();
    }
  }
}
