type GifType = "png" | "gif" | "emoji" | "avatar";

export type GifItem = {
  id: string;
  url: string;
  type: GifType;
};

type GifsData = {
  clubEmotes: GifItem[];
  gifs: GifItem[];
};

export const gifsData: GifsData = {
  clubEmotes: [
    {
      id: "low_rider",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/low_rider_112.png",
      type: "png",
    },
    {
      id: "chicano_dog",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/sneak_chicano_dog_bbb_112.png",
      type: "png",
    },
    {
      id: "graffiti_what",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/sneak_graffiti_what_112.png",
      type: "png",
    },
    {
      id: "lowrider_levelup",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/sneak_lowrider_levelup_112.png",
      type: "png",
    },
    {
      id: "lowrider_orange",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/sneak_Lowrider_Orange_112.png",
      type: "png",
    },
    {
      id: "twerking_chicano",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/sneak_twerking_chicano_112.png",
      type: "png",
    },
    {
      id: "twerking_weed",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/sneak_twerking_weed_112.png",
      type: "png",
    },
    {
      id: "chibi_smile",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/ours/ours_chibi_smile_112.png",
      type: "png",
    },
    {
      id: "black_left",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/black_left_112.png",
      type: "png",
    },
    {
      id: "black_right",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/black_right_112.png",
      type: "png",
    },
    {
      id: "brown_left",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/brown_left_112.png",
      type: "png",
    },
    {
      id: "brown_right",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/brown_right_112.png",
      type: "png",
    },
    {
      id: "chancla",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/chancla_112.gif",
      type: "gif",
    },
    {
      id: "clapping",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/clapping_112.gif",
      type: "gif",
    },
    {
      id: "cry",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/cry_112.gif",
      type: "gif",
    },
    {
      id: "get_clapped",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/get_clapped_112.png",
      type: "png",
    },
    {
      id: "gg_gif",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/gg_112.gif",
      type: "gif",
    },
    {
      id: "gg_png",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/gg_112.png",
      type: "png",
    },
    {
      id: "happy",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/happy_112.gif",
      type: "gif",
    },
    {
      id: "happy_and_sad",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/happy_and_sad_112.gif",
      type: "gif",
    },
    {
      id: "harold",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/harold_112.gif",
      type: "gif",
    },
    {
      id: "heart",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/heart_112.gif",
      type: "gif",
    },
    {
      id: "hi",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/hi_112.gif",
      type: "gif",
    },
    {
      id: "hype",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/hype_112.png",
      type: "png",
    },
    {
      id: "hype_v1",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/hype_v1_112.gif",
      type: "gif",
    },
    {
      id: "hype_v2",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/hype_v2_112.gif",
      type: "gif",
    },
    {
      id: "hype_v3",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/hype_v3_112.gif",
      type: "gif",
    },
    {
      id: "italian_hands",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/italian_hands_112.gif",
      type: "gif",
    },
    {
      id: "lighter",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/lighter_112.gif",
      type: "gif",
    },
    {
      id: "lol_guy",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/lol_guy_112.gif",
      type: "gif",
    },
    {
      id: "mic_drop",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/mic_drop_112.gif",
      type: "gif",
    },
    {
      id: "money",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/money_112.gif",
      type: "gif",
    },
    {
      id: "not_sure",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/not_sure_112.gif",
      type: "gif",
    },
    {
      id: "oke",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/oke_112.gif",
      type: "gif",
    },
    {
      id: "oof",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/oof_112.png",
      type: "png",
    },
    {
      id: "party",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/party_112.gif",
      type: "gif",
    },
    {
      id: "pikachu",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/pikachu_112.gif",
      type: "gif",
    },
    {
      id: "rage_gif",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/rage_112.gif",
      type: "gif",
    },
    {
      id: "rage_png",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/rage_112.png",
      type: "png",
    },
    {
      id: "rip",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/rip_112.gif",
      type: "gif",
    },
    {
      id: "rock_on",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/rock_on_112.gif",
      type: "gif",
    },
    {
      id: "rock_on_hand_only",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/rock_on_hand_only_112.gif",
      type: "gif",
    },
    {
      id: "sad",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/sad_112.gif",
      type: "gif",
    },
    {
      id: "sad_2",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/sad_112_gif_2.gif",
      type: "gif",
    },
    {
      id: "shame_bell",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/shame_bell_112.gif",
      type: "gif",
    },
    {
      id: "sheeesh",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/sheeesh_112.png",
      type: "png",
    },
    {
      id: "shock",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/shock_112.gif",
      type: "gif",
    },
    {
      id: "sip",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/sip_112.gif",
      type: "gif",
    },
    {
      id: "slow_clapping",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/slow_clapping_112.gif",
      type: "gif",
    },
    {
      id: "spray_bottle",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/spray_bottle_112.gif",
      type: "gif",
    },
    {
      id: "sus_cat",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/sus_cat_112.gif",
      type: "gif",
    },
    {
      id: "sus_guy",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/sus_guy_112.gif",
      type: "gif",
    },
    {
      id: "thinking",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/thinking_112.gif",
      type: "gif",
    },
    {
      id: "thumbs_up",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/thumbs_up_112.gif",
      type: "gif",
    },
    {
      id: "touch_grass",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/touch_grass_112.gif",
      type: "gif",
    },
    {
      id: "white_left",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/white_left_112.png",
      type: "png",
    },
    {
      id: "white_monkey",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/white_monkey_112.gif",
      type: "gif",
    },
    {
      id: "white_right",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/white_right_112.png",
      type: "png",
    },
    {
      id: "wtf",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/misc/wtf_112.gif",
      type: "gif",
    },
    {
      id: "bass",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/bass.gif",
      type: "gif",
    },
    {
      id: "tenor",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/tenor.gif",
      type: "gif",
    },
    {
      id: "edm_bass",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/edm_bass.gif",
      type: "gif",
    },
    {
      id: "david_guetta",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/david_guetta_techno.gif",
      type: "gif",
    },
    {
      id: "friday_night_dancing",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/friday_night_dancing_iwon.gif",
      type: "gif",
    },
    {
      id: "grooving_dancing",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/grooving_dancing_soul_train.gif",
      type: "gif",
    },
    {
      id: "soul_train_dancing",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/soul_train_dancing.gif",
      type: "gif",
    },
    {
      id: "twerk",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/twerk.gif",
      type: "gif",
    },
    {
      id: "twerk_second",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/twerk2.gif",
      type: "gif",
    },
    {
      id: "bounce_wink",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/bounce_wink.gif",
      type: "gif",
    },
    {
      id: "dance_littlekingdoms",
      url: "https://s3.us-east-2.amazonaws.com/assets.our.space.test1/emotes/sneak/dance_dancing_littlekingdoms.gif",
      type: "gif",
    },
  ],
  gifs: [
    {
      id: "baby-yoda",
      url: "https://media.giphy.com/media/Wn74RUT0vjnoU98Hnt/giphy.gif",
      type: "gif",
    },
    {
      id: "excited",
      url: "https://media.giphy.com/media/5GoVLqeAOo6PK/giphy.gif",
      type: "gif",
    },
    {
      id: "dancing",
      url: "https://media.giphy.com/media/l0MYt5jPR6QX5pnqM/giphy.gif",
      type: "gif",
    },
    {
      id: "thumbs-up",
      url: "https://media.giphy.com/media/111ebonMs90YLu/giphy.gif",
      type: "gif",
    },
    {
      id: "panda",
      url: "https://media.giphy.com/media/EatwJZRUIv41G/giphy.gif",
      type: "gif",
    },
    {
      id: "cute",
      url: "https://media.giphy.com/media/3oEjI6SIIHBdRxXI40/giphy.gif",
      type: "gif",
    },
  ],
};
