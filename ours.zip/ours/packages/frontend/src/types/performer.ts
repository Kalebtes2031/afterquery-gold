// types/index.ts - All type definitions in one place

// Stream related types
export interface Stream {
  id: string;
  title: string;
  description: string;
  isLive: boolean;
  startedAt: string;
  viewerCount: number;
  performerName: string;
  performerAvatar: string;
  clubName: string;
}

export interface PaymentMethod {
  id: string;
  name: string;
  enabled: boolean;
  icon?: string;
}

// Chat related types
export interface ChatMessage {
  id: string;
  userId: string;
  username: string;
  message: string;
  timestamp: string;
  reactions: Reaction[];
  isArtist?: boolean;
  mediaUrl?: string;
}

export interface Reaction {
  type: "heart" | "fire" | "hands" | "music" | "sad";
  count: number;
}

// Member related types
export interface Member {
  id: string;
  username: string;
  joinedDate: string;
  avatar?: string;
  isOnline?: boolean;
}

// Component Props types
export interface HeaderProps {
  notificationCount?: number;
  userAvatar: string;
  userName: string;
  memberCount: string;
}

export interface StreamStatusProps {
  isLive: boolean;
  startTime: string;
  className?: string;
}

export interface PerformerPanelProps {
  streamTitle: string;
  streamDescription: string;
  streamUrl: string;
  isLive: boolean;
  startTime: string;
  paymentMethods: PaymentMethod[];
}

export interface ChatInterfaceProps {
  clubName: string;
  isOnline: boolean;
  messages: ChatMessage[];
  onSendMessage: (message: string) => void;
}

export interface MembersPanelProps {
  members: Member[];
  viewerCount: number;
  onEndStream: () => void;
}
