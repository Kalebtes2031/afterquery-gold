import type { CHAT_CHANNEL_ROLES, CHAT_USER_TYPES } from "#ours/frontend/constants/index.ts";

// Chat types
export type UserType = (typeof CHAT_USER_TYPES)[keyof typeof CHAT_USER_TYPES];
export type ChannelRole = (typeof CHAT_CHANNEL_ROLES)[keyof typeof CHAT_CHANNEL_ROLES];

export interface StreamComponentProps {
  streamId: string;
}

export interface Stream {
  id?: number;
  streamName: string;
  unlistedId?: string;
  title: string;
  streamType?: "youtube" | "vimeo" | "ivs";
  hasPassword: boolean;
  createdAt?: string;
  requiresPassword?: boolean;
  paymentMethods?: Array<{
    paymentType: "venmo" | "cashapp" | "paypal";
    handle: string;
  }>;
  // IVS-specific fields
  ivsPlaybackUrl?: string;
  ivsIngestEndpoint?: string;
  ivsStreamKey?: string;
}

export interface LiveChatCardProps {
  hostName: string;
  streamTitle?: string;
  roomId?: string;
  streamId?: string;
}

export interface HashTagData {
  label: string;
}

export interface HashTagsProps {
  hashTags: HashTagData[];
}

export interface FundsAvailableProps {
  amount: string | number;
}

export interface ButtonProps {
  handleClick?: () => void;
  label?: string;
  labelSm?: string;
  disabled?: boolean;
  children?: React.ReactNode;
  loading?: boolean;
  className?: string;
}

export interface NavigationProps {
  param: string;
}

export type InputChangeHandler = (e: React.ChangeEvent<HTMLInputElement>) => void;
export type FormSubmitHandler = (e: React.FormEvent<HTMLFormElement>) => void;

export interface IconProps {
  reactIconClass: string;
}

export interface FormFieldProps {
  label: string;
  type: string;
  name?: string;
  placeholder?: string;
  caption?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

export interface ChatMessage {
  id: string;
  userId: string;
  username?: string;
  content: string;
  message?: string;
  timestamp: string;
  streamId?: string;
  attributes?: Record<string, string>;
  sender?: {
    userId: string;
    attributes?: Record<string, string>;
  };
}

export interface IvsChatConnection {
  connected: boolean;
  connecting: boolean;
  error: string | null;
}

export type IvsChatEventHandlers = {
  onConnect: () => void;
  onDisconnect: () => void;
  onMessageReceived: (message: ChatMessage) => void;
  onMessageSent: (message: ChatMessage) => void;
  onRoomJoined: (roomArn: string) => void;
  onRoomLeft: (roomArn: string) => void;
  onError: (error: string) => void;
};
