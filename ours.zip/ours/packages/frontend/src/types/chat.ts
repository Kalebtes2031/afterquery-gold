export interface UserInfo {
  id: string;
  nickname: string;
  type: string;
  isRegistered: boolean;
  chatUserId: string;
}

export interface ChatConfig {
  backendUrl: string;
  channelId: string;
  userToken?: string;
  expectRegistered?: boolean;
  clerkLoaded?: boolean;
}
