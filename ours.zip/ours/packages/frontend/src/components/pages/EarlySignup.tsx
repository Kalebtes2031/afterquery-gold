import React from "react";
import { EarlySignupTemplate } from "#ours/frontend/components/templates/EarlySignupTemplate.tsx";
export const EarlySignup = React.memo(() => {
  return (
    <div className="rounded-lg min-w-[300px] min-h-[200px]">
      <EarlySignupTemplate />
    </div>
  );
});

EarlySignup.displayName = "EarlySignup";
