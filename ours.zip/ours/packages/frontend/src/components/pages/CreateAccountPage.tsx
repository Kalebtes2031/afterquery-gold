import React from "react";
import { CreateAccountTemplate } from "../templates/CreateAccountTemplate";

export const CreateAccount = React.memo(() => {
  return <CreateAccountTemplate />;
});

CreateAccount.displayName = "CreateAccount";

export default CreateAccount;
