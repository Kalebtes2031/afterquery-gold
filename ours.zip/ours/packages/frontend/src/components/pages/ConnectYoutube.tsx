import React from "react";
import { ConnectYoutubeTemplate } from "../templates/ConnectYoutubeTemplate";

const ConnectYoutube = React.memo(() => {
  return (
    <div className="rounded-lg min-w-[300px] min-h-[200px]">
      <ConnectYoutubeTemplate />
    </div>
  );
});
ConnectYoutube.displayName = "ConnectYoutube";
export default ConnectYoutube;
