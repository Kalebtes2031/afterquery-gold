// Pages/EndStream.tsx
import React from "react";
import { EndStreamTemplate } from "../templates/EndStreamTemplate";

export const EndStream = React.memo(() => {
  return (
    <div className="rounded-lg min-w-[300px] min-h-[200px]">
      <EndStreamTemplate />
    </div>
  );
});

EndStream.displayName = "EndStream";

export default EndStream;
