import { useAuth } from "@clerk/clerk-react";
import { useQuery } from "@tanstack/react-query";
import axios from "axios";
import { useState } from "react";
import { StreamCard } from "#ours/frontend/components/molecules/StreamCard.tsx";
import { createSlug } from "#ours/frontend/utils/utils.ts";

interface Stream {
  id: number;
  streamName: string;
  unlistedId: string;
  title: string;
  streamType: "youtube" | "vimeo" | "ivs";
  hasPassword: boolean;
  paymentMethods?: Array<{
    paymentType: "venmo" | "cashapp" | "paypal";
    handle: string;
  }>;
  createdAt: string;
  ivsIngestEndpoint?: string;
  ivsStreamKey?: string;
  ivsPlaybackUrl?: string;
}

interface ApiResponse {
  success: true;
  streams: Stream[];
}

export function MyStreams() {
  const { getToken } = useAuth();
  const [isCreating, setIsCreating] = useState(false);
  const [title, setTitle] = useState("");
  const [streamName, setStreamName] = useState("");
  const [streamType, setStreamType] = useState<"youtube" | "vimeo" | "ivs">("vimeo");
  const [copiedStreamId, setCopiedStreamId] = useState<number | null>(null);
  const [deletingStreamId, setDeletingStreamId] = useState<number | null>(null);
  const [venmoHandle, setVenmoHandle] = useState("");
  const [cashappHandle, setCashappHandle] = useState("");
  const [paypalHandle, setPaypalHandle] = useState("");
  const [createdIvsStream, setCreatedIvsStream] = useState<Stream | null>(null);
  const [showStreamKey, setShowStreamKey] = useState(false);
  const [expandedIvsStream, setExpandedIvsStream] = useState<number | null>(null);
  const [copiedCredential, setCopiedCredential] = useState<string | null>(null);

  const handleTitleChange = (value: string) => {
    setTitle(value);
    setStreamName(createSlug(value));
  };

  const handleCopyLink = async (streamName: string, streamId: number) => {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/stream/${streamName}`);
      setCopiedStreamId(streamId);

      // Reset after 2 seconds
      setTimeout(() => {
        setCopiedStreamId(null);
      }, 2000);
    } catch (error) {
      console.error("Failed to copy to clipboard:", error);
    }
  };

  const handleCopyCredential = async (text: string, credentialType: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCredential(credentialType);
      setTimeout(() => {
        setCopiedCredential(null);
      }, 2000);
    } catch (error) {
      console.error("Failed to copy to clipboard:", error);
    }
  };

  const handleToggleIvsCredentials = (streamId: number) => {
    setExpandedIvsStream(expandedIvsStream === streamId ? null : streamId);
  };

  const handleDeleteStream = async (name: string, id: number) => {
    if (!window.confirm("Delete this stream? This cannot be undone.")) return;
    setDeletingStreamId(id);
    try {
      const token = await getToken();
      await axios.delete(`/api/streams/${name}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      await refetch();
    } catch (error) {
      console.error("Error deleting stream:", error);
      alert("Failed to delete stream. Please try again.");
    } finally {
      setDeletingStreamId(null);
    }
  };

  const fetchMyStreams = async (): Promise<Stream[]> => {
    const token = await getToken();
    const response = await axios.get<ApiResponse>(`/api/streams/my-streams`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    return response.data.streams;
  };

  const {
    data: streams,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ["my-streams"],
    queryFn: fetchMyStreams,
  });

  const handleCreateStream = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsCreating(true);

    const form = event.currentTarget;
    const formData = new FormData(form);
    const paymentMethods = [];
    if (venmoHandle) paymentMethods.push({ paymentType: "venmo" as const, handle: venmoHandle });
    if (cashappHandle) paymentMethods.push({ paymentType: "cashapp" as const, handle: cashappHandle });
    if (paypalHandle) paymentMethods.push({ paymentType: "paypal" as const, handle: paypalHandle });

    const streamData = {
      streamName: streamName,
      unlistedId: formData.get("unlistedId") as string,
      title: title,
      streamType: streamType,
      password: (formData.get("password") as string) || undefined,
      paymentMethods: paymentMethods.length > 0 ? paymentMethods : undefined,
    };

    try {
      const token = await getToken();
      const response = await axios.post(`/api/streams`, streamData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      // If IVS stream, save the credentials to display
      if (streamType === "ivs" && response.data.stream) {
        setCreatedIvsStream(response.data.stream);
      }

      // Reset form and state
      form.reset();
      setTitle("");
      setStreamName("");
      setStreamType("vimeo");
      setVenmoHandle("");
      setCashappHandle("");
      setPaypalHandle("");
      await refetch();
    } catch (error) {
      console.error("Error creating stream:", error);
      alert("Failed to create stream. Please try again.");
    } finally {
      setIsCreating(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-bg flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-fg mb-4">Error Loading Streams</h2>
          <p className="text-fg-subtle mb-4">Failed to load your streams.</p>
          <button
            type="button"
            onClick={() => refetch()}
            className="bg-black hover:bg-gray-800 text-white px-4 py-2 rounded-md transition-colors duration-200"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-fg">My Streams</h1>
          <p className="mt-2 text-sm text-fg-subtle">Manage your streaming content and view analytics.</p>
        </div>

        {/* Create New Stream Form */}
        <div className="bg-surface border border-border-dark rounded-lg shadow-sm mb-8">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-fg mb-4">Create New Stream</h3>
            <form onSubmit={handleCreateStream} className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-fg">
                    Stream Title
                  </label>
                  <input
                    type="text"
                    name="title"
                    id="title"
                    required
                    value={title}
                    onChange={(e) => handleTitleChange(e.target.value)}
                    placeholder="My Awesome Stream"
                    className="mt-1 block w-full border border-border-dark bg-surface-2 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-colors text-fg placeholder:text-fg-subtle"
                  />
                </div>
                <div>
                  <label htmlFor="streamName" className="block text-sm font-medium text-fg">
                    Stream Name (URL)
                  </label>
                  <input
                    type="text"
                    name="streamName"
                    id="streamName"
                    required
                    value={streamName}
                    onChange={(e) => setStreamName(e.target.value)}
                    pattern="[a-z0-9-]+"
                    placeholder="auto-generated-from-title"
                    className="mt-1 block w-full border border-border-dark bg-surface-2 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-colors text-fg placeholder:text-fg-subtle"
                  />
                  <p className="mt-1 text-xs text-fg-subtle">Auto-generated from title, or edit manually</p>
                </div>
                <div>
                  <label htmlFor="streamType" className="block text-sm font-medium text-fg">
                    Stream Type
                  </label>
                  <select
                    name="streamType"
                    id="streamType"
                    value={streamType}
                    onChange={(e) => setStreamType(e.target.value as "youtube" | "vimeo" | "ivs")}
                    className="mt-1 block w-full border border-border-dark bg-surface-2 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-colors text-fg"
                  >
                    <option value="vimeo">Vimeo</option>
                    <option value="youtube">YouTube</option>
                    <option value="ivs">IVS (Live Streaming)</option>
                  </select>
                </div>
                {streamType !== "ivs" && (
                  <div>
                    <label htmlFor="unlistedId" className="block text-sm font-medium text-fg">
                      {streamType === "youtube" ? "YouTube Video ID" : "Vimeo URL or Video ID"}
                    </label>
                    <input
                      type="text"
                      name="unlistedId"
                      id="unlistedId"
                      required
                      placeholder={
                        streamType === "youtube"
                          ? "dQw4w9WgXcQ"
                          : "https://vimeo.com/event/1234567/abcdef123 or 123456789"
                      }
                      className="mt-1 block w-full border border-border-dark bg-surface-2 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-colors text-fg placeholder:text-fg-subtle"
                    />
                    {streamType === "vimeo" && (
                      <p className="mt-1 text-xs text-fg-subtle">
                        For live events, paste the full URL (e.g., https://vimeo.com/event/123/abc)
                      </p>
                    )}
                  </div>
                )}
                {streamType === "ivs" && (
                  <div className="col-span-2">
                    <div className="bg-blue-900/20 border border-blue-700/50 rounded-lg p-4">
                      <p className="text-sm text-blue-200">
                        📡 <strong>IVS Live Streaming</strong> - Stream credentials will be generated automatically. Use
                        them with OBS, Wirecast, or any RTMP streaming software.
                      </p>
                    </div>
                  </div>
                )}
                <div>
                  <label htmlFor="password" className="block text-sm font-medium text-fg">
                    Password (optional)
                  </label>
                  <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="Leave empty for public stream"
                    className="mt-1 block w-full border border-border-dark bg-surface-2 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-colors text-fg placeholder:text-fg-subtle"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="text-sm font-medium text-fg">Payment Methods (optional)</h4>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label htmlFor="venmo" className="block text-sm font-medium text-fg">
                      Venmo Handle
                    </label>
                    <input
                      type="text"
                      name="venmo"
                      id="venmo"
                      value={venmoHandle}
                      onChange={(e) => setVenmoHandle(e.target.value)}
                      placeholder="your-venmo"
                      className="mt-1 block w-full border border-border-dark bg-surface-2 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-colors text-fg placeholder:text-fg-subtle"
                    />
                  </div>
                  <div>
                    <label htmlFor="cashapp" className="block text-sm font-medium text-fg">
                      Cash App Handle
                    </label>
                    <input
                      type="text"
                      name="cashapp"
                      id="cashapp"
                      value={cashappHandle}
                      onChange={(e) => setCashappHandle(e.target.value)}
                      placeholder="$your-cashapp"
                      className="mt-1 block w-full border border-border-dark bg-surface-2 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-colors text-fg placeholder:text-fg-subtle"
                    />
                  </div>
                  <div>
                    <label htmlFor="paypal" className="block text-sm font-medium text-fg">
                      PayPal Handle
                    </label>
                    <input
                      type="text"
                      name="paypal"
                      id="paypal"
                      value={paypalHandle}
                      onChange={(e) => setPaypalHandle(e.target.value)}
                      placeholder="paypal handle"
                      className="mt-1 block w-full border border-border-dark bg-surface-2 rounded-lg px-3 py-2 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-colors text-fg placeholder:text-fg-subtle"
                    />
                  </div>
                </div>
              </div>
              <div>
                <button
                  type="submit"
                  disabled={isCreating}
                  className="inline-flex items-center justify-center px-6 py-3 text-sm font-semibold rounded-lg text-primary-900 !bg-primary-200 hover:!bg-primary-300 focus:outline-none focus:ring-2 focus:ring-primary-400 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-md hover:shadow-lg"
                >
                  {isCreating ? "Creating..." : "Create Stream"}
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* IVS Credentials Modal */}
        {createdIvsStream && (
          <div className="bg-surface border border-border-dark rounded-lg shadow-sm mb-8">
            <div className="px-4 py-5 sm:p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg leading-6 font-medium text-fg">🎉 IVS Stream Created!</h3>
                <button
                  type="button"
                  onClick={() => setCreatedIvsStream(null)}
                  className="text-fg-subtle hover:text-fg"
                >
                  ✕
                </button>
              </div>
              <p className="text-sm text-fg-subtle mb-4">
                Copy these credentials to your streaming software (OBS, Wirecast, etc.)
              </p>

              <div className="space-y-3">
                {/* RTMP URL */}
                <div>
                  <label htmlFor="created-rtmp-url" className="block text-xs font-medium text-fg mb-1">
                    RTMP Server URL
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="created-rtmp-url"
                      type="text"
                      readOnly
                      value={`rtmps://${createdIvsStream.ivsIngestEndpoint}:443/app/`}
                      className="flex-1 px-3 py-2 bg-surface-2 border border-border-dark rounded-lg text-fg text-sm font-mono"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        handleCopyCredential(`rtmps://${createdIvsStream.ivsIngestEndpoint}:443/app/`, "created-rtmp")
                      }
                      className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-sm"
                    >
                      {copiedCredential === "created-rtmp" ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>

                {/* Stream Key */}
                <div>
                  <label htmlFor="created-stream-key" className="block text-xs font-medium text-fg mb-1">
                    Stream Key (Secret)
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="created-stream-key"
                      type={showStreamKey ? "text" : "password"}
                      readOnly
                      value={createdIvsStream.ivsStreamKey || "Not available - check console"}
                      className="flex-1 px-3 py-2 bg-surface-2 border border-border-dark rounded-lg text-fg text-sm font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowStreamKey(!showStreamKey)}
                      className="px-4 py-2 bg-neutral-700 hover:bg-neutral-600 text-white rounded-lg text-sm"
                    >
                      {showStreamKey ? "Hide" : "Show"}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (createdIvsStream.ivsStreamKey) {
                          handleCopyCredential(createdIvsStream.ivsStreamKey, "created-key");
                        }
                      }}
                      disabled={!createdIvsStream.ivsStreamKey}
                      className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {copiedCredential === "created-key" ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>

                {/* Playback URL */}
                <div>
                  <label htmlFor="created-playback-url" className="block text-xs font-medium text-fg mb-1">
                    Playback URL (for viewers)
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="created-playback-url"
                      type="text"
                      readOnly
                      value={createdIvsStream.ivsPlaybackUrl || ""}
                      className="flex-1 px-3 py-2 bg-surface-2 border border-border-dark rounded-lg text-fg text-sm font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => handleCopyCredential(createdIvsStream.ivsPlaybackUrl || "", "created-playback")}
                      className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-sm"
                    >
                      {copiedCredential === "created-playback" ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>
              </div>

              <div className="mt-4 p-3 bg-yellow-900/20 border border-yellow-700/50 rounded-lg">
                <p className="text-xs text-yellow-200">
                  ⚠️ <strong>Important:</strong> Save these credentials! The stream key won't be shown again for security
                  reasons.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Streams List */}
        <div className="bg-surface border border-border-dark rounded-lg shadow-sm">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-fg mb-4">Your Streams ({streams?.length || 0})</h3>

            {!streams || streams.length === 0 ? (
              <div className="text-center py-12">
                <svg
                  className="mx-auto h-12 w-12 text-fg-subtle"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  aria-hidden="true"
                >
                  <path
                    vectorEffect="non-scaling-stroke"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
                  />
                </svg>
                <h3 className="mt-2 text-sm font-medium text-fg">No streams</h3>
                <p className="mt-1 text-sm text-fg-subtle">Get started by creating your first stream.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {streams.map((stream) => (
                  <StreamCard
                    key={stream.id}
                    stream={stream}
                    copiedStreamId={copiedStreamId}
                    deletingStreamId={deletingStreamId}
                    expandedIvsStream={expandedIvsStream}
                    copiedCredential={copiedCredential}
                    onCopyLink={handleCopyLink}
                    onDeleteStream={handleDeleteStream}
                    onToggleIvsCredentials={handleToggleIvsCredentials}
                    onCopyCredential={handleCopyCredential}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

MyStreams.displayName = "MyStreams";
