import React from "react";
import { HomeTemplate } from "#ours/frontend/components/templates/HomeTemplate.tsx";
export const Home = React.memo(() => {
  return (
    <div className="rounded-lg min-w-[300px] min-h-[200px]">
      <HomeTemplate />
    </div>
  );
});

Home.displayName = "Home";
