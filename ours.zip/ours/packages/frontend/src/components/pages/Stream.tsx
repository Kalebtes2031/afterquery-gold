import React from "react";
import { useParams } from "react-router-dom";
import { StreamTemplate } from "#ours/frontend/components/templates/StreamTemplate.tsx";

export const Stream = React.memo(() => {
  const { streamId } = useParams<{ streamId: string }>();

  if (!streamId) {
    return <div>Stream not found</div>;
  }

  const StreamTemplateProps = {
    streamId: streamId,
  };
  return (
    <div className="rounded-lg min-w-[300px] min-h-[200px]">
      <StreamTemplate {...StreamTemplateProps} />
    </div>
  );
});

Stream.displayName = "Stream";
