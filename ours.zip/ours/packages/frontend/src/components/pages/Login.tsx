import { SignIn, useAuth } from "@clerk/clerk-react";
import { dark } from "@clerk/themes";
import { Navigate } from "react-router-dom";

export function Login() {
  const { isSignedIn } = useAuth();

  // Redirect to home if already signed in
  if (isSignedIn) {
    return <Navigate to="/my-streams" replace />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-bg py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="flex flex-col items-center">
          <h2 className="mt-6 text-center text-3xl font-extrabold text-fg">Sign in to OURS</h2>
          <p className="mt-2 text-center text-sm text-fg-subtle">Access your streaming dashboard</p>
        </div>
        <div className="mt-8 flex justify-center">
          <SignIn
            redirectUrl="/my-streams"
            appearance={{
              baseTheme: dark,
              elements: {
                formButtonPrimary: "bg-indigo-600 hover:bg-indigo-700 text-sm normal-case",
              },
            }}
          />
        </div>
      </div>
    </div>
  );
}

Login.displayName = "Login";
