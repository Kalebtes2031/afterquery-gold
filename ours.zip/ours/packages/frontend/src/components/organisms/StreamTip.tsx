import React from "react";
import { TipOptions } from "#ours/frontend/components/molecules/TipOptions.tsx";
import { TipSubmitForm } from "#ours/frontend/components/molecules/TipSubmitForm.tsx";

export const StreamTip = React.memo(() => {
  return (
    <section>
      <div className="text-stone-800 shadow-lg border-stone-200 border  rounded-lg min-w-[300px]">
        <TipOptions />
        <TipSubmitForm />
      </div>
    </section>
  );
});
StreamTip.displayName = "StreamTip";
