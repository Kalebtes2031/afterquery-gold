import GraphemeSplitter from "grapheme-splitter";
import React, { useCallback, useEffect, useRef } from "react";
import { FiSend } from "react-icons/fi";
import { EmojiPopover } from "#ours/frontend/components/molecules/EmojiPopover.tsx";
import { GifPicker } from "#ours/frontend/components/molecules/GifPicker.tsx";
import { useKeyboard } from "#ours/frontend/contexts/KeyboardContext.tsx";
import { gifsData } from "#ours/frontend/data/gifs.ts";
import type { UserInfo } from "#ours/frontend/types/chat.ts";

const splitter = new GraphemeSplitter();

interface ActiveChatBoxRefactoredProps {
  newMessage: string | null;
  canSendMessages: boolean;
  currentUser: UserInfo | null;
  getInputStyle: {
    backgroundColor: string;
    color?: string;
  };
  getButtonStyle: {
    backgroundColor: string;
    color: string;
  };
  handleMessageChange: (value: string) => void;
  handleReceiveInput: (e: React.FormEvent) => void;
  closeChatConnection: () => void;
}

export const ActiveChatBoxRefactored = React.memo(
  ({
    newMessage,
    canSendMessages,
    currentUser,
    getInputStyle,
    getButtonStyle,
    handleMessageChange,
    handleReceiveInput,
    closeChatConnection: _closeChatConnection,
  }: ActiveChatBoxRefactoredProps) => {
    const editorRef = useRef<HTMLDivElement>(null);
    const lastRawValueRef = useRef<string>("");
    const { inputFocused, isMobile, setInputFocused } = useKeyboard();

    const hasValidContent = useCallback((message: string | null): boolean => {
      if (!message) return false;
      let contentWithoutMedia = message.replace(/\[GIF:[^\]]+\]/g, "");
      contentWithoutMedia = contentWithoutMedia.replace(/\[EMOTE:[^\]]+\]/g, "");
      return contentWithoutMedia.trim().length > 0;
    }, []);

    const getTextLength = useCallback((message: string | null): number => {
      if (!message) return 0;

      const contentWithoutMedia = message.replace(/\[GIF:[^\]]+\]/g, "").replace(/\[EMOTE:[^\]]+\]/g, "");

      return splitter.countGraphemes(contentWithoutMedia);
    }, []);

    // Convert raw string to HTML for display
    const rawToHtml = useCallback((raw: string): string => {
      if (!raw) return "";

      let html = raw;

      // Handle GIFs
      html = html.replace(/\[GIF:(https?:\/\/[^\]]+)\]/g, (_, url) => {
        return `<img src="${url}" data-type="gif" alt="GIF" class="block max-h-20 mx-1 rounded object-cover" />`;
      });

      // Handle Emotes
      html = html.replace(/\[EMOTE:([^\]]+)\]/g, (match, emoteId) => {
        const emote = gifsData.clubEmotes.find((e) => e.id === emoteId);
        if (emote) {
          return `<img src="${emote.url}" data-type="emote" data-emote-id="${emoteId}" alt="Emote" class="inline h-6 w-auto mx-1" />`;
        }
        return match;
      });

      // Convert newlines to <br>
      html = html.replace(/\n/g, "<br>");

      return html;
    }, []);

    // Helper function to process DOM nodes for HTML to raw conversion
    const processNodeToRaw = useCallback((node: Node, rawAccumulator: { value: string }): void => {
      if (node.nodeType === Node.TEXT_NODE) {
        rawAccumulator.value += node.textContent || "";
      } else if (node.nodeType === Node.ELEMENT_NODE) {
        const element = node as Element;

        if (element.tagName === "IMG") {
          const dataType = element.getAttribute("data-type");
          if (dataType === "gif") {
            const src = element.getAttribute("src");
            rawAccumulator.value += `[GIF:${src}]`;
          } else if (dataType === "emote") {
            const emoteId = element.getAttribute("data-emote-id");
            rawAccumulator.value += `[EMOTE:${emoteId}]`;
          }
        } else if (element.tagName === "BR") {
          rawAccumulator.value += "\n";
        } else {
          // Process child nodes for other elements
          for (let i = 0; i < element.childNodes.length; i++) {
            processNodeToRaw(element.childNodes[i], rawAccumulator);
          }
        }
      }
    }, []);

    // Convert HTML back to raw string
    const htmlToRaw = useCallback(
      (html: string): string => {
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = html;

        const rawAccumulator = { value: "" };

        for (let i = 0; i < tempDiv.childNodes.length; i++) {
          processNodeToRaw(tempDiv.childNodes[i], rawAccumulator);
        }

        return rawAccumulator.value;
      },
      [processNodeToRaw],
    );

    // Auto-resize function
    const adjustHeight = useCallback(() => {
      if (!editorRef.current) return;

      editorRef.current.style.height = "36px";
      const scrollHeight = editorRef.current.scrollHeight;
      const newHeight = Math.min(Math.max(scrollHeight, 36), 144);
      editorRef.current.style.height = `${newHeight}px`;
      editorRef.current.style.overflowY = newHeight >= 144 ? "auto" : "hidden";
    }, []);

    const attachMediaListeners = useCallback(() => {
      if (!editorRef.current) return;

      const images = editorRef.current.querySelectorAll<HTMLImageElement>(
        'img[data-type="gif"], img[data-type="emote"]',
      );
      images.forEach((img) => {
        if (img.dataset.loadHandled === "true") {
          return;
        }

        img.dataset.loadHandled = "true";

        if (img.complete) {
          adjustHeight();
        } else {
          img.addEventListener("load", adjustHeight, { once: true });
          img.addEventListener("error", adjustHeight, { once: true });
        }
      });
    }, [adjustHeight]);

    // Handle input changes
    const handleInput = useCallback((): void => {
      if (!editorRef.current) return;

      const rawValue = htmlToRaw(editorRef.current.innerHTML);

      // Check max length
      if (getTextLength(rawValue) > 500) {
        // Revert to previous content
        editorRef.current.innerHTML = rawToHtml(lastRawValueRef.current);
        return;
      }

      lastRawValueRef.current = rawValue;
      adjustHeight();
      handleMessageChange(rawValue);
      attachMediaListeners();
    }, [htmlToRaw, rawToHtml, handleMessageChange, adjustHeight, getTextLength, attachMediaListeners]);

    // Insert content at cursor position
    const insertAtCursor = useCallback(
      (html: string): void => {
        if (!editorRef.current) return;

        const selection = window.getSelection();
        if (!selection) return;

        let range: Range;
        if (selection.rangeCount > 0) {
          range = selection.getRangeAt(0);
        } else {
          range = document.createRange();
          range.selectNodeContents(editorRef.current);
          range.collapse(false);
        }

        // Delete any selected content
        range.deleteContents();

        // Create a temporary container for the HTML
        const tempDiv = document.createElement("div");
        tempDiv.innerHTML = html;

        // Insert each child node
        while (tempDiv.firstChild) {
          range.insertNode(tempDiv.firstChild);
          range.collapse(false);
        }

        selection.removeAllRanges();
        selection.addRange(range);

        requestAnimationFrame(() => {
          attachMediaListeners();
          adjustHeight();
        });

        // Trigger input event
        handleInput();
      },
      [handleInput, attachMediaListeners, adjustHeight],
    );

    // Handle GIF selection
    const handleGifSelect = useCallback(
      (gif: string) => {
        let html: string;
        if (gif.startsWith("[EMOTE:") || gif.startsWith("[Avatar:")) {
          // Parse emote format
          if (gif.startsWith("[EMOTE:")) {
            const emoteId = gif.match(/\[EMOTE:([^\]]+)\]/)?.[1];
            if (emoteId) {
              const emote = gifsData.clubEmotes.find((e) => e.id === emoteId);
              if (emote) {
                html = `<img src="${emote.url}" data-type="emote" data-emote-id="${emoteId}" alt="Emote" class="inline h-6 w-auto mx-1" />`;
              } else {
                return;
              }
            } else {
              return;
            }
          } else {
            // Handle avatar format if needed
            return;
          }
        } else {
          // Direct GIF URL
          html = `<img src="${gif}" data-type="gif" alt="GIF" class="block max-h-20 mx-1 rounded object-cover" />`;
        }

        editorRef.current?.focus();
        insertAtCursor(html);
      },
      [insertAtCursor],
    );

    const handleEmojiSelect = useCallback(
      (emoji: string) => {
        editorRef.current?.focus();
        insertAtCursor(emoji);
      },
      [insertAtCursor],
    );

    const resolveGifViaApi = useCallback((rawUrl: string): Promise<string | null> => {
      return fetch(`/api/gifs/resolve?url=${encodeURIComponent(rawUrl)}`)
        .then((response) => {
          if (!response.ok) {
            throw new Error("Failed to resolve gif");
          }
          return response.json() as Promise<{ result?: { url?: string } }>;
        })
        .then((payload) => {
          const gifUrl = payload.result?.url;
          if (typeof gifUrl === "string" && gifUrl.trim() !== "") {
            return gifUrl;
          }
          return null;
        })
        .catch(() => null);
    }, []);

    // Update content when newMessage prop changes
    useEffect(() => {
      if (editorRef.current && newMessage !== lastRawValueRef.current) {
        const html = rawToHtml(newMessage || "");
        editorRef.current.innerHTML = html;
        lastRawValueRef.current = newMessage || "";

        // Auto-resize
        adjustHeight();
        attachMediaListeners();
      }
    }, [newMessage, rawToHtml, adjustHeight, attachMediaListeners]);

    // Handle key events
    const handleKeyDown = useCallback(
      (e: React.KeyboardEvent) => {
        if (e.key === "Enter" && !e.shiftKey) {
          e.preventDefault();
          if (!hasValidContent(newMessage) && !newMessage?.trim()) {
            return;
          }
          handleReceiveInput(e);
        }
      },
      [handleReceiveInput, hasValidContent, newMessage],
    );

    // Handle paste events to clean up pasted content
    const handlePaste = useCallback(
      async (e: React.ClipboardEvent) => {
        e.preventDefault();
        const text = e.clipboardData.getData("text/plain");

        const escapeHtml = (segment: string) =>
          segment
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#39;");

        const escapeAttribute = (value: string) =>
          value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

        const convertNewLines = (value: string) => value.replace(/\r?\n/g, "<br>");

        const urlRegex = /(https?:\/\/[\w-.~:/?#[\]@!$&'()*+,;=%]+)/gi;
        const matches = Array.from(text.matchAll(urlRegex));

        if (matches.length === 0) {
          insertAtCursor(convertNewLines(escapeHtml(text)));
          return;
        }

        const tokens = matches.flatMap((match, index) => {
          const start = match.index ?? 0;
          const end = start + match[0].length;
          const previousMatch = index === 0 ? null : matches[index - 1];
          const previousEnd = previousMatch ? (previousMatch.index ?? 0) + previousMatch[0].length : 0;
          const leading = text.slice(previousEnd, start);
          const pieces: Array<{ type: "text" | "url"; value: string }> = [];
          if (leading !== "") {
            pieces.push({ type: "text", value: leading });
          }
          pieces.push({ type: "url", value: match[0] });
          if (index === matches.length - 1) {
            const trailing = text.slice(end);
            if (trailing !== "") {
              pieces.push({ type: "text", value: trailing });
            }
          }
          return pieces;
        });

        const fragments = await Promise.all(
          tokens.map((token) => {
            if (token.type === "url") {
              return resolveGifViaApi(token.value).then((resolved) => {
                if (resolved) {
                  const safeGifUrl = escapeAttribute(resolved);
                  return `<img src="${safeGifUrl}" data-type="gif" alt="GIF" class="block max-h-20 mx-1 rounded object-cover" />`;
                }
                return convertNewLines(escapeHtml(token.value));
              });
            }
            return Promise.resolve(convertNewLines(escapeHtml(token.value)));
          }),
        );

        const html = fragments.join("");
        insertAtCursor(html !== "" ? html : convertNewLines(escapeHtml(text)));
      },
      [insertAtCursor, resolveGifViaApi],
    );

    return (
      <div
        className={`bg-[#09090B] p-4 z-10 ${
          inputFocused && isMobile
            ? "fixed left-0 right-0 z-[70] rounded-none"
            : "relative -mt-[30px] rounded-t-2xl rounded-b-xl"
        } sm:relative sm:rounded-t-2xl sm:rounded-b-xl sm:-mt-28`}
        style={inputFocused && isMobile ? { bottom: 0, zIndex: 70 } : undefined}
      >
        <div className="space-y-2">
          <form onSubmit={handleReceiveInput} className="flex gap-2 items-end mt-3 mb-2">
            <div
              ref={editorRef}
              contentEditable={canSendMessages}
              suppressContentEditableWarning={true}
              data-placeholder="Chat with the club ..."
              className="flex-1 bg-zinc-700 border border-zinc-600 rounded-lg px-2 py-1 text-white 
                        focus:outline-none focus:border-blue-500 disabled:opacity-50 resize-none 
                        overflow-wrap-break-word text-left overflow-hidden w-0
                        empty:before:content-[attr(data-placeholder)] 
                        empty:before:text-gray-400 
                        empty:before:pointer-events-none empty:before:text-left"
              style={{
                ...getInputStyle,
                minHeight: "36px",
                maxHeight: "144px",
                maxWidth: "100%",
              }}
              onInput={handleInput}
              onFocus={() => isMobile && setInputFocused(true)}
              onBlur={() => isMobile && setInputFocused(false)}
              onKeyDown={handleKeyDown}
              onPaste={handlePaste}
            />
            <button
              type="submit"
              disabled={!canSendMessages || (!hasValidContent(newMessage) && !newMessage?.trim())}
              className="px-4 py-2 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed sm:px-4 px-3 sm:py-1 py-1 self-end flex items-center gap-2"
              style={{
                ...getButtonStyle,
                minHeight: "36px",
              }}
              onMouseDown={(e) => {
                if (isMobile) {
                  e.preventDefault();
                  // Trigger form submission immediately
                  const form = e.currentTarget.closest("form");
                  if (form) {
                    const submitEvent = new Event("submit", { bubbles: true, cancelable: true });
                    form.dispatchEvent(submitEvent);
                  }
                  setTimeout(() => {
                    if (editorRef.current) {
                      editorRef.current.blur();
                    }
                    setInputFocused(false);
                  }, 0);
                } else {
                  if (editorRef.current) {
                    editorRef.current.blur();
                  }
                }
              }}
            >
              Send
              <FiSend className="w-4 h-4" />
            </button>
          </form>

          {currentUser && (
            <div className="flex justify-between items-center text-xs text-gray-400 flex-row gap-1">
              <div className="flex items-center gap-2">
                <span>
                  Chatting as - <span style={{ color: "#D4F8CC" }}>{currentUser.nickname}</span>
                </span>
              </div>
              <span></span>
              <div className="flex items-center gap-4 sm:gap-1 gap-1">
                <GifPicker onGifSelect={handleGifSelect} />
                <EmojiPopover onEmojiSelect={handleEmojiSelect} />
              </div>
              <span style={{ color: getTextLength(newMessage) >= 500 ? "#FCA5A5" : "inherit" }}>
                {getTextLength(newMessage)}/500
              </span>
            </div>
          )}
        </div>
      </div>
    );
  },
);

ActiveChatBoxRefactored.displayName = "ActiveChatBoxRefactored";
