import React, { useRef } from "react";
import { ChatInputRenderer } from "#ours/frontend/components/molecules/ChatInputRenderer.tsx";
import { useKeyboard } from "#ours/frontend/contexts/KeyboardContext.tsx";

interface ReadOnlyChatIntroProps {
  hostName: string;
  newMessage: string | null;
  getInputStyle: {
    backgroundColor: string;
    color?: string;
  };
  getButtonStyle: {
    backgroundColor: string;
    color: string;
  };
  handleMessageChange: (value: string) => void;
  handleReceiveInput: (e: React.FormEvent) => void;
}

export const ReadOnlyChatIntro = React.memo(
  ({
    hostName,
    newMessage,
    getInputStyle,
    getButtonStyle,
    handleMessageChange,
    handleReceiveInput,
  }: ReadOnlyChatIntroProps) => {
    const { inputFocused, isMobile, setInputFocused } = useKeyboard();
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    return (
      <div
        className={`bg-[#09090B] p-4 relative z-10 sm:p-4 transition-all duration-300 ${
          inputFocused && isMobile
            ? "relative left-0 right-0 z-[70] rounded-t-2xl rounded-b-xl"
            : "-mt-28 rounded-t-2xl rounded-b-xl"
        }`}
        style={{
          ...(inputFocused &&
            isMobile && {
              bottom: 0,
              marginTop: 0,
              zIndex: 70,
            }),
        }}
      >
        <div className="flex flex-col items-center justify-center space-y-1 mb-3">
          <h2 className="font-bold text-lg sm:text-lg" style={{ color: "#D4F8CC" }}>
            Welcome to DJ {hostName}'s Club!
          </h2>
          <p className="text-sm text-gray-400">Choose a handle to Join the conversation</p>
        </div>

        <div className="space-y-2">
          <form onSubmit={handleReceiveInput} className="flex gap-2 items-end mt-3 mb-2">
            {newMessage && (newMessage.includes("[GIF:") || newMessage.includes("[EMOTE:")) ? (
              <div className="flex-1 relative">
                <ChatInputRenderer
                  message={newMessage}
                  className="bg-zinc-700 border border-zinc-600 rounded-lg px-2 py-1"
                  style={{
                    ...getInputStyle,
                    minHeight: "36px",
                  }}
                  placeholder="Enter your handle ..."
                />
                <textarea
                  value={newMessage || ""}
                  onChange={(e) => handleMessageChange(e.target.value)}
                  className="absolute inset-0 opacity-0 bg-transparent border-0 resize-none w-full h-full"
                  disabled={false}
                  maxLength={500}
                  onFocus={() => isMobile && setInputFocused(true)}
                  onBlur={() => isMobile && setInputFocused(false)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      handleReceiveInput(e);
                    }
                  }}
                />
              </div>
            ) : (
              <textarea
                ref={textareaRef}
                value={newMessage || ""}
                onChange={(e) => handleMessageChange(e.target.value)}
                placeholder="Enter your handle ..."
                disabled={false}
                maxLength={500}
                rows={1}
                className="flex-1 bg-zinc-700 border border-zinc-600 rounded-lg px-2 py-1 text-white placeholder-gray-400 focus:outline-none focus:border-blue-500 disabled:opacity-50 resize-none overflow-hidden"
                style={{
                  ...getInputStyle,
                  height: "36px",
                }}
                onFocus={(e) => {
                  if (isMobile) {
                    setInputFocused(true);
                    // Scroll textarea into view above keyboard
                    setTimeout(() => {
                      e.target.scrollIntoView({
                        behavior: "smooth",
                        block: "center",
                      });
                    }, 300);
                  }
                }}
                onBlur={() => isMobile && setInputFocused(false)}
                onInput={(e) => {
                  const target = e.target as HTMLTextAreaElement;
                  target.style.height = "36px";
                  target.style.height = `${Math.min(target.scrollHeight, 36)}px`;
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleReceiveInput(e);
                  }
                }}
              />
            )}
            <button
              type="submit"
              disabled={false}
              className="px-4 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              style={{
                ...getButtonStyle,
                height: "36px",
              }}
              onClick={() => {
                if (textareaRef.current) {
                  textareaRef.current.blur();
                }
                if (isMobile) {
                  setInputFocused(false);
                }
              }}
            >
              <div className="flex items-center gap-2">Start Chatting</div>
            </button>
          </form>
        </div>
      </div>
    );
  },
);

ReadOnlyChatIntro.displayName = "ReadOnlyChatIntro";
