import { useAuth } from "@clerk/clerk-react";
import React, { useState } from "react";
import { FiMenu, FiVideo, FiX } from "react-icons/fi";
import { Link } from "react-router-dom";
import logo from "#ours/frontend/assets/logo.svg";
import { UserProfile } from "#ours/frontend/components/molecules/UserProfile.tsx";

export const Header = React.memo(() => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { isSignedIn } = useAuth();

  return (
    <header className="text-fg bg-surface h-header relative z-[9999]">
      <div className="h-full w-full px-6">
        <div className="flex items-center justify-between h-full">
          <img src={logo} alt="Ours" className="h-10 w-auto" />

          <div className="hidden md:flex items-center space-x-6">
            {isSignedIn && (
              <div className="flex items-center space-x-6">
                <Link
                  to="/my-streams"
                  className="hover:opacity-80 transition-opacity text-fg flex items-center space-x-1"
                >
                  <FiVideo className="h-5 w-5 text-fg" />
                </Link>
              </div>
            )}

            <div className="flex items-center space-x-3">
              {/*<button type="button" className="p-1.5 hover:opacity-80 transition-opacity">
                <FiMessageCircle className="h-5 w-5 text-fg" />
              </button>
              <button type="button" className="relative p-1.5 hover:opacity-80 transition-opacity">
                <FiBell className="h-5 w-5 text-fg" />
                <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 rounded-full flex items-center justify-center text-xs font-medium">
                  6
                </span>
                </button> */}

              <UserProfile />
            </div>
          </div>
          <button type="button" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="md:hidden p-2">
            {isMobileMenuOpen ? <FiX className="h-6 w-6 text-fg" /> : <FiMenu className="h-6 w-6 text-fg" />}
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden py-4 px-6 border-t border-border-dark bg-black absolute top-full left-0 right-0 z-[9999]">
            <nav className="space-y-3 mb-4">
              <Link to="/home" className="block hover:opacity-80 transition-opacity text-fg">
                Home
              </Link>
              {isSignedIn && (
                <Link to="/my-streams" className="block hover:opacity-80 transition-opacity text-fg">
                  My Streams
                </Link>
              )}
            </nav>

            <div className="pt-4 border-t border-border-dark">
              <div className="flex items-center justify-between">
                <UserProfile />

                {/*<div className="flex items-center space-x-2">
                  <button type="button" className="p-1.5 hover:opacity-80 transition-opacity">
                    <FiMessageCircle className="h-5 w-5 text-fg" />
                  </button>
                  <button type="button" className="relative p-1.5 hover:opacity-80 transition-opacity">
                    <FiBell className="h-5 w-5 text-fg" />
                    <span className="absolute -top-0.5 -right-0.5 h-4 w-4 bg-red-500 rounded-full flex items-center justify-center text-xs font-medium">
                      6
                    </span>
                  </button>
                </div>*/}
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
});

Header.displayName = "Header";

export default Header;
