import React, { useState } from "react";
import { ShareDialog } from "#ours/frontend/components/molecules/ShareDialog.tsx";
import { StreamInfo } from "#ours/frontend/components/molecules/StreamInfo.tsx";
import { VideoPlayer } from "#ours/frontend/components/molecules/VideoPlayer.tsx";
import type { Stream } from "#ours/frontend/types/index.ts";

interface StreamSectionProps {
  streamData: Stream;
}

export const StreamSection = React.memo<StreamSectionProps>(({ streamData }) => {
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  return (
    <section className="w-full md:basis-[65%] md:max-w-[65%] xl:basis-[60%] xl:max-w-[60%] flex flex-col h-full min-h-0">
      <div className="flex flex-col gap-3 mb-4 sm:gap-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
            <h1 className="text-lg sm:text-2xl font-medium text-gray-300 truncate">{streamData.title}</h1>
            <div className="bg-red-600 px-2 py-1 rounded flex items-center gap-2 flex-shrink-0">
              <span className="text-white text-sm font-medium">Live</span>
              <div className="flex items-center gap-0.5">
                <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></div>
                <div
                  className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"
                  style={{ animationDelay: "0.2s" }}
                ></div>
                <div
                  className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"
                  style={{ animationDelay: "0.4s" }}
                ></div>
              </div>
            </div>
          </div>
          <div className="flex-shrink-0 ml-4">
            <ShareDialog open={isShareModalOpen} onOpenChange={setIsShareModalOpen} />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <VideoPlayer
          videoId={streamData.unlistedId || "dQw4w9WgXcQ"}
          streamName={streamData.streamName}
          streamType={streamData.streamType}
          ivsPlaybackUrl={streamData.ivsPlaybackUrl}
        />
        <StreamInfo streamTitle={streamData.title} paymentMethods={streamData.paymentMethods} />
      </div>
    </section>
  );
});

StreamSection.displayName = "StreamSection";

export default StreamSection;
