import React from "react";
import { StreamPlayer } from "#ours/frontend/components/molecules/StreamPlayer.tsx";
import type { StreamComponentProps } from "#ours/frontend/types/index.ts";

export const StreamVideoCard = React.memo(({ streamId }: StreamComponentProps) => {
  return (
    <section>
      <div className="rounded-lg min-w-[300px] min-h-[700px]">
        <StreamPlayer streamId={streamId} />
      </div>
    </section>
  );
});
StreamVideoCard.displayName = "StreamVideoCard";
