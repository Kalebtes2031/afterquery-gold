import { Check, Copy, DollarSign, Edit2, Settings, X } from "lucide-react";
import React, { useState } from "react";
import { StreamStatus } from "#ours/frontend/components/molecules/StreamStatus";
import { Button } from "#ours/frontend/components/ui/button";
import { Card, CardContent, CardHeader } from "#ours/frontend/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "#ours/frontend/components/ui/dialog";
import { Input } from "#ours/frontend/components/ui/input";
import { Label } from "#ours/frontend/components/ui/label";
import { Textarea } from "#ours/frontend/components/ui/textarea";
import type { PerformerPanelProps } from "#ours/frontend/types/performer.ts";
import { cn } from "#ours/frontend/utils/utils.ts";

export const PerformerPanel = React.memo(
  ({
    streamTitle: initialTitle,
    streamDescription: initialDescription,
    streamUrl: initialUrl,
    isLive,
    startTime,
    paymentMethods,
  }: PerformerPanelProps) => {
    const [title, setTitle] = useState(initialTitle);
    const [description, setDescription] = useState(initialDescription);
    const [url, setUrl] = useState(initialUrl);
    const [showCopyNotification, setShowCopyNotification] = useState(false);
    const [showEditDialog, setShowEditDialog] = useState(false);

    const [tempTitle, setTempTitle] = useState(title);
    const [tempDescription, setTempDescription] = useState(description);
    const [tempUrl, setTempUrl] = useState(url);

    const handleCopy = () => {
      navigator.clipboard.writeText(url);
      setShowCopyNotification(true);
      setTimeout(() => setShowCopyNotification(false), 2000);
    };

    const handleSaveChanges = () => {
      setTitle(tempTitle);
      setDescription(tempDescription);
      setUrl(tempUrl);
      setShowEditDialog(false);
    };

    const handleOpenDialog = () => {
      setTempTitle(title);
      setTempDescription(description);
      setTempUrl(url);
      setShowEditDialog(true);
    };

    return (
      <div className="flex flex-col h-full bg-zinc-900">
        <StreamStatus isLive={isLive} startTime={startTime} />
        <div className="aspect-video bg-black">
          <iframe
            src={url}
            className="w-full h-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            title="Performer Stream"
          />
        </div>
        <div className="p-4 space-y-3">
          <div className="flex items-center gap-2">
            <h2 className="flex-1 text-white font-medium">{title}</h2>
            <div className="relative">
              <Button variant="ghost" size="icon" onClick={handleCopy} className="hover:bg-zinc-800">
                <Copy className="w-4 h-4 text-zinc-400" />
              </Button>
              {showCopyNotification && (
                <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-zinc-800 text-white text-xs px-3 py-1.5 rounded-md whitespace-nowrap shadow-lg">
                  Link copied!
                </div>
              )}
            </div>
            <Button variant="ghost" size="icon" onClick={handleOpenDialog} className="hover:bg-zinc-800">
              <Edit2 className="w-4 h-4 text-zinc-400" />
            </Button>
          </div>
          <p className="text-sm text-zinc-400">{description}</p>
        </div>
        <div className="p-4">
          <Card className="bg-transparent border-zinc-800">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-green-500/10 rounded-full flex items-center justify-center">
                    <DollarSign className="w-4 h-4 text-green-500" />
                  </div>
                  <span className="text-white font-medium">Tipping Methods</span>
                </div>
                <Button variant="ghost" size="icon" className="hover:bg-zinc-800">
                  <Settings className="w-4 h-4 text-zinc-400" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                {paymentMethods.map((method) => (
                  <Button
                    key={method.id}
                    variant={method.enabled ? "secondary" : "ghost"}
                    className={cn(
                      "justify-center",
                      method.enabled
                        ? "bg-zinc-800 hover:bg-zinc-700 text-white"
                        : "bg-zinc-900 hover:bg-zinc-800 text-zinc-500",
                    )}
                  >
                    <span className="text-sm font-medium">{method.name}</span>
                    {method.enabled && <Check className="ml-2 w-4 h-4 text-green-500" />}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white max-w-lg" showCloseButton={false}>
            <DialogHeader>
              <div className="flex items-center justify-between">
                <DialogTitle className="text-white">Edit Stream Details</DialogTitle>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowEditDialog(false)}
                  className="hover:bg-zinc-800 -mr-2"
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </DialogHeader>

            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="stream-url" className="text-sm text-zinc-300">
                  YouTube Live Stream URL
                </Label>
                <Input
                  id="stream-url"
                  type="text"
                  value={tempUrl}
                  onChange={(e) => setTempUrl(e.target.value)}
                  placeholder="https://youtube.com/watch?v=..."
                  className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stream-title" className="text-sm text-zinc-300">
                  Stream Title
                </Label>
                <Input
                  id="stream-title"
                  type="text"
                  value={tempTitle}
                  onChange={(e) => setTempTitle(e.target.value)}
                  placeholder="Eg:- Sneak's Friday Night Mix"
                  className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stream-description" className="text-sm text-zinc-300">
                  Stream Description (optional)
                </Label>
                <Textarea
                  id="stream-description"
                  value={tempDescription}
                  onChange={(e) => setTempDescription(e.target.value)}
                  placeholder="Enter stream description here ..."
                  className="bg-zinc-800 border-zinc-700 text-white placeholder:text-zinc-500 min-h-[120px] resize-none"
                />
              </div>

              <div className="flex justify-end pt-4">
                <Button onClick={handleSaveChanges} className="bg-green-500 hover:bg-green-600 text-white">
                  Save Changes
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  },
);

PerformerPanel.displayName = "PerformerPanel";
