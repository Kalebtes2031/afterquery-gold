import { useEffect, useRef, useState } from "react";

interface IVSPlayerProps {
  playbackUrl: string;
  autoplay?: boolean;
  muted?: boolean;
  className?: string;
}

// Simple CDN approach - no bundler complexity
const PLAYER_VERSION = "1.46.0";
const PLAYER_SCRIPT_URL = `https://player.live-video.net/${PLAYER_VERSION}/amazon-ivs-player.min.js`;

declare global {
  interface Window {
    IVSPlayer?: {
      isPlayerSupported: boolean;
      create: () => IVSPlayerInstance;
      PlayerState: Record<string, string>;
      PlayerEventType: Record<string, string>;
    };
  }
}

interface IVSPlayerInstance {
  attachHTMLVideoElement: (element: HTMLVideoElement) => void;
  load: (url: string) => void;
  setAutoplay: (autoplay: boolean) => void;
  setMuted: (muted: boolean) => void;
  addEventListener: (event: string, handler: (data?: unknown) => void) => void;
  removeEventListener: (event: string, handler: () => void) => void;
  delete: () => void;
}

export function IVSPlayer({ playbackUrl, autoplay = true, muted = false, className = "" }: IVSPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const playerRef = useRef<IVSPlayerInstance | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let player: IVSPlayerInstance | null = null;
    let isMounted = true;

    const initPlayer = async () => {
      try {
        if (!window.IVSPlayer) {
          await new Promise<void>((resolve, reject) => {
            const existingScript = document.querySelector(`script[src="${PLAYER_SCRIPT_URL}"]`);
            if (existingScript) {
              existingScript.addEventListener("load", () => resolve());
              return;
            }

            const script = document.createElement("script");
            script.src = PLAYER_SCRIPT_URL;
            script.async = true;
            script.onload = () => resolve();
            script.onerror = () => reject(new Error("Failed to load IVS Player"));
            document.head.appendChild(script);
          });
        }

        if (!isMounted || !videoRef.current) return;

        const IVS = window.IVSPlayer;

        if (!IVS || !IVS.isPlayerSupported) {
          throw new Error("IVS Player not supported in this browser");
        }

        // Create player - CDN version handles WASM automatically
        player = IVS.create();
        player.attachHTMLVideoElement(videoRef.current);

        player.addEventListener(IVS.PlayerState.PLAYING, () => {
          console.log("Player is playing");
          setIsLoading(false);
          setError(null);
        });

        player.addEventListener(IVS.PlayerState.BUFFERING, () => {
          console.log("Player is buffering");
          setIsLoading(true);
        });

        player.addEventListener(IVS.PlayerState.IDLE, () => {
          console.log("Player is idle");
          setIsLoading(false);
        });

        player.addEventListener(IVS.PlayerEventType.ERROR, (err?: unknown) => {
          console.error("Player error:", err);
          const errorMessage =
            err && typeof err === "object" && "message" in err ? String(err.message) : "Playback error";
          setError(errorMessage);
          setIsLoading(false);
        });

        player.addEventListener(IVS.PlayerEventType.INITIALIZED, () => {
          console.log("Player initialized");
        });

        player.load(playbackUrl);
        player.setAutoplay(autoplay);
        player.setMuted(muted);

        playerRef.current = player;
      } catch (err: unknown) {
        console.error("Failed to initialize player:", err);
        const errorMessage =
          err && typeof err === "object" && "message" in err ? String(err.message) : "Failed to initialize player";
        setError(errorMessage);
        setIsLoading(false);
      }
    };

    initPlayer();

    return () => {
      isMounted = false;
      if (player) {
        player.delete();
      }
      playerRef.current = null;
    };
  }, [playbackUrl, autoplay, muted]);

  return (
    <div className={`relative ${className}`}>
      {isLoading && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-10">
          <div className="text-white">Loading stream...</div>
        </div>
      )}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black z-10">
          <div className="text-red-500 p-4 text-center">
            <p className="font-semibold">Error</p>
            <p className="text-sm">{error}</p>
          </div>
        </div>
      )}
      <video ref={videoRef} className="w-full h-full bg-black" playsInline controls muted={muted} />
    </div>
  );
}

IVSPlayer.displayName = "IVSPlayer";
