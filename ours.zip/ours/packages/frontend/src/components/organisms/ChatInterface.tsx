import { Film, Flame, Frown, Heart, Music, Send, Smile } from "lucide-react";
import React, { useState } from "react";
import { Badge } from "#ours/frontend/components/ui/badge";
import { Button } from "#ours/frontend/components/ui/button";
import { Input } from "#ours/frontend/components/ui/input";
import type { ChatInterfaceProps, ChatMessage } from "#ours/frontend/types/performer.ts";
import { cn } from "#ours/frontend/utils/utils.ts";

const ReactionButton = ({
  icon: Icon,
  count,
}: {
  icon: React.ComponentType<{ className?: string }>;
  count: number;
  type: string;
}) => (
  <Button variant="ghost" size="sm" className="h-8 px-2 bg-transparent hover:bg-zinc-800 text-zinc-400">
    <Icon className="w-4 h-4 mr-1" />
    <span className="text-xs">{count}</span>
  </Button>
);

const MessageCard = ({ message }: { message: ChatMessage }) => {
  const reactionIcons = {
    heart: Heart,
    fire: Flame,
    music: Music,
    sad: Frown,
  };

  return (
    <div className="bg-zinc-700 rounded-lg p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-white font-medium">{message.username}</span>
          {message.isArtist && (
            <Badge variant="outline" className="bg-green-500/20 text-green-400 border-green-500/50 text-xs">
              ARTIST
            </Badge>
          )}
        </div>
        <span className="text-xs text-zinc-300">{message.timestamp}</span>
      </div>
      {message.mediaUrl && <img src={message.mediaUrl} alt="Media" className="w-full rounded-md" />}
      <p className="text-white">{message.message}</p>
      <div className="flex items-center gap-2">
        {message.reactions.map((reaction) => (
          <ReactionButton
            key={reaction.type}
            icon={reactionIcons[reaction.type as keyof typeof reactionIcons] || Heart}
            count={reaction.count}
            type={reaction.type}
          />
        ))}
      </div>
    </div>
  );
};

const demoMessages: ChatMessage[] = [
  {
    id: "1",
    userId: "1",
    username: "DJ_Sneak",
    message: "Welcome everyone! Ready for an amazing night?",
    timestamp: "10:30 PM",
    isArtist: true,
    mediaUrl: "/panda-dj.jpg",
    reactions: [
      { type: "heart", count: 2 },
      { type: "fire", count: 1 },
      { type: "music", count: 0 },
      { type: "sad", count: 0 },
    ],
  },
  {
    id: "2",
    userId: "2",
    username: "MusicLover",
    message: "Oof! Been waiting all week for this",
    timestamp: "10:33 PM",
    reactions: [
      { type: "heart", count: 1 },
      { type: "fire", count: 0 },
      { type: "music", count: 0 },
      { type: "sad", count: 0 },
    ],
  },
  {
    id: "3",
    userId: "3",
    username: "PartyGoer",
    message: "Let’s gooo! \u{1F525}", // Fire
    timestamp: "10:34 PM",
    reactions: [
      { type: "heart", count: 0 },
      { type: "fire", count: 2 },
      { type: "music", count: 1 },
      { type: "sad", count: 0 },
    ],
  },
];

export const ChatInterface = React.memo(({ clubName, isOnline }: Pick<ChatInterfaceProps, "clubName" | "isOnline">) => {
  const [message, setMessage] = useState("");
  const maxChars = 500;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const text = e.target.value;
    if (text.length <= maxChars) {
      setMessage(text);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      setMessage("");
    }
  };

  return (
    <div className="flex flex-col h-full bg-zinc-800 mt-6 rounded-2xl">
      <div className="px-6 py-4 border-b border-zinc-700 flex-shrink-0">
        <div className="flex items-center gap-2">
          <h2 className="text-xl font-bold text-white">{clubName}</h2>
          {isOnline && (
            <Badge variant="outline" className="gap-1.5 border-green-500/50 text-green-400">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              Online
            </Badge>
          )}
        </div>
        <p className="text-sm text-zinc-400 mt-1">Welcome to Club Chat!</p>
      </div>
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {demoMessages.map((msg) => (
          <MessageCard key={msg.id} message={msg} />
        ))}
      </div>
      <div className="p-4 border-t border-zinc-700 bg-zinc-950 flex-shrink-0">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Input
              type="text"
              value={message}
              onChange={handleInputChange}
              onKeyPress={handleKeyPress}
              placeholder="Chat with the club..."
              className="w-full bg-zinc-900 border-zinc-700 text-white pr-20 focus:ring-zinc-600"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-zinc-800">
                <Film className="w-4 h-4 text-zinc-500" />
              </Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-zinc-800">
                <Smile className="w-4 h-4 text-zinc-500" />
              </Button>
            </div>
          </div>
          <Button
            className={cn(
              "gap-2",
              message.trim() ? "bg-green-500 hover:bg-green-600 text-white" : "bg-zinc-700 text-zinc-500",
            )}
            disabled={!message.trim()}
          >
            Send
            <Send className="w-4 h-4" />
          </Button>
        </div>
        <div className="mt-2 text-xs text-zinc-500">
          {message.length}/{maxChars}
        </div>
      </div>
    </div>
  );
});
ChatInterface.displayName = "ChatInterface";
