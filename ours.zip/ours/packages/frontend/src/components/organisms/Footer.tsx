import React from "react";
import { FaInstagram } from "react-icons/fa";
import { Link } from "react-router-dom";

export const Footer = React.memo(() => {
  const instagramLink = "https://www.instagram.com/what_is_ours/";
  const instagramAccount = "what_is_ours";
  const copyrightText = `© ${new Date().getFullYear()} OURS. All Rights Reserved`;
  return (
    <footer className="p-4">
      <hr className="h-px my-8 bg-gray-200 border-0 dark:bg-gray-700" />
      <div className="grid grid-cols-3 gap-4">
        <div className="md:col-span-1 col-span-3 text-left">
          <Link to="/">Privacy Policy</Link>
        </div>
        <div className="md:col-span-1 col-span-3 lg:text-center md:text-left sm:text-left">
          <Link to={instagramLink} target="_blank">
            <span className="inline-block text-2xl relative ">
              <FaInstagram />
            </span>
            <span className="inline-block px-1  align-top">@{instagramAccount}</span>
          </Link>
        </div>
        <div className="md:col-span-1 col-span-3 lg:text-right sm:text-left sm:text-left">{copyrightText}</div>
      </div>
    </footer>
  );
});
Footer.displayName = "Footer";
