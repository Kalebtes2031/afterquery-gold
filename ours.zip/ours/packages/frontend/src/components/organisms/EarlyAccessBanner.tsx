import React from "react";
import earlyAccessBanner from "#ours/frontend/assets/earlyAccessBanner.png";
import { ScrollIcon } from "#ours/frontend/components/atoms/Icons.tsx";
import { WhatIsOursLogo } from "#ours/frontend/components/atoms/WhatIsOursLogo.tsx";

export const EarlyAccessBanner = React.memo(() => {
  const subTitle = "The Future is OURS";

  return (
    <section>
      <div
        style={{ backgroundImage: `url(${earlyAccessBanner})` }}
        className={
          "h-full content-center min-h-lvh text-neutral-100 bg-neutral-900 overflow-y-auto bg-cover bg-center bg-no-repeat"
        }
      >
        <div className="m-auto mb-4 grid gap-2 overflow-y-hidden text-center relative top-[-50px]">
          <span className="m-auto lg:scale-100 md:scale-85 sm:scale-85 scale-85 transition duration-300 ease-in-out">
            <WhatIsOursLogo />
          </span>
          <div className="m-auto w-full lg:text-6xl py-10 md:text-5xl sm:text-3xl">
            <div>
              <span className="font-black">OUR</span> Music, <span className="font-black">OUR</span> Scene.
            </div>
          </div>
          <span className="m-auto font-medium text-4xl lg:scale-100 md:scale-85 sm:scale-65 scale-85">{subTitle}</span>
        </div>
      </div>
      <div className="relative m-auto w-50 h-20 bottom-50 p-4">
        <div className="absolute bottom-0 m-auto">
          <span className="inline-block align-middle bg-neutral-900 rounded-4xl animate-pulse ">
            <ScrollIcon />
          </span>
          <span className="inline-block align-middle pl-4">Scroll to Join</span>
        </div>
      </div>
    </section>
  );
});
EarlyAccessBanner.displayName = "EarlyAccessBanner";
