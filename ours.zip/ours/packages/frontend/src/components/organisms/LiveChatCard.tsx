import React, { useCallback, useEffect, useRef, useState } from "react";
import { FiArrowDown } from "react-icons/fi";
import { KeyboardOverlay } from "#ours/frontend/components/atoms/KeyboardOverlay.tsx";
import { ChatMessage } from "#ours/frontend/components/molecules/ChatMessage.tsx";
import { NicknameEntry } from "#ours/frontend/components/molecules/NicknameEntry.tsx";
import { ActiveChatBoxRefactored } from "#ours/frontend/components/organisms/ActiveChatBox.tsx";
import { ReadOnlyChatIntro } from "#ours/frontend/components/organisms/ReadOnlyChatIntro.tsx";
import { useChatContext } from "#ours/frontend/contexts/ChatContext.tsx";
import { useStreamContext } from "#ours/frontend/contexts/StreamContext.tsx";
import type { LiveChatCardProps } from "#ours/frontend/types/index.ts";
import { clearTemporaryUserSession, clearUserSession } from "#ours/frontend/utils/sessionUtils.ts";
import { invalidNicknameMessage, isValidNickname } from "#ours/shared/inputValidation.ts";

export const LiveChatCard = React.memo(({ hostName, streamId }: LiveChatCardProps) => {
  const [newMessage, setNewMessage] = useState<string>("");
  const [showNicknameEntry, setShowNicknameEntry] = useState(false);
  const [inputError, setInputError] = useState<string | null>(null);
  const { clearSimulatedUserSession } = useStreamContext();
  const [showJumpToNow, setShowJumpToNow] = useState(false);

  const chatContainerRef = useRef<HTMLDivElement>(null);
  const shouldAutoScrollRef = useRef(true);
  const previousMessageRef = useRef<string | null>(null);

  const {
    messages,
    currentUser,
    roomInfo,
    isReadOnlyMode,
    isConnected,
    canSendMessages,
    isLoading,
    error,
    checkNicknameAvailability,
    connectWithNickName,
    sendMessage,
    toggleReaction,
    connectReadOnly,
  } = useChatContext();

  const displayTitle = "Club Chat";

  const hasValidContent = React.useCallback((message: string | null): boolean => {
    if (!message) return false;

    // Remove all GIF and EMOTE patterns to check if there's actual text content
    let contentWithoutMedia = message.replace(/\[GIF:[^\]]+\]/g, "");
    contentWithoutMedia = contentWithoutMedia.replace(/\[EMOTE:[^\]]+\]/g, "");

    // Check if there's any meaningful text left after removing media
    return contentWithoutMedia.trim().length > 0;
  }, []);

  const handleMessageChange = React.useCallback(
    (value: string) => {
      setNewMessage(value);
      previousMessageRef.current = value;
      if (inputError) {
        setInputError(null);
      }
    },
    [inputError],
  );

  const handleJoinChat = useCallback(
    async ({ nickname }: { nickname: string }): Promise<boolean> => {
      if (!isValidNickname(nickname)) {
        setInputError(invalidNicknameMessage);
        setNewMessage("");
        return false;
      }
      const success = await connectWithNickName({ nickname });
      if (success) {
        setShowNicknameEntry(false);
        setInputError(null);
        setNewMessage("");
        return true;
      }
      const availability = await checkNicknameAvailability(nickname);
      if (!availability.available) {
        setInputError(availability.reason || "This username is already in use");
      } else {
        setInputError(null);
        setNewMessage("");
      }
      return false;
    },
    [connectWithNickName, checkNicknameAvailability],
  );

  const validateMessage = useCallback((message: string | null): string | null => {
    if ((message?.length || 0) > 500) {
      return "Message cannot exceed 500 characters";
    }
    return null;
  }, []);

  const handleMessageSend = useCallback(
    async (message: string) => {
      const validationError = validateMessage(message);
      if (validationError) {
        setInputError(validationError);
        return;
      }

      setInputError(null);
      const success = await sendMessage(message);
      if (success) {
        setNewMessage("");
      } else {
        setInputError("Error Sending your message, Please try again!");
      }
    },
    [sendMessage, validateMessage],
  );

  const handleReceiveInput = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault();
      setNewMessage("");
      const trimmedMessage = newMessage.trim();
      if (isReadOnlyMode) {
        await handleJoinChat({ nickname: trimmedMessage });
      } else {
        await handleMessageSend(trimmedMessage);
      }
    },
    [newMessage, isReadOnlyMode, handleJoinChat, handleMessageSend],
  );

  const getConnectionStatus = React.useMemo(() => {
    if (isConnected) return { color: "bg-green-500", text: "Online" };
    if (isLoading) return { color: "bg-yellow-500", text: "Connecting..." };
    return { color: "bg-gray-500", text: "Offline" };
  }, [isConnected, isLoading]);

  const getButtonStyle = React.useMemo(() => {
    const isEnabled = (canSendMessages && (hasValidContent(newMessage) || newMessage?.trim())) || isReadOnlyMode;
    return {
      backgroundColor: isEnabled ? "#D4F8CC" : "#6B7280",
      color: isEnabled ? "#244C24" : "#fff",
    };
  }, [canSendMessages, newMessage, isReadOnlyMode, hasValidContent]);

  const getInputStyle = React.useMemo(
    () => ({
      backgroundColor: isReadOnlyMode ? "#FFFF" : "rgba(255, 255, 255, 0.15)",
      color: isReadOnlyMode ? "#000" : undefined,
    }),
    [isReadOnlyMode],
  );

  const closeChatConnection = async () => {
    clearSimulatedUserSession();
    clearTemporaryUserSession();
    clearUserSession();
    await connectReadOnly();
  };

  const handleScroll = React.useCallback(() => {
    const container = chatContainerRef.current;
    if (!container || isReadOnlyMode) return;

    const isAtBottom = container.scrollTop + container.clientHeight >= container.scrollHeight - 5;
    shouldAutoScrollRef.current = isAtBottom;
    setShowJumpToNow(!isAtBottom);
  }, [isReadOnlyMode]);

  const jumpToNow = React.useCallback(() => {
    const container = chatContainerRef.current;
    if (!container) return;

    shouldAutoScrollRef.current = true;
    container.scrollTo({
      top: container.scrollHeight,
      behavior: "smooth",
    });
  }, []);

  useEffect(() => {
    const container = chatContainerRef.current;
    if (!container || isReadOnlyMode || messages.length === 0) return;

    // Auto-scroll if we should (user was at bottom) or it's the first message
    if (shouldAutoScrollRef.current || messages.length === 1) {
      setTimeout(() => {
        if (container) {
          container.scrollTop = container.scrollHeight;
        }
      }, 50);
    }
  }, [messages, isReadOnlyMode]);

  useEffect(() => {
    const container = chatContainerRef.current;
    if (!container || isReadOnlyMode) return;

    container.addEventListener("scroll", handleScroll);
    return () => container.removeEventListener("scroll", handleScroll);
  }, [handleScroll, isReadOnlyMode]);

  return (
    <KeyboardOverlay>
      {showNicknameEntry && (
        <div className="fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
          <div className="relative z-10 flex items-center justify-center min-h-screen p-4">
            <div className="relative">
              <button
                type="button"
                onClick={() => setShowNicknameEntry(false)}
                className="absolute -top-2 -right-2 w-8 h-8 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white/70 hover:text-white transition-colors z-10 text-xl leading-none"
              >
                ×
              </button>
              <NicknameEntry
                onJoinChat={() => handleJoinChat({ nickname: newMessage || "" })}
                onCheckAvailability={checkNicknameAvailability}
                isLoading={isLoading}
                error={error}
              />
            </div>
          </div>
        </div>
      )}

      <section
        className="relative text-white w-full h-[55vh] overflow-hidden rounded-[12px] sm:p-4 sm:shadow-lg sm:border-zinc-700 sm:border sm:h-[650px] row-span-3"
        style={{ backgroundColor: "#27272A" }}
      >
        <div className="mb-2 pb-2 px-4 pt-4 sm:px-0 sm:pt-0">
          <div className="flex items-center gap-2 mb-1">
            <h2 className="font-bold text-lg text-white sm:text-lg text-base">{displayTitle}</h2>
            <div className="flex items-center gap-1">
              <div className={`w-2 h-2 rounded-full ${getConnectionStatus.color}`}></div>
              <span className="text-sm text-gray-300 font-medium">{getConnectionStatus.text}</span>
            </div>
          </div>
          <div className="mb-4 text-center">
            <p className="text-sm text-gray-400">Welcome to Club Chat!</p>
          </div>
        </div>

        <div className="flex flex-col h-[calc(55vh-120px)] sm:h-[650px]">
          {(error || inputError) && (
            <div className="bg-red-900 border border-red-700 text-red-200 px-3 py-2 rounded mb-2 text-xs">
              {error || inputError}
            </div>
          )}

          {showJumpToNow && !isReadOnlyMode && (
            <div className="relative mb-2">
              <button
                type="button"
                onClick={jumpToNow}
                className="absolute top-0 left-1/2 transform -translate-x-1/2 !bg-blue-600 hover:!bg-blue-700 text-white px-3 py-1 rounded-full text-sm font-medium transition-colors flex items-center gap-1 shadow-lg z-10 sm:px-3 px-2 sm:py-1 py-1"
              >
                <FiArrowDown className="w-3 h-3" />
                Jump to Now
              </button>
            </div>
          )}

          <div
            ref={chatContainerRef}
            className={`flex-1 px-4 pb-5 sm:p-4 sm:pb-56 ${isReadOnlyMode ? "overflow-y-hidden" : "overflow-y-scroll"} [&::-webkit-scrollbar]:hidden`}
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            }}
          >
            {messages.length === 0 ? (
              <p className="text-gray-400 text-sm">
                {isConnected ? "Chat messages will appear here..." : "Connect to start chatting..."}
              </p>
            ) : (
              <div className="flex flex-col space-y-3">
                {messages.map((message) => (
                  <ChatMessage
                    key={message.id}
                    message={message}
                    currentUserId={roomInfo?.userId}
                    streamId={streamId}
                    onToggleReaction={toggleReaction}
                    isOwner={message.sender?.attributes?.channelRole === "owner"}
                    isReadOnlyMode={isReadOnlyMode}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
      {isReadOnlyMode ? (
        <ReadOnlyChatIntro
          hostName={hostName}
          newMessage={newMessage}
          getInputStyle={getInputStyle}
          getButtonStyle={getButtonStyle}
          handleMessageChange={handleMessageChange}
          handleReceiveInput={handleReceiveInput}
        />
      ) : (
        <ActiveChatBoxRefactored
          newMessage={newMessage}
          canSendMessages={canSendMessages}
          currentUser={currentUser}
          getInputStyle={getInputStyle}
          getButtonStyle={getButtonStyle}
          handleMessageChange={handleMessageChange}
          handleReceiveInput={handleReceiveInput}
          closeChatConnection={closeChatConnection}
        />
      )}
    </KeyboardOverlay>
  );
});

LiveChatCard.displayName = "LiveChatCard";
