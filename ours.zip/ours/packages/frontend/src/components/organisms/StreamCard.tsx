import React, { useState } from "react";
import { AiFillHeart, AiOutlineAudio, AiOutlineHeart, AiOutlineShareAlt } from "react-icons/ai";
import { BodyText } from "#ours/frontend/components/atoms/BodyText.tsx";
import { ActionBar } from "#ours/frontend/components/molecules/ActionBar.tsx";
import { MediaHeader } from "#ours/frontend/components/molecules/MediaHeader.tsx";

type StreamCardProps = {
  title: string;
  host: string;
  description: string;
  onFavorite?: () => void;
  onShare: () => void;
  onAudioOnly: () => void;
  isFavorited?: boolean;
};

export const StreamCard = React.memo(
  ({ title, host, description, onFavorite: _onFavorite, onShare, onAudioOnly }: StreamCardProps) => {
    const [isFavorited, setIsFavorited] = useState(false);

    const handleFavorite = React.useCallback(() => setIsFavorited((prev) => !prev), []);

    const actions = React.useMemo(
      () => [
        {
          id: "favorite",
          icon: isFavorited ? (
            <AiFillHeart className="w-6 h-6 text-red-600" />
          ) : (
            <AiOutlineHeart className="w-6 h-6 text-gray-600" />
          ),
          label: isFavorited ? "Unfollow :( " : "Follow",
          onClick: handleFavorite,
        },
        {
          id: "share",
          icon: <AiOutlineShareAlt className="w-6 h-6 text-gray-700" />,
          label: "Share",
          onClick: onShare,
        },
        {
          id: "audio",
          icon: <AiOutlineAudio className="w-6 h-6 text-gray-700" />,
          label: "Audio Only",
          onClick: onAudioOnly,
        },
      ],
      [isFavorited, onShare, onAudioOnly, handleFavorite],
    );

    return (
      <article className="p-4 bg-white rounded-lg shadow-sm border border-gray-200 flex flex-col h-64">
        <MediaHeader title={title} host={host} />
        <BodyText className="mt-3 whitespace-pre-line text-gray-800 flex-grow">{description}</BodyText>
        <nav aria-label="Stream actions" className="mt-4 flex justify-end space-x-6">
          <ActionBar actions={actions} />
        </nav>
      </article>
    );
  },
);

StreamCard.displayName = "StreamCard";
