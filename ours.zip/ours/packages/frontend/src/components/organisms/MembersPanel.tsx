import { MoreVertical, Search, Users } from "lucide-react";
import React, { useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "#ours/frontend/components/ui/avatar";
import { Button } from "#ours/frontend/components/ui/button";
import { Card, CardContent } from "#ours/frontend/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader } from "#ours/frontend/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "#ours/frontend/components/ui/dropdown-menu";
import { Input } from "#ours/frontend/components/ui/input";
import { ScrollArea } from "#ours/frontend/components/ui/scroll-area";
import type { MembersPanelProps } from "#ours/frontend/types/performer.ts";

export const MembersPanel = React.memo(({ members, viewerCount, onEndStream }: MembersPanelProps) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [showConfirm, setShowConfirm] = useState(false);

  const filteredMembers = members.filter((member) => member.username.toLowerCase().includes(searchQuery.toLowerCase()));

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  };

  return (
    <div className="flex flex-col h-full">
      <div className="w-full flex justify-end mb-2">
        <Button
          onClick={() => setShowConfirm(true)}
          variant="secondary"
          className="bg-zinc-700 text-white hover:bg-zinc-600 px-4 py-2 h-9 border-none"
        >
          End Streaming
        </Button>
      </div>
      <Card className="bg-zinc-900 border border-zinc-800 flex-1 flex flex-col">
        <CardContent className="p-0 flex-1 flex flex-col">
          <div className="flex items-center gap-2 px-4 pt-4 pb-2">
            <Users className="w-5 h-5 text-zinc-400" />
            <span className="text-zinc-300">
              <span className="font-semibold text-white">{viewerCount}</span> members watching now
            </span>
          </div>
          <div className="p-4 border-b border-zinc-800">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
              <Input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search members..."
                className="pl-10 bg-zinc-800 border-zinc-700 text-white focus:bg-zinc-900"
              />
            </div>
          </div>
          <ScrollArea className="flex-1">
            <div className="sticky top-0 px-4 py-2 border-b border-zinc-800 bg-zinc-900 z-10">
              <div className="grid grid-cols-2 gap-4 text-xs font-medium text-zinc-400 uppercase">
                <div>Member</div>
                <div className="text-right">Date Joined</div>
              </div>
            </div>
            <div className="divide-y divide-zinc-800">
              {filteredMembers.map((member, index) => (
                <div key={member.id} className="px-4 py-3 hover:bg-zinc-800 transition-colors">
                  <div className="grid grid-cols-2 gap-4 items-center">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-zinc-500 font-medium w-6">{index + 1}.</span>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={member.avatar} alt={member.username} />
                          <AvatarFallback className="bg-zinc-800 text-xs text-zinc-400">
                            {member.username.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <span className="text-sm font-medium text-white">{member.username}</span>
                        {member.isOnline && <span className="w-2 h-2 bg-green-500 rounded-full" />}
                      </div>
                    </div>
                    <div className="flex items-center justify-end gap-2">
                      <span className="text-sm text-zinc-400">{formatDate(member.joinedDate)}</span>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 hover:bg-zinc-800">
                            <MoreVertical className="w-4 h-4 text-zinc-400" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>View Profile</DropdownMenuItem>
                          <DropdownMenuItem>Send Message</DropdownMenuItem>
                          <DropdownMenuItem className="text-red-600">Remove</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>
      <Dialog open={showConfirm} onOpenChange={setShowConfirm}>
        <DialogContent className="bg-zinc-900 border-zinc-800">
          <DialogHeader className="text-white">Are you sure you want to end the stream?</DialogHeader>
          <DialogFooter className="flex gap-2 justify-end">
            <Button
              variant="secondary"
              className="bg-zinc-700 text-white border-none"
              onClick={() => setShowConfirm(false)}
            >
              Cancel
            </Button>
            <Button
              variant="default"
              className="bg-green-200 hover:bg-green-300 text-[#244C24]"
              onClick={() => {
                setShowConfirm(false);
                onEndStream();
              }}
            >
              End Stream
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
});
MembersPanel.displayName = "MembersPanel";
