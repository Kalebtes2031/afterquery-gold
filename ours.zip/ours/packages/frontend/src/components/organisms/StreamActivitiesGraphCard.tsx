import React from "react";
import type { StreamComponentProps } from "#ours/frontend/types/index.ts";

export const StreamActivitiesGraphCard = React.memo(({ streamId }: StreamComponentProps) => {
  return (
    <section className="text-stone-800 p-4 shadow-lg border-stone-200 border rounded-lg min-h-[200px]">
      <span className="font-bold text-1xl">Stream Activities Graph</span>
      <small> {streamId}</small>
    </section>
  );
});
StreamActivitiesGraphCard.displayName = "StreamActivitiesGraphCard";
