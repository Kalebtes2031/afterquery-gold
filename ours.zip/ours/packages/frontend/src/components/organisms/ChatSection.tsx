import React from "react";
import { LiveChatCard } from "#ours/frontend/components/organisms/LiveChatCard.tsx";

interface ChatSectionProps {
  roomId: string | null;
  streamId: string | null;
}

export const ChatSection = React.memo(({ roomId, streamId }: ChatSectionProps) => {
  const streamData = {
    hostName: "Sneak",
    title: "Friday Night House Mix",
  };

  return (
    <div className="w-full md:basis-[35%] md:max-w-[35%] xl:basis-[40%] xl:max-w-[40%] text-center text-gray-500 lg:p-6">
      {roomId && (
        <LiveChatCard
          roomId={roomId}
          streamId={streamId ?? undefined}
          hostName={streamData.hostName}
          streamTitle={streamData.title}
        />
      )}
    </div>
  );
});

ChatSection.displayName = "ChatSection";

export default ChatSection;
