import React from "react";

import { cn } from "#ours/frontend/utils/utils.ts";

export const Card = React.memo(({ className, ...props }: React.ComponentProps<"div">) => {
  return (
    <div
      data-slot="card"
      className={cn("bg-card text-card-foreground flex flex-col gap-6 rounded-xl border py-6 shadow-sm", className)}
      {...props}
    />
  );
});

export const CardHeader = React.memo(({ className, ...props }: React.ComponentProps<"div">) => {
  return (
    <div
      data-slot="card-header"
      className={cn(
        "@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-1.5 px-6 has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-6",
        className,
      )}
      {...props}
    />
  );
});

export const CardTitle = React.memo(({ className, ...props }: React.ComponentProps<"div">) => {
  return <div data-slot="card-title" className={cn("leading-none font-semibold", className)} {...props} />;
});

export const CardDescription = React.memo(({ className, ...props }: React.ComponentProps<"div">) => {
  return <div data-slot="card-description" className={cn("text-muted-foreground text-sm", className)} {...props} />;
});

export const CardAction = React.memo(({ className, ...props }: React.ComponentProps<"div">) => {
  return (
    <div
      data-slot="card-action"
      className={cn("col-start-2 row-span-2 row-start-1 self-start justify-self-end", className)}
      {...props}
    />
  );
});

export const CardContent = React.memo(({ className, ...props }: React.ComponentProps<"div">) => {
  return <div data-slot="card-content" className={cn("px-6", className)} {...props} />;
});

export const CardFooter = React.memo(({ className, ...props }: React.ComponentProps<"div">) => {
  return (
    <div data-slot="card-footer" className={cn("flex items-center px-6 [.border-t]:pt-6", className)} {...props} />
  );
});

Card.displayName = "Card";
CardHeader.displayName = "CardHeader";
CardFooter.displayName = "CardFooter";
CardTitle.displayName = "CardTitle";
CardAction.displayName = "CardAction";
CardDescription.displayName = "CardDescription";
CardContent.displayName = "CardContent";
