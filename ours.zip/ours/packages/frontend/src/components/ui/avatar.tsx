import * as AvatarPrimitive from "@radix-ui/react-avatar";
import React from "react";

import { cn } from "#ours/frontend/utils/utils.ts";

export const Avatar = React.memo(({ className, ...props }: React.ComponentProps<typeof AvatarPrimitive.Root>) => {
  return (
    <AvatarPrimitive.Root
      data-slot="avatar"
      className={cn("relative flex size-8 shrink-0 overflow-hidden rounded-full", className)}
      {...props}
    />
  );
});

export const AvatarImage = React.memo(({ className, ...props }: React.ComponentProps<typeof AvatarPrimitive.Image>) => {
  return (
    <AvatarPrimitive.Image data-slot="avatar-image" className={cn("aspect-square size-full", className)} {...props} />
  );
});

export const AvatarFallback = React.memo(
  ({ className, ...props }: React.ComponentProps<typeof AvatarPrimitive.Fallback>) => {
    return (
      <AvatarPrimitive.Fallback
        data-slot="avatar-fallback"
        className={cn("bg-muted flex size-full items-center justify-center rounded-full", className)}
        {...props}
      />
    );
  },
);

Avatar.displayName = "Avatar";
AvatarImage.displayName = "AvatarImage";
AvatarFallback.displayName = "AvatarFallback";
