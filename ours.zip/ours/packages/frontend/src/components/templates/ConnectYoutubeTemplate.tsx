import React, { useState } from "react";
import { Button } from "#ours/frontend/components/ui/button";
import { Input } from "#ours/frontend/components/ui/input";
import { Label } from "#ours/frontend/components/ui/label";
import { Textarea } from "#ours/frontend/components/ui/textarea";
import type { Stream } from "#ours/frontend/types/performer.ts";
import { PerformerHeader } from "../molecules/PerformerHeader";

const mockStream: Stream = {
  id: "1",
  title: "House Vibes Friday Night Mix - Deep House & Tech",
  description:
    "Join me for a special Friday night stream featuring the latest house tracks and some classics. This week I'll be showcasing some unreleased material from upcoming producers!",
  isLive: true,
  startedAt: "9:15 PM",
  viewerCount: 150,
  performerName: "DJ Sneak",
  performerAvatar: "/avatar.jpg",
  clubName: "Sneak's House Club",
};

// Hook to manage YouTube form logic
const useYoutubeForm = () => {
  const [formData, setFormData] = React.useState({
    youtubeUrl: "",
    streamTitle: "",
    streamDescription: "",
  });

  const [errors, setErrors] = React.useState<{ [key: string]: string }>({});
  const [loading, setLoading] = React.useState(false);

  const setField = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const validate = React.useCallback(() => {
    const newErrors: { [key: string]: string } = {};
    if (!formData.youtubeUrl.trim()) newErrors.youtubeUrl = "YouTube URL is required";
    if (!formData.streamTitle.trim()) newErrors.streamTitle = "Stream title is required";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [formData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    try {
      await new Promise((res) => setTimeout(res, 1000));
      alert("Stream connected!");
    } catch {
      alert("Failed to connect stream.");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setField(id, value);
  };

  return {
    formData,
    errors,
    loading,
    handleSubmit,
    handleChange,
  };
};

export const ConnectYoutubeTemplate = React.memo(() => {
  const { formData, errors, loading, handleSubmit, handleChange } = useYoutubeForm();
  const [stream] = useState<Stream>(mockStream);

  // const handleNotificationsClick = () => {
  //   alert("Opening notifications...");
  // };

  return (
    <div className="min-h-screen bg-[#18181B] text-white flex flex-col">
      <PerformerHeader
        notificationCount={8}
        userAvatar={stream.performerAvatar}
        userName={stream.performerName}
        memberCount="23K Members"
      />

      {/* Main Content */}
      <main className="flex-grow flex flex-col items-center justify-start px-4 pt-20 pb-10">
        <form onSubmit={handleSubmit} className="w-full max-w-2xl space-y-10" noValidate>
          <div className="text-center space-y-2">
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-semibold">Connect Your YouTube Stream</h1>
            <p className="text-zinc-500 font-normal max-w-lg mx-auto">
              Share your unlisted YouTube stream link to broadcast exclusively to your club members.
            </p>
          </div>

          <div className="space-y-6">
            {/* YouTube URL */}
            <div className="space-y-2">
              <Label htmlFor="youtubeUrl">YouTube Live Stream URL</Label>
              <Input
                id="youtubeUrl"
                value={formData.youtubeUrl}
                onChange={handleChange}
                placeholder="https://youtube.com/watch?v=..."
                className="bg-zinc-900 border-gray-700 text-white"
                aria-invalid={!!errors.youtubeUrl}
                aria-describedby="youtubeUrl-error"
              />
              {errors.youtubeUrl && (
                <p id="youtubeUrl-error" className="text-red-500 text-sm">
                  {errors.youtubeUrl}
                </p>
              )}
            </div>

            {/* Stream Title */}
            <div className="space-y-2">
              <Label htmlFor="streamTitle">Stream Title</Label>
              <Input
                id="streamTitle"
                value={formData.streamTitle}
                onChange={handleChange}
                placeholder="E.g. Sneak's Friday Night Mix"
                className="bg-zinc-900 border-gray-700 text-white"
                aria-invalid={!!errors.streamTitle}
                aria-describedby="streamTitle-error"
              />
              {errors.streamTitle && (
                <p id="streamTitle-error" className="text-red-500 text-sm">
                  {errors.streamTitle}
                </p>
              )}
            </div>

            {/* Stream Description */}
            <div className="space-y-2">
              <Label htmlFor="streamDescription">Stream Description (optional)</Label>
              <Textarea
                id="streamDescription"
                value={formData.streamDescription}
                onChange={handleChange}
                placeholder="Enter stream description here..."
                className="bg-zinc-900 border-gray-700 text-white h-32 resize-none"
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={loading}
            className="w-full hover:bg-green-600 text-black font-medium text-sm sm:text-base py-3"
            style={{ backgroundColor: "#D4F8CC" }}
          >
            {loading ? "Connecting..." : "Proceed"}
          </Button>
        </form>
      </main>
    </div>
  );
});
ConnectYoutubeTemplate.displayName = "ConnectYoutubeTemplate";
