import React, { useState } from "react";
import { PerformerHeader } from "#ours/frontend/components/molecules/PerformerHeader.tsx";
import { ChatInterface } from "#ours/frontend/components/organisms/ChatInterface";
import { MembersPanel } from "#ours/frontend/components/organisms/MembersPanel";
import { PerformerPanel } from "#ours/frontend/components/organisms/PerformerPanel";
import type { Member, PaymentMethod, Stream } from "#ours/frontend/types/performer.ts";

// Mock data - all internal to this component
const mockStream: Stream = {
  id: "1",
  title: "House Vibes Friday Night Mix - Deep House & Tech",
  description:
    "Join me for a special Friday night stream featuring the latest house tracks and some classics. This week I'll be showcasing some unreleased material from upcoming producers!",
  isLive: true,
  startedAt: "9:15 PM",
  viewerCount: 150,
  performerName: "DJ Sneak",
  performerAvatar: "/avatar.jpg",
  clubName: "Rylo's Club",
};

const mockMembers: Member[] = [
  { id: "1", username: "TrollKing88", joinedDate: "2023-11-10" },
  { id: "2", username: "Angela Stewart", joinedDate: "2010-07-17" },
  { id: "3", username: "Sharon Roberts", joinedDate: "2015-03-07" },
  { id: "4", username: "Nancy Clark", joinedDate: "2009-10-13" },
  { id: "5", username: "Angela Smith", joinedDate: "2020-12-10" },
  { id: "6", username: "Paul Jones", joinedDate: "2006-04-08" },
  { id: "7", username: "Ben Young", joinedDate: "2014-05-01" },
  { id: "8", username: "Richard Hernandez", joinedDate: "2010-07-05" },
  { id: "9", username: "Rachel Lee", joinedDate: "2016-12-25" },
  { id: "10", username: "Elizabeth Clark", joinedDate: "2021-02-05" },
  { id: "11", username: "Ruth Kim", joinedDate: "2009-05-12" },
  { id: "12", username: "Michelle Brown", joinedDate: "2020-12-22" },
];

const mockPaymentMethods: PaymentMethod[] = [
  { id: "1", name: "PayPal", enabled: true },
  { id: "2", name: "Cash App", enabled: true },
  { id: "3", name: "Venmo", enabled: true },
  { id: "4", name: "Apple Pay", enabled: true },
];

export const PerformerStreamingLayout = React.memo(() => {
  const [stream] = useState<Stream>(mockStream);

  const handleEndStream = () => {
    console.log("Ending stream...");
  };

  return (
    <div className="min-h-screen flex flex-col bg-zinc-900">
      <PerformerHeader
        notificationCount={8}
        userAvatar={stream.performerAvatar}
        userName={stream.performerName}
        memberCount="23K Members"
      />

      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden gap-x-6 pr-6 pl-6">
        <div className="w-full lg:w-1/3 mt-6">
          <PerformerPanel
            streamTitle={stream.title}
            streamDescription={stream.description}
            streamUrl="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1&mute=1&controls=1&rel=0&modestbranding=1"
            isLive={stream.isLive}
            startTime={stream.startedAt}
            paymentMethods={mockPaymentMethods}
          />
        </div>

        <div className="w-full lg:w-1/3 flex flex-col mt-6">
          <ChatInterface clubName={stream.clubName} isOnline={stream.isLive} />
        </div>

        <div className="w-full lg:w-1/3 flex flex-col mt-6">
          <MembersPanel members={mockMembers} viewerCount={stream.viewerCount} onEndStream={handleEndStream} />
        </div>
      </div>
    </div>
  );
});
PerformerStreamingLayout.displayName = "PerformerStreamingLayout";
