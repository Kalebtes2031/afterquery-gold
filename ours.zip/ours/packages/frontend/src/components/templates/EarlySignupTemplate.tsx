import React from "react";
import { EarlyAccessBenefits } from "#ours/frontend/components/molecules/EarlyAccessBenefits.tsx";
import { EarlyAccessBanner } from "#ours/frontend/components/organisms/EarlyAccessBanner.tsx";
import { Footer } from "#ours/frontend/components/organisms/Footer.tsx";
export const EarlySignupTemplate = React.memo(() => {
  return (
    <div className="min-h-full bg-linear-to-t from-neutral-900 to-neutral-900 text-neutral-300">
      <div className="min-h-lvh grid-flow-cols m-auto mb-4 grid gap-8">
        <EarlyAccessBanner />
      </div>
      <div className="grid-flow-cols m-auto pb-20 grid max-w-[1400px] gap-20">
        <EarlyAccessBenefits />
        <Footer />
      </div>
    </div>
  );
});
EarlySignupTemplate.displayName = "EarlySignupTemplate";
