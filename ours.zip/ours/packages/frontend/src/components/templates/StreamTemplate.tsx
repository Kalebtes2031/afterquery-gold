import { useQuery } from "@tanstack/react-query";
import React, { useEffect } from "react";
import { PasswordModal } from "#ours/frontend/components/molecules/PasswordModal.tsx";
import { ChatSection } from "#ours/frontend/components/organisms/ChatSection.tsx";
import { StreamSection } from "#ours/frontend/components/organisms/StreamSection.tsx";
import { useChatContext } from "#ours/frontend/contexts/ChatContext.tsx";
import { useStreamContext } from "#ours/frontend/contexts/StreamContext.tsx";
import { usePasswordProtectedStream } from "#ours/frontend/hooks/usePasswordProtectedStream.ts";
import { apiService } from "#ours/frontend/services/ApiService.ts";
import type { StreamComponentProps } from "#ours/frontend/types/index.ts";

export const StreamTemplate = React.memo(({ streamId }: StreamComponentProps) => {
  const { devUser } = useStreamContext();
  const { setChannelId, setUserToken } = useChatContext();

  // Use the custom hook for password-protected stream logic
  const {
    streamData,
    isLoading: streamLoading,
    error: streamError,
    showPasswordModal,
    passwordError,
    isVerifyingPassword,
    handlePasswordSubmit,
    handlePasswordModalClose,
  } = usePasswordProtectedStream({ streamId });

  const { data: roomId = null } = useQuery({
    queryKey: ["GET_ROOM_ID", streamId],
    queryFn: async () => {
      const result = await apiService.get<{ room: { id: string } }>(`/api/rooms/demo`);
      return result?.room?.id;
    },
    enabled: !!streamId,
  });

  useEffect(() => {
    setUserToken(devUser?.token);
  }, [devUser?.token, setUserToken]);

  useEffect(() => {
    if (roomId) {
      setChannelId(roomId);
    } else {
      setChannelId("");
    }
  }, [roomId, setChannelId]);

  // Loading state
  if (streamLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-bg">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-500"></div>
      </div>
    );
  }

  // Error state (but not password-related errors)
  if (streamError) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-bg">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-fg mb-4">Stream Not Found</h2>
          <p className="text-fg-subtle mb-4">The requested stream could not be found.</p>
          <button
            type="button"
            onClick={() => window.history.back()}
            className="bg-primary-600 hover:bg-primary-700 text-white px-4 py-2 rounded-md"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  // Don't render main content if stream requires password and we don't have full data
  if (streamData?.requiresPassword || !streamData?.unlistedId) {
    return (
      <>
        <div className="min-h-screen flex items-center justify-center bg-bg">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-fg mb-4">Password Required</h2>
            <p className="text-fg-subtle">This stream is password protected.</p>
          </div>
        </div>
        <PasswordModal
          isOpen={showPasswordModal}
          streamTitle={streamData?.title || "Stream"}
          onSubmit={handlePasswordSubmit}
          onClose={handlePasswordModalClose}
          isLoading={isVerifyingPassword}
          error={passwordError}
        />
      </>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-bg">
      <main className="w-full px-6 py-4 flex-1 flex flex-col h-[calc(100vh-var(--spacing-header))] max-w-[92rem] mx-auto overflow-x-hidden">
        <div className="flex flex-col md:flex-row gap-6 lg:gap-8 flex-1 h-full min-h-0">
          <StreamSection streamData={streamData} />
          <ChatSection key={streamId} roomId={roomId} streamId={streamId} />
        </div>
      </main>
    </div>
  );
});
StreamTemplate.displayName = "StreamTemplate";

export default StreamTemplate;
