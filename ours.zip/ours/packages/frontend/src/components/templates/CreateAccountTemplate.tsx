import { ChevronRight } from "lucide-react";
import React, { useState } from "react";

interface FormData {
  djName: string;
  location: string;
  clubName: string;
  style: string;
}

interface StepStatus {
  id: number;
  label: string;
  status: "pending" | "active" | "completed";
}

export const CreateAccountTemplate = React.memo(() => {
  const [formData, setFormData] = useState<FormData>({
    djName: "",
    location: "",
    clubName: "",
    style: "",
  });

  const [currentStep] = useState<number>(1);

  const steps: StepStatus[] = [
    { id: 1, label: "Basic Info", status: currentStep === 1 ? "active" : "pending" },
    { id: 2, label: "Your Musical DNA", status: "pending" },
    { id: 3, label: "Connect Your World", status: "pending" },
  ];

  const handleInputChange =
    (field: keyof FormData) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>): void => {
      setFormData((prev) => ({
        ...prev,
        [field]: e.target.value,
      }));
    };

  const handleNext = (): void => {
    console.log("Form submitted:", formData);
  };

  return (
    <div className="h-screen bg-zinc-900 text-white flex flex-col overflow-hidden">
      <div className="fixed top-0 left-0 bg-red-500 text-white p-2 z-50">
        {globalThis.innerWidth ?? 0} x {globalThis.innerHeight ?? 0}
      </div>
      <header className="h-[86px] bg-black flex items-center shrink-0">
        <div className="w-full px-6 flex items-center justify-between">
          <h1 className="text-2xl font-bold">Ours</h1>
          <div className="absolute left-1/2 transform -translate-x-1/2 text-center">
            <p className="text-xs font-medium" style={{ color: "#D4F8CC" }}>
              Create Your Artist Profile
            </p>
            <p className="text-[10px] text-zinc-400 mt-1">Let's set up your space to connect with fans</p>
          </div>
          <div className="w-[60px]"></div>
        </div>
      </header>
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="w-[521px] space-y-6">
          <ProgressIndicator steps={steps} />
          <div className="bg-black rounded-xl p-6 border border-zinc-800">
            <div className="space-y-5">
              <FormField
                label="What's your DJ Name ?"
                id="djName"
                value={formData.djName}
                onChange={handleInputChange("djName")}
                placeholder="Enter here ..."
                helperText="This is how your fans will find you. Make it memorable, make it YOU."
              />
              <FormField
                label="Location"
                id="location"
                value={formData.location}
                onChange={handleInputChange("location")}
                placeholder="e.g:- Chicago, IL"
              />
              <FormField
                label="Club Name"
                id="clubName"
                value={formData.clubName}
                onChange={handleInputChange("clubName")}
                placeholder='e.g., "Sneak Underground"'
              />
              <div className="space-y-2">
                <label htmlFor="style" className="block text-xs font-medium text-zinc-100">
                  Tell us your style in a few words
                </label>
                <textarea
                  id="style"
                  value={formData.style}
                  onChange={handleInputChange("style")}
                  placeholder='e.g., "Deep house vibes with a touch of funk"'
                  rows={3}
                  className="w-full px-3 py-2 text-sm bg-zinc-950 border border-zinc-800 rounded-lg 
                           text-zinc-100 placeholder-zinc-600 focus:outline-none focus:ring-2 
                           focus:ring-emerald-500 focus:border-transparent transition-all
                           resize-none"
                />
              </div>
              <div className="flex justify-end pt-2">
                <button
                  type="button"
                  onClick={handleNext}
                  className="px-6 py-2 bg-emerald-400 text-zinc-900 text-sm font-semibold rounded-lg
                           hover:bg-emerald-300 focus:outline-none focus:ring-2 focus:ring-emerald-500 
                           focus:ring-offset-2 focus:ring-offset-black transition-all
                           flex items-center gap-2 group"
                >
                  Next
                  <ChevronRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
});
CreateAccountTemplate.displayName = "CreateAccountTemplate";

const ProgressIndicator = React.memo(({ steps }: { steps: StepStatus[] }) => {
  return (
    <div className="bg-black rounded-xl p-4 border border-zinc-800">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <React.Fragment key={step.id}>
            <StepItem step={step} />
            {index < steps.length - 1 && <div className="flex-1 h-[1px] bg-zinc-800 mx-3" />}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
});
ProgressIndicator.displayName = "ProgressIndicator";

const StepItem = React.memo(({ step }: { step: StepStatus }) => {
  const isActive = step.status === "active";
  const isCompleted = step.status === "completed";
  return (
    <div className="flex flex-col items-center gap-1 min-w-fit">
      <div className="flex items-center gap-2">
        <div
          className={`
            w-7 h-7 rounded-full border flex items-center justify-center
            font-medium text-xs transition-all
            ${
              isActive
                ? "border-emerald-400 bg-emerald-400/10 text-emerald-400"
                : isCompleted
                  ? "border-emerald-400 bg-emerald-400 text-zinc-900"
                  : "border-zinc-600 text-zinc-500"
            }
          `}
        >
          {step.id}
        </div>
        <div>
          <h3 className={`text-xs font-medium ${isActive ? "text-zinc-100" : "text-zinc-400"}`}>{step.label}</h3>
          <p className="text-[10px] text-zinc-600 mt-0.5">
            {step.status === "pending" ? "Pending" : step.status === "active" ? "In Progress" : "Completed"}
          </p>
        </div>
      </div>
    </div>
  );
});
StepItem.displayName = "StepItem";

interface FormFieldProps {
  label: string;
  id: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder: string;
  helperText?: string;
}

const FormField = React.memo(({ label, id, value, onChange, placeholder, helperText }: FormFieldProps) => {
  return (
    <div className="space-y-2">
      <label htmlFor={id} className="block text-xs font-small text-zinc-100">
        {label}
      </label>
      <input
        type="text"
        id={id}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full px-3 py-2 text-sm bg-zinc-950 border border-zinc-800 rounded-lg 
                 text-zinc-100 placeholder-zinc-600 focus:outline-none focus:ring-2 
                 focus:ring-emerald-500 focus:border-transparent transition-all"
      />
      {helperText && <p className="text-[10px] text-zinc-500">{helperText}</p>}
    </div>
  );
});
FormField.displayName = "CreateAccountFormField";

export default CreateAccountTemplate;
