import React from "react";
export const HomeTemplate = React.memo(() => {
  return "Home";
});
HomeTemplate.displayName = "HomeTemplate";
