import React from "react";
import { Button } from "#ours/frontend/components/ui/button";

export const EndStreamTemplate = React.memo(() => {
  return (
    <div className="min-h-screen bg-[#18181B] text-white flex items-center justify-center px-4">
      <div className="bg-black rounded-2xl shadow-lg p-8 w-full max-w-md space-y-6 text-left">
        <h2 className="text-2xl font-semibold">End Live Stream</h2>
        <p className="text-zinc-300 font-normal">Are you sure you want to end your live stream?</p>
        <div className="flex justify-center space-x-4">
          <Button className="bg-black border border-[#D4F8CC] text-[#D4F8CC] font-medium hover:bg-[#222222] transition">
            Cancel
          </Button>
          <Button className="bg-[#D4F8CC] text-black font-medium hover:bg-[#c4eebb] transition-colors duration-200">
            Confirm
          </Button>
        </div>
      </div>
    </div>
  );
});
EndStreamTemplate.displayName = "EndStreamTemplate";
