import React from "react";
import { Heading } from "#ours/frontend/components/atoms/Heading.tsx";
import { Subtitle } from "#ours/frontend/components/atoms/Subtitle.tsx";

type MediaHeaderProps = {
  title: string;
  host: string;
};

export const MediaHeader = React.memo(({ title, host }: MediaHeaderProps) => (
  <div className="space-y-1">
    <Heading className="text-green-600">{title}</Heading>
    <Subtitle>
      Live with <span className="text-green-600 font-bold">{host}</span>
    </Subtitle>
  </div>
));
MediaHeader.displayName = "MediaHeader";
