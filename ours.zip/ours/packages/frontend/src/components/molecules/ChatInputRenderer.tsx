import React from "react";
import { gifsData } from "#ours/frontend/data/gifs.ts";

interface ChatInputRendererProps {
  message: string;
  className?: string;
  style?: React.CSSProperties;
  placeholder?: string;
}

export const ChatInputRenderer = React.memo(({ message, className, style, placeholder }: ChatInputRendererProps) => {
  if (!message) {
    return (
      <div className={`${className} flex items-center min-h-[36px]`} style={style}>
        <span className="text-gray-400">{placeholder}</span>
      </div>
    );
  }

  // Handle both GIFs and emotes
  const gifRegex = /\[GIF:(https?:\/\/[^\]]+)\]/g;
  const emoteRegex = /\[EMOTE:([^\]]+)\]/g;

  // First, handle emotes by converting them to GIF format for processing
  const processedContent = message.replace(emoteRegex, (match, emoteId) => {
    const emote = gifsData.clubEmotes.find((e) => e.id === emoteId);
    if (emote) {
      return `[GIF:${emote.url}]`;
    }
    return match; // Keep original if emote not found
  });

  // Then handle GIFs
  const parts = processedContent.split(gifRegex);

  // If no media found, show regular text
  if (!gifRegex.test(processedContent)) {
    return (
      <div
        className={`${className} flex items-center justify-start min-h-[36px]`}
        style={{
          ...style,
          direction: "ltr",
          textAlign: "left",
          unicodeBidi: "embed",
        }}
      >
        <span
          className="text-white text-left"
          style={{
            direction: "ltr",
            unicodeBidi: "embed",
            textAlign: "left",
          }}
        >
          {message}
        </span>
      </div>
    );
  }

  // Render content maintaining the original order
  const renderContent = () => {
    const renderedParts: React.ReactElement[] = [];

    parts.forEach((part, index) => {
      // Handle GIFs/Emotes - only if this part was extracted by the GIF regex
      if (part.match(/^https?:\/\//) && index % 2 === 1) {
        // Check if it's a club emote (PNG)
        const isClubEmote = gifsData.clubEmotes.some((emote) => emote.url === part);

        const imgElement = (
          <img
            key={`input-media-${part.slice(-20)}-${index}`}
            src={part}
            alt={isClubEmote ? "Club Emote" : "GIF"}
            className={`${isClubEmote ? "inline-block" : "block"} ${isClubEmote ? "h-[calc(1em+25px)] w-auto" : "max-w-[100px] max-h-[100px]"} rounded object-cover`}
            loading="lazy"
            onError={(e) => {
              e.currentTarget.style.display = "none";
            }}
          />
        );

        // Club emotes stay inline, GIFs get their own block
        if (isClubEmote) {
          renderedParts.push(imgElement);
        } else {
          renderedParts.push(
            <div key={`input-gif-wrapper-${part.slice(-20)}-${index}`} className="block">
              {imgElement}
            </div>,
          );
        }
      } else if (part) {
        // Handle regular text
        renderedParts.push(
          <span
            key={`input-text-${part.slice(0, 20)}-${index}`}
            className="text-white break-words inline-block w-full items-start"
            style={{
              direction: "ltr",
              unicodeBidi: "embed",
              textAlign: "left",
            }}
          >
            {part}
          </span>,
        );
      }
    });

    return renderedParts;
  };

  return (
    <div
      className={`${className} flex flex-wrap items-start justify-start gap-1 min-h-[36px] max-h-[144px] max-w-full overflow-y-auto py-1`}
      style={{
        ...style,
        height: "auto",
        direction: "ltr",
        textAlign: "left",
        unicodeBidi: "embed",
      }}
    >
      {renderContent()}
    </div>
  );
});

ChatInputRenderer.displayName = "ChatInputRenderer";
