import React from "react";
// import { CHAT_REACTIONS } from "#ours/frontend/constants/index.ts";
import { gifsData } from "#ours/frontend/data/gifs.ts";
import type { ChatMessage as ChatMessageType } from "#ours/frontend/services/IvsChatService.ts";

// interface Reaction {
//   emoji: string;
//   reaction: string;
//   count: number;
// }

interface ChatMessageProps {
  message: ChatMessageType;
  isOwner?: boolean;
  currentUserId?: string;
  streamId?: string;
  isReadOnlyMode?: boolean;
  onToggleReaction: (messageId: string, reaction: string, userId: string, streamId: string) => void;
}

// const allowedReactions = [
//   { emoji: "\u2764\uFE0F", reaction: CHAT_REACTIONS.HEART, count: 0 }, // Red Heart
//   { emoji: "\u{1F64C}", reaction: CHAT_REACTIONS.HANDS_UP, count: 0 }, // Raising Hands
//   { emoji: "\u{1F525}", reaction: CHAT_REACTIONS.FIRE, count: 0 }, // Fire
//   { emoji: "\u{1F3B5}", reaction: CHAT_REACTIONS.MUSIC, count: 0 }, // Musical Note
//   { emoji: "\u{1F62E}", reaction: CHAT_REACTIONS.SURPRISED, count: 0 }, // Face with Open Mouth
// ];

// const getReactionCount = (message: ChatMessageProps["message"], reaction: string) => {
//   return message.reactions?.find((r) => r.reaction === reaction)?.count || 0;
// };

const renderMessageContent = (content: string) => {
  // Handle both GIFs and emotes
  const gifRegex = /\[GIF:(https?:\/\/[^\]]+)\]/g;
  const emoteRegex = /\[EMOTE:([^\]]+)\]/g;

  // First, handle emotes by converting them to GIF format for processing
  const processedContent = content.replace(emoteRegex, (match, emoteId) => {
    const emote = gifsData.clubEmotes.find((e) => e.id === emoteId);
    if (emote) {
      return `[GIF:${emote.url}]`;
    }
    return match; // Keep original if emote not found
  });

  // Then handle GIFs (both original GIFs and converted emotes)
  const parts = processedContent.split(gifRegex);

  return parts.map((part, index) => {
    // Handle GIFs/Emotes - only if this part was extracted by the GIF regex
    if (part.match(/^https?:\/\//) && index % 2 === 1) {
      // Check if it's a club emote (PNG)
      const isClubEmote = gifsData.clubEmotes.some((emote) => emote.url === part);

      return (
        <img
          key={`media-${part.slice(0, 20)}-${index}`}
          src={part}
          alt={isClubEmote ? "Club Emote" : "GIF"}
          className={isClubEmote ? "inline-block h-[calc(2em+75px)] w-auto mx-1" : "max-w-48 max-h-48 rounded-lg mt-2"}
          loading="lazy"
        />
      );
    }

    // Process text for links and mentions
    return <span key={`text-${part.slice(0, 20)}-${index}`}>{processTextContent(part)}</span>;
  });
};

const processTextContent = (text: string) => {
  // Enhanced regex for URLs (with and without protocol) and mentions
  const urlRegex = /((?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?)/g;
  const mentionRegex = /(@\w+)/g;

  // Split by URLs first
  const urlParts = text.split(urlRegex);

  return urlParts.map((urlPart, urlIndex) => {
    // If it's a URL, make it clickable
    if (urlPart.match(urlRegex)) {
      const href = urlPart.startsWith("http") ? urlPart : `https://${urlPart}`;
      return (
        <a
          key={`url-${urlPart.replace(/[^a-zA-Z0-9]/g, "")}-${urlIndex}`}
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-400 hover:text-blue-300 underline"
        >
          {urlPart}
        </a>
      );
    }

    // Process mentions within non-URL text
    const mentionParts = urlPart.split(mentionRegex);

    return mentionParts.map((mentionPart) => {
      // If it's a mention, make it bold
      if (mentionPart.match(mentionRegex)) {
        return (
          <span key={`mention-${mentionPart}`} className="font-bold" style={{ color: "#27ADF5" }}>
            {mentionPart}
          </span>
        );
      }

      // Regular text
      return mentionPart;
    });
  });
};

export const ChatMessage = React.memo(
  // ({ message, currentUserId, streamId, onToggleReaction, isOwner, isReadOnlyMode }: ChatMessageProps) => {
  ({ message, isOwner }: ChatMessageProps) => {
    const messageUserName = message.sender?.attributes?.username || message.sender?.attributes?.nickname || "Anonymous";
    const isArtistMessage = isOwner;

    return (
      <div className="space-y-2">
        <div
          className="rounded-xl p-4"
          style={{
            backgroundColor: isArtistMessage ? "#475245" : "#3F3F46",
          }}
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-primary-300">{messageUserName}</span>
                {isArtistMessage && (
                  <span
                    className="px-2 py-1 text-xs font-medium rounded"
                    style={{ backgroundColor: "#D4F8CC", color: "#000" }}
                  >
                    ARTIST
                  </span>
                )}
              </div>
            </div>

            <span className="text-xs text-gray-400">
              {new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
            </span>
          </div>

          <div>
            <div className="text-sm text-white text-left break-words break-all overflow-wrap-anywhere">
              {renderMessageContent(message.content)}
            </div>
          </div>
        </div>

        {/*
        <div className={"flex items-center gap-2 px-2 opacity-100"}>
          {allowedReactions?.map((reaction: Reaction) => {
            const count = getReactionCount(message, reaction.reaction);
            return (
              <button
                disabled={isReadOnlyMode || !currentUserId}
                key={`${message.id}-reaction-${reaction.reaction}`}
                type="button"
                className="flex items-center gap-1 px-2 py-1 rounded-lg text-xs text-gray-300 hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                style={{
                  backgroundColor: "#3F3F46",
                }}
                onClick={() => {
                  if (isReadOnlyMode || !currentUserId || !streamId) return;
                  onToggleReaction(message.id, reaction.reaction, currentUserId, streamId);
                }}
              >
                {count > 0 && <span>{count}</span>}
                <span>{reaction.emoji}</span>
              </button>
            );
          })}
        </div>
        */}
      </div>
    );
  },
);

ChatMessage.displayName = "ChatMessage";
