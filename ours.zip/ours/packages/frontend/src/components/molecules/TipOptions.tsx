import React from "react";

export const TipOptions = React.memo(() => {
  return (
    <div className="rounded-lg min-w-[300px] min-h-[50px] p-2  bg-gray-300 ">
      <div className="font-bold text-1xl">TipOptions</div>
    </div>
  );
});
TipOptions.displayName = "TipOptions";
