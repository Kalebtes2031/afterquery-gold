import React from "react";
import { IconButton } from "#ours/frontend/components/atoms/IconButton.tsx";

type Action = {
  id: string;
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
};

type ActionBarProps = {
  actions: Action[];
};

export const ActionBar = React.memo(({ actions }: ActionBarProps) => (
  <div className="flex justify-end space-x-4 mt-4">
    {actions.map((action) => (
      <div key={action.id} className="flex-shrink-0">
        <IconButton icon={action.icon} label={action.label} onClick={action.onClick} className="p-3" />
      </div>
    ))}
  </div>
));
ActionBar.displayName = "ActionBar";
