import React, { useCallback, useEffect, useState } from "react";

type wordsProps = { words: string[]; interval: number };

export const WordsInterval = React.memo(({ words, interval }: wordsProps) => {
  const [wordIndex, setWordIndex] = useState(-2);
  const [fade, setFade] = useState("opacity-100 transition-all duration-600");
  const transitionStates = {
    initial: "opacity-0 left-[-60px] transition-none",
    slideIn: "opacity-100 left-[0px] transition-all duration-500",
    slideOut: "opacity-0 left-[60px] transition-all duration-500",
  };

  const slideWordIn = useCallback(() => {
    setWordIndex((prevIndex) => (prevIndex + 1) % words.length);
    setFade(transitionStates.initial);
    setTimeout(() => {
      setFade(transitionStates.slideIn);
      setTimeout(() => {
        setFade(transitionStates.slideOut);
      }, interval * 0.75);
    }, interval / 8);
  }, [words, interval]);

  useEffect(() => {
    slideWordIn();
    const timer = setInterval(() => {
      slideWordIn();
    }, interval);
    return () => clearInterval(timer);
  }, [interval, slideWordIn]);

  return <span className={`relative ${fade}`}>{words[wordIndex]}</span>;
});
WordsInterval.displayName = "WordsInterval";
