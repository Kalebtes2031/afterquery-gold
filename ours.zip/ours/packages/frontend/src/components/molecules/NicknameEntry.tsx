import React, { useCallback, useState } from "react";
import { BodyText } from "#ours/frontend/components/atoms/BodyText.tsx";
import { Button } from "#ours/frontend/components/atoms/Buttons.tsx";

export interface NicknameEntryProps {
  onJoinChat: (nickname: string) => Promise<boolean>;
  onCheckAvailability: (nickname: string) => Promise<{ available: boolean; reason?: string }>;
  isLoading?: boolean;
  error?: string | null;
  className?: string;
}

export const NicknameEntry = React.memo(
  ({ onJoinChat, onCheckAvailability, isLoading = false, error, className = "" }: NicknameEntryProps) => {
    const [nickname, setNickname] = useState("");
    const [availability, setAvailability] = useState<{ available: boolean; reason?: string } | null>(null);
    const [isCheckingAvailability, setIsCheckingAvailability] = useState(false);

    // Validate nickname format
    const isValidNickname = useCallback((nick: string): boolean => {
      return /^[a-zA-Z0-9_]{3,20}$/.test(nick);
    }, []);

    // Check availability with debounce
    const checkAvailability = useCallback(
      async (nick: string) => {
        if (!isValidNickname(nick)) {
          setAvailability({
            available: false,
            reason: "Use 3-20 characters, letters, numbers, and underscores only",
          });
          return;
        }

        setIsCheckingAvailability(true);
        const result = await onCheckAvailability(nick);
        setAvailability(result);
        setIsCheckingAvailability(false);
      },
      [onCheckAvailability, isValidNickname],
    );

    // Handle nickname input change
    const handleNicknameChange = useCallback(
      (value: string) => {
        setNickname(value);
        setAvailability(null);

        // Debounced availability check
        if (value.length >= 3) {
          const timeoutId = setTimeout(() => {
            checkAvailability(value);
          }, 500);

          return () => clearTimeout(timeoutId);
        }
      },
      [checkAvailability],
    );

    // Handle join chat
    const handleJoinChat = useCallback(async () => {
      if (!nickname || !availability?.available) {
        return;
      }

      const success = await onJoinChat(nickname);
      if (!success) {
        // Re-check availability in case of error
        checkAvailability(nickname);
      }
    }, [nickname, availability, onJoinChat, checkAvailability]);

    // Handle key press
    const handleKeyPress = useCallback(
      (e: React.KeyboardEvent) => {
        if (e.key === "Enter" && nickname && availability?.available && !isLoading) {
          handleJoinChat();
        }
      },
      [nickname, availability, isLoading, handleJoinChat],
    );

    const getAvailabilityMessage = () => {
      if (isCheckingAvailability) {
        return { message: "Checking availability...", type: "info" };
      }

      if (availability === null) {
        return null;
      }

      if (availability.available) {
        return { message: "\u2713 Username available", type: "success" }; // Check Mark
      }

      const reasonMessages: Record<string, string> = {
        in_use: "Username is currently taken",
        reserved: "Username is reserved",
        error: "Error checking availability",
      };

      return {
        message: reasonMessages[availability.reason || ""] || availability.reason || "Username not available",
        type: "error",
      };
    };

    const availabilityInfo = getAvailabilityMessage();
    const canJoin = nickname && availability?.available && !isLoading && !isCheckingAvailability;

    return (
      <div
        className={`flex flex-col gap-6 p-8 bg-black/80 rounded-xl border border-white/10 backdrop-blur-sm max-w-md mx-auto ${className}`}
      >
        <div className="text-center mb-4">
          <BodyText className="text-[#a8ff5e] mb-2 font-semibold text-lg">Welcome to DJ Sneak's Club!</BodyText>
          <BodyText className="text-white/80 text-sm">Choose a handle to join the conversation</BodyText>
        </div>

        <div className="flex flex-col gap-4">
          <input
            type="text"
            value={nickname}
            onChange={(e) => handleNicknameChange(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Enter your handle ..."
            disabled={isLoading}
            className="w-full"
          />
          {error && <p className="text-red-500">{error}</p>}

          {availabilityInfo && (
            <BodyText
              className={`-mt-2 text-sm ${
                availabilityInfo.type === "success"
                  ? "text-green-400"
                  : availabilityInfo.type === "error"
                    ? "text-red-400"
                    : "text-blue-400"
              }`}
            >
              {availabilityInfo.message}
            </BodyText>
          )}

          <Button handleClick={handleJoinChat} disabled={!canJoin} loading={isLoading} className="">
            Start Chatting
          </Button>
        </div>
      </div>
    );
  },
);

NicknameEntry.displayName = "NicknameEntry";
