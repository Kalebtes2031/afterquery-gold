import React from "react";
import { HashTag } from "#ours/frontend/components/atoms/HashTag.tsx";
import type { HashTagsProps } from "#ours/frontend/types/index.ts";

export const HashTags = React.memo(({ hashTags }: HashTagsProps) => {
  return (
    <article className="flex text-stone-800">
      {hashTags.map((hash, index) => (
        <HashTag key={index.toString()} label={hash.label} />
      ))}
    </article>
  );
});
HashTags.displayName = "HashTags";
