import React from "react";
import { Link } from "react-router-dom";

interface StreamCardProps {
  stream: {
    id: number;
    streamName: string;
    title: string;
    streamType: "youtube" | "vimeo" | "ivs";
    hasPassword: boolean;
    paymentMethods?: Array<{
      paymentType: "venmo" | "cashapp" | "paypal";
      handle: string;
    }>;
    createdAt: string;
    ivsIngestEndpoint?: string;
    ivsStreamKey?: string;
    ivsPlaybackUrl?: string;
  };
  copiedStreamId: number | null;
  deletingStreamId: number | null;
  expandedIvsStream: number | null;
  copiedCredential: string | null;
  onCopyLink: (streamName: string, streamId: number) => void;
  onDeleteStream: (streamName: string, streamId: number) => void;
  onToggleIvsCredentials: (streamId: number) => void;
  onCopyCredential: (text: string, credentialType: string) => void;
}

export const StreamCard = React.memo(
  ({
    stream,
    copiedStreamId,
    deletingStreamId,
    expandedIvsStream,
    copiedCredential,
    onCopyLink,
    onDeleteStream,
    onToggleIvsCredentials,
    onCopyCredential,
  }: StreamCardProps) => {
    return (
      <div className="border border-border-dark rounded-lg p-4 hover:shadow-md transition-shadow bg-surface-2">
        <div className="flex items-center justify-between mb-2 min-w-0">
          <h4 title={stream.title} className="text-lg font-medium text-fg truncate max-w-[28rem]">
            {stream.title}
          </h4>
          <div className="flex gap-2">
            {stream.streamType === "ivs" && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-900 text-blue-200">
                📡 Live
              </span>
            )}
            {stream.hasPassword && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-surface text-fg">
                Protected
              </span>
            )}
          </div>
        </div>
        <p className="text-sm text-fg-subtle mb-2">
          Type: {stream.streamType === "ivs" ? "IVS Live" : stream.streamType === "youtube" ? "YouTube" : "Vimeo"}
        </p>
        <div className="text-sm text-fg-subtle mb-2">
          <span>URL: </span>
          <span
            title={`/streams/${stream.streamName}`}
            className="inline-block max-w-[calc(100%-3rem)] truncate align-bottom"
          >
            /streams/{stream.streamName}
          </span>
        </div>
        <p className="text-xs text-fg-subtle mb-2">Created: {new Date(stream.createdAt).toLocaleDateString()}</p>
        {stream.paymentMethods && stream.paymentMethods.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {stream.paymentMethods.map((method) => (
              <span
                key={`${method.paymentType}-${method.handle}`}
                title={method.handle}
                className="inline-block max-w-[20rem] truncate whitespace-nowrap overflow-hidden px-2.5 py-0.5 rounded-full text-xs font-medium bg-surface text-fg"
              >
                {method.paymentType === "venmo" && "Venmo"}
                {method.paymentType === "cashapp" && "Cash App"}
                {method.paymentType === "paypal" && "PayPal"}: {method.handle}
              </span>
            ))}
          </div>
        )}

        {stream.streamType === "ivs" && (
          <div className="mb-4">
            <button
              type="button"
              onClick={() => onToggleIvsCredentials(stream.id)}
              className="w-full text-left px-3 py-2 bg-blue-900/20 border border-blue-700/50 rounded-lg text-sm text-blue-200 hover:bg-blue-900/30 transition-colors"
            >
              {expandedIvsStream === stream.id ? "🔽 Hide" : "▶️ Show"} Stream Credentials
            </button>

            {expandedIvsStream === stream.id && (
              <div className="mt-2 p-3 bg-surface border border-border-dark rounded-lg space-y-2">
                {stream.ivsIngestEndpoint && (
                  <div>
                    <label htmlFor={`rtmp-url-${stream.id}`} className="block text-xs font-medium text-fg-subtle mb-1">
                      RTMP URL
                    </label>
                    <div className="flex gap-1">
                      <input
                        id={`rtmp-url-${stream.id}`}
                        type="text"
                        readOnly
                        value={`rtmps://${stream.ivsIngestEndpoint}:443/app/`}
                        className="flex-1 px-2 py-1 bg-surface-2 border border-border-dark rounded text-fg text-xs font-mono"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          onCopyCredential(`rtmps://${stream.ivsIngestEndpoint}:443/app/`, `rtmp-${stream.id}`)
                        }
                        className="px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs"
                      >
                        {copiedCredential === `rtmp-${stream.id}` ? "Copied!" : "Copy"}
                      </button>
                    </div>
                  </div>
                )}

                {stream.ivsStreamKey && (
                  <div>
                    <label
                      htmlFor={`stream-key-${stream.id}`}
                      className="block text-xs font-medium text-fg-subtle mb-1"
                    >
                      Stream Key
                    </label>
                    <div className="flex gap-1">
                      <input
                        id={`stream-key-${stream.id}`}
                        type="password"
                        readOnly
                        value={stream.ivsStreamKey}
                        className="flex-1 px-2 py-1 bg-surface-2 border border-border-dark rounded text-fg text-xs font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => onCopyCredential(stream.ivsStreamKey || "", `key-${stream.id}`)}
                        className="px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs"
                      >
                        {copiedCredential === `key-${stream.id}` ? "Copied!" : "Copy"}
                      </button>
                    </div>
                  </div>
                )}

                {stream.ivsPlaybackUrl && (
                  <div>
                    <label
                      htmlFor={`playback-url-${stream.id}`}
                      className="block text-xs font-medium text-fg-subtle mb-1"
                    >
                      Playback URL
                    </label>
                    <div className="flex gap-1">
                      <input
                        id={`playback-url-${stream.id}`}
                        type="text"
                        readOnly
                        value={stream.ivsPlaybackUrl}
                        className="flex-1 px-2 py-1 bg-surface-2 border border-border-dark rounded text-fg text-xs font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => onCopyCredential(stream.ivsPlaybackUrl || "", `playback-${stream.id}`)}
                        className="px-3 py-1 bg-neutral-800 hover:bg-neutral-700 text-white rounded text-xs"
                      >
                        {copiedCredential === `playback-${stream.id}` ? "Copied!" : "Copy"}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        <div className="flex space-x-2">
          <Link
            to={`/stream/${stream.streamName}`}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-white hover:text-white focus:text-white bg-neutral-800 hover:bg-neutral-700 focus:outline-none focus:ring-2 focus:ring-neutral-500 transition-all duration-200 shadow-sm hover:shadow-md no-underline"
          >
            View Stream
          </Link>
          <button
            type="button"
            onClick={() => onCopyLink(stream.streamName, stream.id)}
            className={`inline-flex items-center px-4 py-2 border text-sm font-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all duration-200 shadow-sm hover:shadow-md ${
              copiedStreamId === stream.id
                ? "border-green-600 text-white bg-green-600 hover:bg-green-700"
                : "border-border-dark text-fg bg-surface hover:bg-surface-2"
            }`}
          >
            {copiedStreamId === stream.id ? "Copied!" : "Copy Link"}
          </button>
          <button
            type="button"
            disabled={deletingStreamId === stream.id}
            onClick={() => onDeleteStream(stream.streamName, stream.id)}
            className={`inline-flex items-center px-4 py-2 border text-sm font-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 transition-all duration-200 shadow-sm hover:shadow-md ${
              deletingStreamId === stream.id
                ? "border-red-600 text-white bg-red-600 opacity-70 cursor-not-allowed"
                : "border-red-600 text-white bg-red-600 hover:bg-red-700 focus:ring-red-500"
            }`}
          >
            {deletingStreamId === stream.id ? "Deleting..." : "Delete"}
          </button>
        </div>
      </div>
    );
  },
);

StreamCard.displayName = "StreamCard";
