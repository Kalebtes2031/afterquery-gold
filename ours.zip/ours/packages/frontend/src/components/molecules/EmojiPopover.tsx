import React, { useRef, useState } from "react";
import { HiChevronLeft, HiChevronRight, HiOutlineEmojiHappy } from "react-icons/hi";
import { Popover, PopoverContent, PopoverTrigger } from "#ours/frontend/components/ui/popover.tsx";
import { type EmojiItem, emojisData } from "#ours/frontend/data/emojis.ts";

interface EmojiPopoverProps {
  onEmojiSelect: (emoji: string) => void;
}

type EmojiCategory =
  | "Smileys & Emotion"
  | "People & Body"
  | "Animals & Nature"
  | "Food & Drink"
  | "Travel & Places"
  | "Activities"
  | "Objects"
  | "Symbols"
  | "Flags";

const CATEGORY_LABELS = {
  "Smileys & Emotion": "Smileys",
  "People & Body": "People",
  "Animals & Nature": "Nature",
  "Food & Drink": "Food",
  "Travel & Places": "Travel",
  Activities: "Activities",
  Objects: "Objects",
  Symbols: "Symbols",
  Flags: "Flags",
};

export const EmojiPopover = React.memo(({ onEmojiSelect }: EmojiPopoverProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<EmojiCategory>("Smileys & Emotion");
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const handleEmojiClick = (emoji: string) => {
    onEmojiSelect(emoji);
    setIsOpen(false);
  };

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -120, behavior: "smooth" });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 120, behavior: "smooth" });
    }
  };

  const getCurrentEmojis = (): string[] => {
    const categoryData = emojisData.emojis[activeCategory];
    if (!categoryData) return [];

    // Extract emojis from all subcategories within the selected category
    const emojis = Object.values(categoryData)
      .filter(Array.isArray)
      .flatMap((subcategory: EmojiItem[]) =>
        subcategory
          .filter(
            (item): item is EmojiItem =>
              item !== undefined &&
              item !== null &&
              item.emoji !== undefined &&
              item.emoji !== null &&
              item.emoji !== "",
          )
          .map((item) => item.emoji),
      );

    // Limit emojis based on category for performance
    const limit = 80;
    return emojis.slice(0, limit);
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <button type="button" style={{ color: "inherit", backgroundColor: "transparent" }} className="cursor-pointer">
          <HiOutlineEmojiHappy className="w-4 h-4" />
        </button>
      </PopoverTrigger>
      <PopoverContent
        className="w-[90vw] max-w-80 p-0 border-none shadow-lg rounded-xl"
        align="end"
        side="top"
        sideOffset={8}
        style={{ backgroundColor: "rgba(0, 0, 0, 0.9)" }}
      >
        <div className="p-4 space-y-4">
          {/* Tab Navigation */}
          <div className="relative border-b border-gray-700">
            <button
              type="button"
              onClick={scrollLeft}
              className="absolute left-0 top-0 bottom-0 z-10 px-1 text-gray-400 hover:text-white transition-colors bg-gradient-to-r from-black/90 to-transparent"
              style={{
                backgroundColor: "transparent",
                background: "linear-gradient(to right, rgba(0,0,0,0.9) 0%, transparent 100%)",
              }}
            >
              <HiChevronLeft className="w-4 h-4" />
            </button>

            <div
              ref={scrollContainerRef}
              className="flex overflow-x-auto [&::-webkit-scrollbar]:hidden px-6"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
            >
              {(Object.keys(CATEGORY_LABELS) as EmojiCategory[]).map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setActiveCategory(category)}
                  className={`px-2 py-2 text-xs font-medium transition-colors relative flex-shrink-0 whitespace-nowrap ${
                    activeCategory === category ? "text-gray-400 hover:text-white" : "text-gray-400 hover:text-white"
                  }`}
                  style={{ backgroundColor: "transparent", color: activeCategory === category ? "#D4F8CC" : undefined }}
                >
                  {CATEGORY_LABELS[category]}
                  {activeCategory === category && (
                    <div
                      className="absolute bottom-0 left-0 right-0 h-0.5"
                      style={{ backgroundColor: "#D4F8CC" }}
                    ></div>
                  )}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={scrollRight}
              className="absolute right-0 top-0 bottom-0 z-10 px-1 text-gray-400 hover:text-white transition-colors"
              style={{
                backgroundColor: "transparent",
                background: "linear-gradient(to left, rgba(0,0,0,0.9) 0%, transparent 100%)",
              }}
            >
              <HiChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Emoji Grid */}
          <div
            className="grid grid-cols-8 gap-2 max-h-64 overflow-y-auto [&::-webkit-scrollbar]:hidden"
            style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
          >
            {getCurrentEmojis().map((emoji) => (
              <button
                key={`${activeCategory}-${emoji}`}
                type="button"
                onClick={() => handleEmojiClick(emoji)}
                style={{ backgroundColor: "transparent" }}
                className="w-8 h-8 hover:bg-gray-700 rounded-lg flex items-center justify-center text-lg transition-colors focus:outline-none focus:ring-2 focus:ring-green-400 focus:ring-offset-2 focus:ring-offset-black"
                title={emoji}
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
});

EmojiPopover.displayName = "EmojiPopover";
