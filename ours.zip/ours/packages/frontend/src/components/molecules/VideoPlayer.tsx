import React from "react";
import { IVSPlayer } from "#ours/frontend/components/organisms/ivs_player.tsx";
import { VIDEO_EMBED_URLS } from "#ours/frontend/constants/index.ts";
import { useOnlinePresence } from "#ours/frontend/hooks/useOnlinePresence.ts";

interface VideoPlayerProps {
  videoId?: string;
  streamName?: string;
  streamType?: "youtube" | "vimeo" | "ivs";
  ivsPlaybackUrl?: string;
}

export const VideoPlayer = React.memo(
  ({ videoId = "dQw4w9WgXcQ", streamName, streamType, ivsPlaybackUrl }: VideoPlayerProps) => {
    const detectedStreamType = streamType || (streamName?.includes("vimeo") ? "vimeo" : "youtube");

    const { viewerCount, isConnected } = useOnlinePresence({
      slug: streamName || videoId,
      enabled: !!streamName,
    });

    if (detectedStreamType === "ivs" && ivsPlaybackUrl) {
      return (
        <div className="w-full bg-black rounded-lg overflow-hidden relative aspect-video">
          <IVSPlayer playbackUrl={ivsPlaybackUrl} className="aspect-video" autoplay muted={false} />
          {streamName && (
            <div className="hidden sm:flex absolute top-3 right-4 items-center gap-2 rounded-[6px] bg-[#3f3f46]/60 backdrop-blur-sm px-3 py-1 text-white text-sm z-20">
              <svg
                className="h-4 w-4 text-white"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
                aria-label="Viewers icon"
              >
                <title>Viewers</title>
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M17 20h5v-2a4 4 0 0 0-3-3.87M9 20h8M3 20h5m4-16a4 4 0 1 1-8 0 4 4 0 0 1 8 0zm6 4a4 4 0 1 1-8 0 4 4 0 0 1 8 0z"
                />
              </svg>
              <span>{viewerCount > 0 ? `${viewerCount} watching` : isConnected ? "1 watching" : "connecting..."}</span>
            </div>
          )}
        </div>
      );
    }

    const embedUrl = VIDEO_EMBED_URLS[detectedStreamType as "youtube" | "vimeo"](videoId);

    return (
      <div className="w-full bg-black rounded-lg overflow-hidden relative aspect-video">
        <iframe
          width="100%"
          height="100%"
          src={embedUrl}
          title="Live Stream"
          style={{ border: "none" }}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          className="w-full h-full absolute inset-0 m-0 p-0"
        />
        {streamName && (
          <div className="hidden sm:flex absolute top-3 right-4 items-center gap-2 rounded-[6px] bg-[#3f3f46]/60 backdrop-blur-sm px-3 py-1 text-white text-sm">
            <svg
              className="h-4 w-4 text-white"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              viewBox="0 0 24 24"
              aria-label="Viewers icon"
            >
              <title>Viewers</title>
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                d="M17 20h5v-2a4 4 0 0 0-3-3.87M9 20h8M3 20h5m4-16a4 4 0 1 1-8 0 4 4 0 0 1 8 0zm6 4a4 4 0 1 1-8 0 4 4 0 0 1 8 0z"
              />
            </svg>
            <span>{viewerCount > 0 ? `${viewerCount} watching` : isConnected ? "1 watching" : "connecting..."}</span>
          </div>
        )}
      </div>
    );
  },
);
VideoPlayer.displayName = "VideoPlayer";

export default VideoPlayer;
