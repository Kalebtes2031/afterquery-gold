import React from "react";
import { BorderedIcon } from "#ours/frontend/components/atoms/Icons.tsx";
export const EarlyAccessBenefits = React.memo(() => {
  const leadInCopy =
    "Welcome fellow music heads... get in the club early, support the artists giving back to the scene";
  const benefits = [
    {
      description: "Be the first to explore intimate, high-quality streams.",
      icon: "IoMedalOutline",
    },
    {
      description: "Get exclusive access to private shows you won't find anywhere else.",
      icon: "FiLock",
    },
    {
      description: "Help us build the ultimate community for authentic music connection.",
      icon: "SlPeople",
    },
  ];
  return (
    <div className="m-4 grid grid-cols-3 gap-8">
      <div className="col-span-3 p- text-center text-3xl py-20 lg:px-80">{leadInCopy}</div>

      {benefits.map((benefit, index) => (
        <div
          key={index.toString()}
          className="sm: col-span-3 min-h-[240px] rounded-md bg-radial-[at_0%_5%] from-neutral-500 to-neutral-800 p-0.5 lg:col-span-1"
        >
          <div className="h-full rounded-md bg-radial-[at_30%_35%] from-neutral-800 to-neutral-950 p-10 ">
            <div className="w-[60px] h-[60px]">
              <BorderedIcon reactIconClass={benefit.icon} />
            </div>
            <p className="py-6 text-2xl">{benefit.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
});
EarlyAccessBenefits.displayName = "EarlyAccessBenefits";
