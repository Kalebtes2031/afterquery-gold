import React from "react";

export const TipSubmitForm = React.memo(() => {
  return (
    <div className="rounded-lg min-w-[300px] min-h-[100px] p-2  bg-gray-300 ">
      <div className="font-bold text-1xl">TipSubmitForm</div>
    </div>
  );
});
TipSubmitForm.displayName = "TipSubmitForm";
