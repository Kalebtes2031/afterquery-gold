import React from "react";

type StreamPlayerProps = {
  streamId?: string;
};

export const StreamPlayer = React.memo(({ streamId: _streamId }: StreamPlayerProps) => {
  return <div>StreamPlayer</div>;
  // return (
  //   <article className="flex text-stone-800 h-[800px]">
  //     <iframe
  //       className="grow shadow-lg border-stone-200 border border-rounded-lg rounded-lg"
  //       src={iframeSrc}
  //       allowFullScreen
  //       title="Stream Player"
  //     />
  //   </article>
  // );
});

StreamPlayer.displayName = "StreamPlayer";
