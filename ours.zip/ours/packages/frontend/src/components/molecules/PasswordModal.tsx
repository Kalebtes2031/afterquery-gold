import { useEffect, useState } from "react";
import { AiOutlineEye, AiOutlineEyeInvisible, AiOutlineLock } from "react-icons/ai";

interface PasswordModalProps {
  isOpen: boolean;
  streamTitle: string;
  onSubmit: (password: string) => void;
  onClose: () => void;
  isLoading?: boolean;
  error?: string;
}

export function PasswordModal({
  isOpen,
  streamTitle,
  onSubmit,
  onClose,
  isLoading = false,
  error,
}: PasswordModalProps) {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  // Clear password when error occurs so user can retry easily
  useEffect(() => {
    if (error) {
      setPassword("");
    }
  }, [error]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password.trim()) {
      onSubmit(password);
    }
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") {
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
      onClick={handleBackdropClick}
      onKeyDown={handleKeyDown}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div className="bg-surface border border-border-dark rounded-lg shadow-xl max-w-md w-full p-6">
        <div className="flex items-center justify-center mb-6">
          <div className="w-16 h-16 bg-surface-2 rounded-full flex items-center justify-center">
            <AiOutlineLock className="w-8 h-8 text-fg-subtle" />
          </div>
        </div>

        <div className="text-center mb-6">
          <h2 id="modal-title" className="text-xl font-semibold text-fg mb-2">
            Password Protected Stream
          </h2>
          <p className="text-sm text-fg-subtle mb-1">"{streamTitle}"</p>
          <p className="text-sm text-fg-subtle">Please enter the password to access this stream</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-fg mb-2">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-border-dark bg-surface-2 rounded-lg px-3 py-2 pr-10 focus:ring-2 focus:ring-primary-500 focus:border-primary-500 outline-none transition-colors text-fg placeholder:text-fg-subtle"
                placeholder="Enter password"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-fg-subtle hover:text-fg transition-colors"
                disabled={isLoading}
              >
                {showPassword ? <AiOutlineEyeInvisible className="w-4 h-4" /> : <AiOutlineEye className="w-4 h-4" />}
              </button>
            </div>
            {error && <p className="mt-2 text-sm text-red-500">{error}</p>}
          </div>

          <div className="flex space-x-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              disabled={isLoading}
              className="flex-1 px-4 py-2 border border-border-dark text-sm font-medium rounded-lg text-fg bg-surface hover:bg-surface-2 focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isLoading || !password.trim()}
              className="flex-1 px-4 py-2 border border-transparent text-sm font-medium rounded-lg text-bg bg-fg hover:bg-fg-muted focus:outline-none focus:ring-2 focus:ring-primary-500 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? "Verifying..." : "Access Stream"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

PasswordModal.displayName = "PasswordModal";
