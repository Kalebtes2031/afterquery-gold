import React from "react";
import type { StreamStatusProps } from "#ours/frontend/types/performer.ts";
import { cn } from "#ours/frontend/utils/utils.ts";

export const StreamStatus = React.memo(({ isLive, startTime, className }: StreamStatusProps) => {
  return (
    <div className={cn("h-12 px-4 flex items-center gap-2 bg-transparent", className)}>
      {isLive && (
        <>
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
          </span>
          <span className="text-white font-medium">You're Live</span>
          <span className="text-sm text-white bg-zinc-950 px-2 py-1 rounded">Started: {startTime}</span>
        </>
      )}
    </div>
  );
});
StreamStatus.displayName = "StreamStatus";
