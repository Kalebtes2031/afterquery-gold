import React from "react";
import { FiCheck, FiCopy } from "react-icons/fi";
import { PaymentOptions } from "#ours/frontend/components/molecules/PaymentOptions.tsx";
import { type PaymentMethod, usePayment } from "#ours/frontend/hooks/usePayment.ts";

interface StreamInfoProps {
  streamTitle?: string;
  paymentMethods?: PaymentMethod[];
}

export const StreamInfo = React.memo<StreamInfoProps>(({ streamTitle, paymentMethods }) => {
  const {
    selectedPayment,
    setSelectedPayment,
    copied,
    qrCodeDataUrl,
    availablePaymentTypes,
    getPaymentHandle,
    handleCopy,
  } = usePayment(paymentMethods);

  const fullPaymentHandle = getPaymentHandle() || "";
  const TRUNCATE_LENGTH = 10;
  const displayPaymentHandle =
    fullPaymentHandle.length > TRUNCATE_LENGTH
      ? `${fullPaymentHandle.slice(0, TRUNCATE_LENGTH - 3)}...`
      : fullPaymentHandle;

  return (
    <div className="flex flex-col lg:flex-row gap-6 lg:gap-12 mt-6 lg:relative">
      <div className="flex-1">
        <h2 className="text-white text-xl font-semibold mb-3">{streamTitle || "Live Stream"}</h2>
        <p className="text-gray-300 text-sm mb-4 leading-relaxed">
          Join me for a special live stream session! Your support through tips is greatly appreciated.
        </p>
        <p className="text-gray-400 text-sm">Live Now</p>
      </div>

      <div className="w-full md:flex md:justify-end lg:max-w-[400px] self-end">
        {availablePaymentTypes.length > 0 && (
          <div className="relative flex flex-row gap-2 items-stretch h-[150px] w-full md:w-full lg:pr-[140px]">
            <div className="flex-1 min-w-0 md:min-w-[200px] md:max-w-none lg:max-w-none">
              <PaymentOptions
                selected={selectedPayment}
                onChange={setSelectedPayment}
                availableTypes={availablePaymentTypes}
              />
            </div>

            <div className="bg-[#27272A] rounded-xl flex flex-col items-center justify-between p-2 w-[120px] h-[150px] relative flex-shrink-0 lg:absolute lg:right-0 lg:top-0">
              <h4 className="text-white text-xs font-medium text-center">Tip Streamer</h4>

              <div className="bg-white p-1.5 rounded-lg">
                <div className="w-20 h-20">
                  {qrCodeDataUrl ? (
                    <img src={qrCodeDataUrl} alt="QR code for tipping streamer" className="w-full h-full" />
                  ) : (
                    <div className="w-full h-full bg-gray-200 rounded flex items-center justify-center">
                      <span className="text-xs text-gray-500">Loading...</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <div
                  className="text-gray-300 text-xs overflow-hidden max-w-[9rem] lg:max-w-[11rem]"
                  title={getPaymentHandle()}
                  style={{ textOverflow: "ellipsis", whiteSpace: "nowrap" }}
                >
                  {displayPaymentHandle}
                </div>
                <button
                  type="button"
                  className="p-2 sm:p-1 hover:bg-[#3a3a3a] rounded-md transition-colors active:scale-95"
                  onClick={handleCopy}
                  aria-label="Copy payment handle"
                >
                  {copied ? (
                    <FiCheck className="w-3 h-3 text-green-400" />
                  ) : (
                    <FiCopy className="w-3 h-3 text-gray-400" />
                  )}
                </button>
              </div>
              {copied && (
                <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-[#1a1a1a] text-white text-xs px-2 py-1 rounded whitespace-nowrap">
                  Copied!
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
});
StreamInfo.displayName = "StreamInfo";

export default StreamInfo;
