import React from "react";
import { FaFacebookF, FaInstagram, FaWhatsapp } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";
import { FiShare2 } from "react-icons/fi";
import { Button } from "#ours/frontend/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "#ours/frontend/components/ui/dialog.tsx";

interface ShareDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const ShareDialog = React.memo(({ open, onOpenChange }: ShareDialogProps) => {
  const handleCopy = (): void => {
    const url = globalThis.location?.href ?? "";
    if (!url) return;
    if (navigator?.clipboard?.writeText) {
      navigator.clipboard.writeText(url).catch(() => {});
    }
  };

  const currentUrl = globalThis.location?.href ?? "";

  const handleShare = (platform: string): void => {
    const url = encodeURIComponent(currentUrl);
    const text = encodeURIComponent("Check out this live stream!");

    let shareUrl = "";
    switch (platform) {
      case "facebook":
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
        break;
      case "whatsapp":
        shareUrl = `https://wa.me/?text=${text}%20${url}`;
        break;
      case "instagram":
        // Instagram doesn't have a direct share URL
        handleCopy();
        return;
      case "twitter":
        shareUrl = `https://twitter.com/intent/tweet?text=${text}&url=${url}`;
        break;
    }

    if (shareUrl) {
      globalThis.open?.(shareUrl, "_blank", "noopener,noreferrer");
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          size="default"
          className="bg-transparent border border-gray-600 text-gray-300 hover:bg-gray-800 hover:text-white rounded-lg px-3 py-2 sm:px-4"
        >
          <FiShare2 className="mr-2 h-4 w-4" />
          <span className="hidden sm:inline">Share Stream</span>
          <span className="sm:hidden">Share</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:bg-[#1a1a1a] bg-[#1a1a1a] border-[#2a2a2a] sm:max-w-[480px] max-w-full p-0 [&>button]:text-gray-400 [&>button:hover]:text-white [&>button]:transition-colors sm:rounded-lg rounded-t-2xl fixed sm:fixed sm:top-[50%] sm:left-[50%] sm:translate-x-[-50%] sm:translate-y-[-50%] bottom-0 left-0 right-0 top-auto translate-x-0 translate-y-0 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 sm:data-[state=closed]:zoom-out-95 sm:data-[state=open]:zoom-in-95 data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom sm:data-[state=closed]:slide-out-to-top-0 sm:data-[state=open]:slide-in-from-top-0">
        <DialogHeader className="px-5 pt-5 pb-3">
          <DialogTitle className="text-lg font-normal text-white">Share Live Stream</DialogTitle>
        </DialogHeader>

        <div className="px-5  sm:pb-5 ">
          <div className="mb-4">
            <label htmlFor="share-stream-url" className="block text-white text-sm font-normal mb-2">
              Stream
            </label>
            <div className="flex items-center gap-2">
              <input
                id="share-stream-url"
                type="text"
                value={currentUrl}
                readOnly
                className="flex-1 px-3 py-2 bg-[#2a2a2a] border border-[#3a3a3a] rounded-md text-gray-300 font-mono text-xs focus:outline-none focus:border-[#4a4a4a]"
              />
              <Button
                type="button"
                onClick={handleCopy}
                className="bg-[#a8ff78] hover:bg-[#8fe55f] text-black font-medium px-4 py-2 h-auto rounded-md transition-colors text-sm"
              >
                Copy
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-3">
            <button
              type="button"
              onClick={() => handleShare("facebook")}
              className="flex flex-col items-center justify-center p-3 rounded-md bg-[#2a2a2a] hover:bg-[#3a3a3a] transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-[#1877f2] flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
                <FaFacebookF className="text-white text-base" />
              </div>
              <span className="text-gray-400 text-xs">Facebook</span>
            </button>

            <button
              type="button"
              onClick={() => handleShare("whatsapp")}
              className="flex flex-col items-center justify-center p-3 rounded-md bg-[#2a2a2a] hover:bg-[#3a3a3a] transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-[#25d366] flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
                <FaWhatsapp className="text-white text-lg" />
              </div>
              <span className="text-gray-400 text-xs">WhatsApp</span>
            </button>

            <button
              type="button"
              onClick={() => handleShare("instagram")}
              className="flex flex-col items-center justify-center p-3 rounded-md bg-[#2a2a2a] hover:bg-[#3a3a3a] transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#f02849] via-[#c32f88] to-[#7638fa] flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
                <FaInstagram className="text-white text-lg" />
              </div>
              <span className="text-gray-400 text-xs">Instagram</span>
            </button>

            <button
              type="button"
              onClick={() => handleShare("twitter")}
              className="flex flex-col items-center justify-center p-3 rounded-md bg-[#2a2a2a] hover:bg-[#3a3a3a] transition-colors group"
            >
              <div className="w-10 h-10 rounded-full bg-black flex items-center justify-center mb-1.5 group-hover:scale-110 transition-transform">
                <FaXTwitter className="text-white text-base" />
              </div>
              <span className="text-gray-400 text-xs">Twitter</span>
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
});
ShareDialog.displayName = "ShareDialog";

export default ShareDialog;
