import React from "react";
import type { StreamComponentProps } from "#ours/frontend/types/index.ts";

export const StreamTippers = React.memo(({ streamId }: StreamComponentProps) => {
  return (
    <div className="text-stone-800 shadow-lg border-stone-200 border rounded-lg min-w-[300px] min-h-[40px] p-4">
      <span className="font-bold text-1xl">StreamTippers</span>
      <small>{streamId}</small>
    </div>
  );
});
