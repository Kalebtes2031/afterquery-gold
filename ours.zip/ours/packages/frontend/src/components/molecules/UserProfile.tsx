import { UserButton, useAuth } from "@clerk/clerk-react";
import { dark } from "@clerk/themes";
import { AiOutlineUser } from "react-icons/ai";
import { Link } from "react-router-dom";

export function UserProfile() {
  const { isSignedIn } = useAuth();

  if (!isSignedIn) {
    return (
      <div className="flex items-center space-x-4">
        <Link to="/login">
          <AiOutlineUser className="w-5 h-5 text-fg" />
        </Link>
      </div>
    );
  }

  return (
    <div className="flex items-center space-x-4">
      <UserButton
        appearance={{
          baseTheme: dark,
          elements: {
            avatarBox: "w-8 h-8",
          },
        }}
        afterSignOutUrl="/home"
      />
    </div>
  );
}

UserProfile.displayName = "UserProfile";
