import { MessageCircle } from "lucide-react";
import React from "react";
import { Avatar, AvatarFallback, AvatarImage } from "#ours/frontend/components/ui/avatar";
import { Badge } from "#ours/frontend/components/ui/badge";
import { Button } from "#ours/frontend/components/ui/button";
import type { HeaderProps } from "#ours/frontend/types/performer.ts";

export const PerformerHeader = React.memo(
  ({ notificationCount = 0, userAvatar, userName, memberCount }: HeaderProps) => {
    return (
      <header className="h-14 bg-zinc-950 border-b border-zinc-800 px-6 flex items-center justify-between">
        <div className="flex items-center">
          <h1 className="text-2xl font-bold text-white">Ours</h1>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="relative hover:bg-zinc-900">
            <MessageCircle className="w-5 h-5 text-zinc-400" />
            {notificationCount > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-green-500 hover:bg-green-500">
                {notificationCount}
              </Badge>
            )}
          </Button>
          <div className="flex items-center gap-3">
            <Avatar className="h-8 w-8 border border-zinc-700">
              <AvatarImage src={userAvatar} alt={userName} />
              <AvatarFallback>{userName.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <span className="text-sm font-medium text-white">{userName}</span>
              <span className="text-xs text-zinc-400">{memberCount}</span>
            </div>
          </div>
        </div>
      </header>
    );
  },
);
