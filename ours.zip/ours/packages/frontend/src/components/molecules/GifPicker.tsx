import React, { useState } from "react";
import { MdGif } from "react-icons/md";
import { Popover, PopoverContent, PopoverTrigger } from "#ours/frontend/components/ui/popover.tsx";
import { type GifItem, gifsData } from "#ours/frontend/data/gifs.ts";

interface GifPickerProps {
  onGifSelect: (gif: string) => void;
}

type TabType = "club-emotes" | "gifs";

export const GifPicker = React.memo(({ onGifSelect }: GifPickerProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>("gifs");

  const handleItemClick = (item: GifItem) => {
    if (item.type === "gif") {
      onGifSelect(item.url);
    } else if (item.type === "png") {
      onGifSelect(`[EMOTE:${item.id}]`);
    } else if (item.type === "emoji") {
      onGifSelect(item.url);
    } else if (item.type === "avatar") {
      onGifSelect(`[Avatar: ${item.url}]`);
    }
    setIsOpen(false);
  };

  const getCurrentItems = (): GifItem[] => {
    return activeTab === "club-emotes" ? gifsData.clubEmotes : gifsData.gifs;
  };

  const renderItem = (item: GifItem) => {
    if (item.type === "gif") {
      return (
        <div className="relative w-full aspect-square rounded-lg overflow-hidden">
          <img
            src={item.url}
            alt={item.id}
            className="w-full h-full object-cover hover:scale-150 transition-transform cursor-pointer"
            loading="lazy"
          />
        </div>
      );
    }

    if (item.type === "png") {
      return (
        <div className="relative w-full aspect-square rounded-lg overflow-hidden flex items-center justify-center p-2">
          <img
            src={item.url}
            alt={item.id}
            className="max-w-full max-h-full object-contain hover:scale-150 transition-transform cursor-pointer"
            loading="lazy"
          />
        </div>
      );
    }

    if (item.type === "emoji") {
      return (
        <div className="w-full aspect-square rounded-lg bg-gray-800 flex items-center justify-center text-2xl hover:bg-gray-700 transition-colors cursor-pointer">
          {item.url}
        </div>
      );
    }

    if (item.type === "avatar") {
      return (
        <div className="w-full aspect-square rounded-full bg-blue-500 flex items-center justify-center text-white font-semibold text-xl hover:bg-blue-600 transition-colors cursor-pointer">
          {item.url}
        </div>
      );
    }

    return null;
  };

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <button type="button" style={{ color: "inherit", backgroundColor: "transparent" }} className="cursor-pointer">
          <MdGif className="w-8 h-8" />
        </button>
      </PopoverTrigger>
      <PopoverContent
        className="w-80 p-0 border-none shadow-lg rounded-xl"
        align="end"
        side="top"
        sideOffset={8}
        style={{ backgroundColor: "rgba(0, 0, 0, 0.9)" }}
      >
        <div className="p-4 space-y-4">
          {/* Tab Navigation */}
          <div className="flex border-b border-gray-700">
            <button
              type="button"
              onClick={() => setActiveTab("club-emotes")}
              className={`px-4 py-2 text-sm font-medium transition-colors relative ${
                activeTab === "club-emotes" ? "text-gray-400 hover:text-white" : "text-gray-400 hover:text-white"
              }`}
              style={{ backgroundColor: "transparent", color: activeTab === "club-emotes" ? "#D4F8CC" : undefined }}
            >
              Club Emotes
              {activeTab === "club-emotes" && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5" style={{ backgroundColor: "#D4F8CC" }}></div>
              )}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("gifs")}
              className={`px-4 py-2 text-sm font-medium transition-colors relative ${
                activeTab === "gifs" ? "text-gray-400 hover:text-white" : "text-gray-400 hover:text-white"
              }`}
              style={{ backgroundColor: "transparent", color: activeTab === "gifs" ? "#D4F8CC" : undefined }}
            >
              GIFS
              {activeTab === "gifs" && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5" style={{ backgroundColor: "#D4F8CC" }}></div>
              )}
            </button>
          </div>

          {/* Content Grid */}
          <div
            className="grid grid-cols-3 gap-3 max-h-64 overflow-y-auto [&::-webkit-scrollbar]:hidden"
            style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
          >
            {getCurrentItems().map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleItemClick(item)}
                className="focus:outline-none rounded-lg"
                style={{ backgroundColor: "transparent" }}
              >
                {renderItem(item)}
              </button>
            ))}
          </div>
        </div>
      </PopoverContent>
    </Popover>
  );
});

GifPicker.displayName = "GifPicker";
