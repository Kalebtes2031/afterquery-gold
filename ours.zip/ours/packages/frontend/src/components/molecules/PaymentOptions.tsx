import React from "react";
import { SiCashapp, SiPaypal, SiVenmo } from "react-icons/si";

type PaymentMethod = "cashapp" | "venmo" | "paypal";

interface PaymentOptionsProps {
  selected: PaymentMethod;
  onChange: (method: PaymentMethod) => void;
  availableTypes?: PaymentMethod[];
}

export const PaymentOptions = React.memo(
  ({ selected, onChange, availableTypes = ["cashapp", "venmo", "paypal"] }: PaymentOptionsProps) => {
    const paymentButtons = [
      { type: "cashapp" as const, label: "Cash App", icon: SiCashapp, bgColor: "#00D632", iconColor: "black" },
      { type: "venmo" as const, label: "Venmo", icon: SiVenmo, bgColor: "#3D95CE", iconColor: "white" },
      { type: "paypal" as const, label: "PayPal", icon: SiPaypal, bgColor: "#0070BA", iconColor: "white" },
    ];

    return (
      <div className="flex flex-col gap-1.5 h-full justify-center">
        {paymentButtons
          .filter((button) => availableTypes.includes(button.type))
          .map((button) => {
            const Icon = button.icon;
            return (
              <button
                key={button.type}
                type="button"
                onClick={() => onChange(button.type)}
                className={`w-full px-3 py-2 rounded-lg flex items-center gap-2 text-left transition-all ${
                  selected === button.type
                    ? "border border-[#3a3a3a]"
                    : "bg-[#1a1a1a] border border-[#27272A] hover:bg-[#202020]"
                }`}
                style={selected === button.type ? { backgroundColor: "#27272A" } : {}}
              >
                <span className="text-sm text-white font-normal flex-1">{button.label}</span>
                <div
                  className="w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: button.bgColor }}
                >
                  <Icon className="text-sm" style={{ color: button.iconColor }} />
                </div>
              </button>
            );
          })}
      </div>
    );
  },
);
PaymentOptions.displayName = "PaymentOptions";

export default PaymentOptions;
