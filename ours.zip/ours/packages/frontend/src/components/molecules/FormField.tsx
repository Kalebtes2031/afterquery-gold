import React from "react";
import type { FormFieldProps } from "#ours/frontend/types/index.ts";
/** 
export const ButtonAddFunds: React.FC<ButtonProps> = ({
  handleClick,
  label,
  labelSm,
}) => {
*/
export const FormField = React.memo(({ label, type, name, placeholder, caption, onChange }: FormFieldProps) => {
  return (
    <div className="mb-4">
      <div className="lg:px-80 sm:px-2 py-2">
        <label className="text-sm block py-[6px] px-4" htmlFor={name}>
          {label}
        </label>
        <input
          type={type}
          name={name}
          className="border-neutral-600 border py-3 px-4 rounded-md w-full"
          placeholder={placeholder}
          onChange={onChange}
        />
        {caption && <p className="text-sm py-2 text-neutral-500">{caption}</p>}
      </div>
    </div>
  );
});
FormField.displayName = "FormField";
