import React from "react";
import { FiLock } from "react-icons/fi";
import { IoMedalOutline } from "react-icons/io5";
import { SlPeople } from "react-icons/sl";
import scrollIcon from "#ours/frontend/assets/scrollIcon.svg";
import type { IconProps } from "#ours/frontend/types/index.ts";

export const BorderedIcon = React.memo(({ reactIconClass }: IconProps) => {
  return (
    <div className=" text-center p-[18%] block m-auto w-full h-full border flex text-4xl rounded-md">
      {reactIconClass === "IoMedalOutline" && <IoMedalOutline />}
      {reactIconClass === "FiLock" && <FiLock />}
      {reactIconClass === "SlPeople" && <SlPeople />}
    </div>
  );
});
BorderedIcon.displayName = "BorderedIcon";

export const ScrollIcon = React.memo(() => {
  return <img src={scrollIcon} alt="Scroll Icon" />;
});
ScrollIcon.displayName = "ScrollIcon";
