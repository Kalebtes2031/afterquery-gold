import React from "react";

type HeadingProps = React.HTMLAttributes<HTMLHeadingElement>;

export const Heading = React.memo(({ children, className = "", ...props }: HeadingProps) => (
  <h2 className={`text-2xl font-bold text-gray-900 ${className}`} {...props}>
    {children}
  </h2>
));
Heading.displayName = "Heading";
