import React from "react";
import type { ButtonProps } from "#ours/frontend/types/index.ts";

export const ButtonAddFunds = React.memo(({ handleClick, label, labelSm }: ButtonProps) => {
  return (
    <button
      type="button"
      onClick={handleClick}
      className="border-neutral-500 hover:border-green-100 hover:bg-green-700 text-neutral-700 hover:text-neutral-200 text-sm mx-2 hover:px-6 rounded-sm border px-4 py-2 font-medium transition-all duration-300"
    >
      <span className="hidden md:block">{label}</span>
      <span className="block md:hidden">{labelSm ? labelSm : label}</span>
    </button>
  );
});
ButtonAddFunds.displayName = "ButtonAddFunds";

export const ButtonDark = React.memo(({ handleClick, label, disabled }: ButtonProps) => {
  return (
    <div>
      <button
        type="button"
        onClick={handleClick}
        disabled={disabled}
        className={"bg-radial-[at_20%_20%] from-neutral-500 to-neutral-900 w-full p-0.5 rounded-md "}
      >
        <div
          className={
            "w-full p-2 rounded-md hover:text-neutral-900 hover:bg-neutral-100 transition-all duration-300 " +
            (disabled ? "bg-neutral-800 cursor-not-allowed" : "bg-neutral-600 ")
          }
        >
          {label}
        </div>
      </button>
    </div>
  );
});
ButtonDark.displayName = "ButtonDark";

export const Button = React.memo(({ children, handleClick, disabled, loading, className }: ButtonProps) => {
  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={disabled}
      className={`bg-neutral-500 w-full p-0.5 rounded-md ${className}`}
    >
      {loading ? "Loading..." : children}
    </button>
  );
});
Button.displayName = "Button";
