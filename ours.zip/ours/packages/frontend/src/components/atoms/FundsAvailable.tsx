import React from "react";
import type { FundsAvailableProps } from "#ours/frontend/types/index.ts";

export const FundsAvailable = React.memo(({ amount }: FundsAvailableProps) => {
  return <div className="text-3xl font-medium text-gray-800">${amount}</div>;
});
FundsAvailable.displayName = "FundsAvailable";
