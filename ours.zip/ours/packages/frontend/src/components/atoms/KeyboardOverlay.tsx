import React from "react";
import { useKeyboard } from "#ours/frontend/contexts/KeyboardContext.tsx";

interface KeyboardOverlayProps {
  children: React.ReactNode;
}

export const KeyboardOverlay = React.memo(({ children }: KeyboardOverlayProps) => {
  const { inputFocused, isMobile } = useKeyboard();

  return (
    <>
      {inputFocused && isMobile && (
        <div className="fixed top-0 left-0 right-0 bottom-30 bg-black/30 backdrop-blur-sm pointer-events-none z-[40]" />
      )}
      {children}
    </>
  );
});
KeyboardOverlay.displayName = "KeyboardOverlay";

export default KeyboardOverlay;
