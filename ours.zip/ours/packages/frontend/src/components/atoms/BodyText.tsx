import React from "react";

type BodyTextProps = React.HTMLAttributes<HTMLParagraphElement>;

export const BodyText = React.memo(({ children, className = "", ...props }: BodyTextProps) => (
  <p className={`text-base text-black whitespace-pre-line ${className}`} {...props}>
    {children}
  </p>
));
BodyText.displayName = "BodyText";
