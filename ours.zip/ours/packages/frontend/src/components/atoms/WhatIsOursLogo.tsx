import React from "react";
import whatIsOurs from "#ours/frontend/assets/whatIsOurs.png";

export const WhatIsOursLogo = React.memo(() => {
  return <img src={whatIsOurs} alt="What Is Ours Logo" />;
});
WhatIsOursLogo.displayName = "WhatIsOursLogo";
