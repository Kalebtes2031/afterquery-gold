import React from "react";
import type { HashTagData } from "#ours/frontend/types/index.ts";

export const HashTag = React.memo(({ label }: HashTagData) => {
  return (
    <span className="inline-flex items-center rounded-lg bg-gray-200 px-2 py-1 mx-1 text-xs font-medium text-gray-600 ring-1 ring-gray-500/10">
      #{label}
    </span>
  );
});
HashTag.displayName = "HashTag";
