import React from "react";
import { FaUser } from "react-icons/fa6";

export const UserAvatar = React.memo(() => {
  return (
    <button type="button">
      <FaUser className="text-stone-900 hover:text-green-700 text-2xl" />
    </button>
  );
});
UserAvatar.displayName = "UserAvatar";
