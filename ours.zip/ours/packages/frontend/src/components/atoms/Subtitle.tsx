import React from "react";

type SubtitleProps = React.HTMLAttributes<HTMLParagraphElement>;

export const Subtitle = React.memo(({ children, className = "", ...props }: SubtitleProps) => (
  <p className={`text-sm text-gray-500 ${className}`} {...props}>
    {children}
  </p>
));
Subtitle.displayName = "Subtitle";
