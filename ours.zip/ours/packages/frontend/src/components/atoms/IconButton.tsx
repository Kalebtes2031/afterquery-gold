import React from "react";

type IconButtonProps = {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  className?: string;
};

export const IconButton = React.memo(({ icon, label, className = "", onClick }: IconButtonProps) => (
  <button
    className={`flex flex-col items-center p-0 m-0 bg-transparent border-none outline-none ${className}`}
    aria-label={label}
    onClick={onClick}
    type="button"
  >
    {icon}
    <span className="text-xs mt-1 text-black font-bold">{label}</span>
  </button>
));
IconButton.displayName = "IconButton";
