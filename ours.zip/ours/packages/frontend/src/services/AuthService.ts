import { apiService } from "#ours/frontend/services/ApiService.ts";
import type { UserType } from "#ours/frontend/types/index.ts";
import { getUserToken } from "#ours/frontend/utils/sessionUtils.ts";

/**
 * Authentication service for managing IVS Chat tokens
 * This service handles secure token generation via backend API using axios
 */

export interface TokenRequest {
  roomId: string;
  userId: string;
  username?: string;
  capabilities?: string[];
  sessionDurationInMinutes?: number;
  // New fields for user management
  nickname?: string;
  userType?: UserType;
  authToken?: string;
}

export interface JoinChatRequest {
  nickname: string;
  channelId: string;
  userType?: UserType;
  authToken?: string;
  userId?: string;
}

export interface NicknameAvailabilityResponse {
  success: boolean;
  nickname: string;
  available: boolean;
  reason?: string;
  error?: string;
}

export interface TokenResponse {
  success: boolean;
  token?: string;
  endpoint?: string;
  roomId?: string;
  userId?: string;
  tokenExpirationTime?: string;
  sessionExpirationTime?: string;
  room?: {
    arn?: string;
    id?: string;
    name?: string;
    createTime?: string;
    updateTime?: string;
    maximumMessageRatePerSecond?: number;
    maximumMessageLength?: number;
  };
  user?: {
    id: string;
    nickname: string;
    type: string;
    isRegistered: boolean;
    chatUserId: string;
  };
  error?: string;
  action?: string;
  details?: string;
}

export interface RoomInfo {
  arn?: string;
  id?: string;
  name?: string;
  createTime?: string;
  updateTime?: string;
  maximumMessageRatePerSecond?: number;
  maximumMessageLength?: number;
  tags?: Record<string, string>;
}

export interface RoomListResponse {
  success: boolean;
  rooms?: RoomInfo[];
  nextToken?: string;
  error?: string;
}

export interface RoomResponse {
  success: boolean;
  room?: RoomInfo;
  error?: string;
}

export interface EventResponse {
  success: boolean;
  eventId?: string;
  eventTime?: string;
  error?: string;
}

export class AuthService {
  private tokenCache: Map<string, { token: string; expiry: number }> = new Map();

  /**
   * Cache token with expiry
   */
  private cacheToken(channelId: string, nickname: string, token: string, expirationTime: string): void {
    const cacheKey = `${channelId}:${nickname}`;
    const expiry = new Date(expirationTime).getTime();
    this.tokenCache.set(cacheKey, { token, expiry });
  }

  async joinChatReadOnly(channelId: string): Promise<TokenResponse> {
    const data = await apiService.post<TokenResponse>("/api/chat/connect-readonly", {
      channelId,
    });

    return data;
  }

  async joinChatTemporary(request: JoinChatRequest) {
    const resp = await apiService.postWithErrorCheck<TokenResponse>("/api/chat/connect-temporary", {
      nickname: request.nickname,
      channelId: request.channelId,
      userType: request.userType || "temporary",
      authToken: request.authToken,
      userId: request.userId,
    });
    if (resp.status === "error") {
      return {
        success: false,
        error: resp.data.error,
        reason: resp.data.reason,
        token: null,
      } as const;
    }
    const data = resp.data;
    if (data.token && data.tokenExpirationTime) {
      this.cacheToken(request.channelId, request.nickname, data.token, data.tokenExpirationTime);
    }
    return {
      success: true,
      token: data,
      error: null,
      reason: null,
    } as const;
  }

  async joinChatRegistered({ roomId, token }: { roomId: string; token?: string }): Promise<TokenResponse> {
    const userToken = getUserToken();
    const data = await apiService.post<TokenResponse>(
      "/api/chat/connect-registered",
      {
        channelId: roomId,
      },
      {},
      {
        Authorization: `Bearer ${token || userToken}`,
      },
    );
    return data;
  }

  /**
   * Check nickname availability
   */
  async checkNicknameAvailability(
    nickname: string,
    userType: UserType = "temporary",
  ): Promise<NicknameAvailabilityResponse> {
    try {
      const response = await apiService.get<NicknameAvailabilityResponse>(
        `/api/nicknames/${encodeURIComponent(nickname)}/availability`,
        {
          params: { userType },
        },
      );

      return response;
    } catch (error) {
      console.error("Error checking nickname availability:", error);

      return {
        success: false,
        nickname,
        available: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }

  /**
   * Leave chat
   */
  async leaveChat(nickname: string, channelId: string): Promise<{ success: boolean; error?: string }> {
    const data = await apiService.post<{ success: boolean; error?: string }>("/api/chat/leave", {
      nickname,
      channelId,
    });
    return data;
  }

  /**
   * Update user activity (heartbeat)
   */
  async updateActivity(nickname: string): Promise<{ success: boolean; error?: string }> {
    const data = await apiService.post<{ success: boolean; error?: string }>("/api/chat/activity", {
      nickname,
    });
    return data;
  }

  /**
   * Check if we have a valid cached token
   */
  getCachedToken(roomId: string, userId: string): string | null {
    const cacheKey = `${roomId}:${userId}`;
    const cached = this.tokenCache.get(cacheKey);

    if (!cached) {
      return null;
    }

    // Check if token is still valid (with 5 minute buffer)
    const now = Date.now();
    const buffer = 5 * 60 * 1000; // 5 minutes

    if (now >= cached.expiry - buffer) {
      this.tokenCache.delete(cacheKey);
      return null;
    }

    return cached.token;
  }

  /**
   * Get cached token by nickname (new method)
   */
  getCachedTokenByNickname(channelId: string, nickname: string): string | null {
    const cacheKey = `${channelId}:${nickname}`;
    const cached = this.tokenCache.get(cacheKey);

    if (!cached) {
      return null;
    }

    // Check if token is still valid (with 5 minute buffer)
    const now = Date.now();
    const buffer = 5 * 60 * 1000; // 5 minutes

    if (now >= cached.expiry - buffer) {
      this.tokenCache.delete(cacheKey);
      return null;
    }

    return cached.token;
  }

  /**
   * Clear token cache
   */
  clearCache(): void {
    this.tokenCache.clear();
  }

  /**
   * Get specific room details from backend using axios
   */
  async getRoom(roomId: string): Promise<RoomResponse> {
    try {
      const data = await apiService.get<RoomResponse>(`/api/rooms/${encodeURIComponent(roomId)}`);
      return data;
    } catch (error) {
      console.error("Error getting room:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      };
    }
  }
}
