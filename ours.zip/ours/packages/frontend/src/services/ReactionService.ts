import { apiService } from "#ours/frontend/services/ApiService.ts";

class ReactionService {
  async toggleReaction<T>(roomId: string, messageId: string, reaction: string, userId: string): Promise<T> {
    return apiService.post<T>(`/api/rooms/${roomId}/messages/${messageId}/reactions`, { reaction, userId });
  }
}

export const reactionService = new ReactionService();
