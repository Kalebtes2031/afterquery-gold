import { apiService } from "./ApiService";

class MessagesService {
  async getChannelMessages(channelId: string): Promise<{
    success: boolean;
    messages: Array<{
      id: string;
      content: string;
      userId: string;
      username: string;
      timestamp: string;
      channelId: string;
      userType?: string;
      isRegistered?: string;
    }>;
    count: number;
    error?: string;
  }> {
    return apiService.get(`/api/messages/${encodeURIComponent(channelId)}`);
  }

  async storeMessage(message: {
    id: string;
    content: string;
    userId: string;
    username: string;
    timestamp: string;
    channelId: string;
    userType?: string;
    isRegistered?: string;
  }): Promise<{ success: boolean; message?: string; error?: string }> {
    return apiService.post("/api/messages", message);
  }
}

export const messagesService = new MessagesService();
