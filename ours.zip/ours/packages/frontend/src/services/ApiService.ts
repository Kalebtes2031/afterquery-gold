import axios, { type AxiosInstance, type InternalAxiosRequestConfig } from "axios";

// Centralized API configuration
class API {
  private readonly instance: AxiosInstance;

  constructor() {
    this.instance = axios.create({
      headers: {
        "Content-Type": "application/json",
      },
      // Add a timeout for requests
      timeout: 5000,
    });

    this.setupInterceptors();
  }

  private setupInterceptors() {
    // Request interceptor to dynamically add the auth token
    this.instance.interceptors.request.use(
      (config: InternalAxiosRequestConfig) => {
        const token = sessionStorage.getItem("AuthorizationToken");
        if (token) {
          // Standard Authorization header
          config.headers.Authorization = `Bearer ${token}`;
          // Also keep the custom header for compatibility if needed
          config.headers.AuthorizationToken = token;
        }
        return config;
      },
      (error) => {
        return Promise.reject(error);
      },
    );

    // Response interceptor for global error handling
    this.instance.interceptors.response.use(
      (response) => {
        // Return the response data directly
        return response;
      },
      (error) => {
        // Handle global errors here, e.g., 401 Unauthorized
        if (error.response?.status === 401) {
          // Example: redirect to login page
          console.error("Unauthorized request. Consider redirecting to login.");
          // globalThis.location.href = '/login';
        }
        return Promise.reject(error);
      },
    );
  }

  get http() {
    return this.instance;
  }
}

// ApiService class to interact with the backend
class ApiService {
  private readonly api = new API();

  async get<T>(url: string, params?: object, headers?: Record<string, string>): Promise<T> {
    const response = await this.api.http.get<T>(url, { params, headers });
    return response.data;
  }

  async postWithErrorCheck<T>(url: string, data: object, params?: object, headers?: Record<string, string>) {
    try {
      const response = await this.api.http.post<T>(url, data, { params, headers });
      return {
        data: response.data,
        status: "success",
      } as const;
    } catch (error) {
      const err1 = error as { response: { status: number } };
      if (err1.response.status === 409) {
        const err2 = error as { response: { data: { error: string; reason: string } } };
        return {
          data: err2.response.data,
          status: "error",
        } as const;
      }
      throw err1;
    }
  }

  async post<T>(url: string, data: object, params?: object, headers?: Record<string, string>): Promise<T> {
    const response = await this.api.http.post<T>(url, data, { params, headers });
    return response.data;
  }

  async put<T>(url: string, data: object, params?: object, headers?: Record<string, string>): Promise<T> {
    const response = await this.api.http.put<T>(url, data, { params, headers });
    return response.data;
  }

  async delete<T>(url: string, params?: object, headers?: Record<string, string>): Promise<T> {
    const response = await this.api.http.delete<T>(url, { params, headers });
    return response.data;
  }
}

// Export a singleton instance of the ApiService
export const apiService = new ApiService();
