import { DeleteMessageCommand, DisconnectUserCommand, IvschatClient } from "@aws-sdk/client-ivschat";
import { CHAT_EVENTS, type ChatEventsTypes } from "#ours/frontend/constants/index.ts";
import { EventEmitter } from "#ours/frontend/utils/event-emitter.ts";

/**
 * IVS Chat Service using AWS SDK directly in the frontend
 * This service handles all IVS Chat operations using proper authentication tokens
 */

export interface SenderAttributes {
  channelRole?: string;
  isRegistered?: string;
  chatUserId?: string;
  userType?: string;
  username?: string;
}

export interface ChatMessage {
  id: string;
  content: string;
  userId: string;
  username?: string;
  timestamp: string;
  attributes?: Record<string, string>; // Timestamp, username
  sender?: {
    userId: string;
    attributes?: SenderAttributes & Record<string, string>; // channelRole, isRegistered, chatUserId, userType, username
  };
  reactions?: Reaction[];
}

export interface Reaction {
  reaction: string;
  count: number;
  users?: string[]; // IDs of users who reacted
}

export interface ChatEvent {
  eventName: string;
  attributes: Record<string, string>;
  timestamp: string;
  sender?: {
    userId: string;
    attributes?: Record<string, string>;
  };
}

export type ChatEventReaction = Omit<ChatEvent, "eventName" | "attributes"> & {
  eventName: ChatEventsTypes["REACTION"];
  attributes: {
    messageId: string;
    reaction: string;
    type: string;
    userId: string;
  };
};

export const isChatEventReaction = (event: ChatEvent): event is ChatEventReaction => {
  return event.eventName === CHAT_EVENTS.REACTION;
};

export interface ConnectionConfig {
  roomId: string;
  userId: string;
  username: string;
  token: string;
  endpoint: string;
  region?: string;
}

export interface ConnectionStatus {
  state: "disconnected" | "connecting" | "connected" | "error";
  message?: string;
}

interface IVSIncomingMessage {
  Type?: string;
  Id?: string;
  Content?: string;
  Sender?: {
    UserId?: string;
    Attributes?: Record<string, string>;
  };
  SendTime?: string;
  Attributes?: Record<string, string>;
  EventName?: string;
  Reason?: string;
  [key: string]: unknown;
}

type IVSEventMap = {
  message: [ChatMessage];
  event: [ChatEvent];
  error: [Error];
  connectionStatusChange: [ConnectionStatus];
  unknown: [unknown];
};

export class IVSChatService extends EventEmitter<IVSEventMap> {
  private ws: WebSocket | null = null;
  private client: IvschatClient | null = null;
  private config: ConnectionConfig | null = null;
  private connectionState: ConnectionStatus = { state: "disconnected" };
  private heartbeatInterval: NodeJS.Timeout | null = null;

  /**
   * Connect to IVS Chat using WebSocket
   */
  async connect(config: ConnectionConfig): Promise<void> {
    if (this.connectionState.state === "connected" || this.connectionState.state === "connecting") {
      // console.log("Already connected or connecting");
      return;
    }

    this.config = config;

    // Initialize AWS SDK client (for server-side operations if needed)
    if (config.region) {
      this.client = new IvschatClient({
        region: config.region,
        // Note: No credentials here - we use the token for WebSocket connection
      });
    }

    try {
      this.updateConnectionState({ state: "connecting", message: "Connecting to IVS Chat..." });

      console.log(`Room: ${config.roomId}`);

      // Create WebSocket connection with token as subprotocol
      this.ws = new WebSocket(config.endpoint, config.token);
      this.setupWebSocketHandlers();
    } catch (error) {
      console.error("Connection error:", error);
      this.updateConnectionState({
        state: "error",
        message: error instanceof Error ? error.message : "Connection failed",
      });
    }
  }

  /**
   * Disconnect from IVS Chat
   */
  disconnect(): void {
    this.stopHeartbeat();

    if (this.ws) {
      this.ws.close(1000, "Manual disconnect");
      this.ws = null;
    }

    this.updateConnectionState({ state: "disconnected", message: "Disconnected" });
  }

  /**
   * Send a message to the chat
   */
  async sendMessage(content: string, attributes?: Record<string, string>): Promise<boolean> {
    if (!this.isConnected()) {
      console.error("Cannot send message: not connected");
      return false;
    }

    const messagePayload = {
      Action: "SEND_MESSAGE",
      Content: content,
      Attributes: {
        username: this.config?.username || "Unknown",
        timestamp: new Date().toISOString(),
        ...attributes,
      },
    };

    this.ws?.send(JSON.stringify(messagePayload));
    console.log("Message sent:", content);
    return true;
  }

  /**
   * Send an event to the chat
   */
  async sendEvent(eventName: string, attributes: Record<string, string>): Promise<boolean> {
    if (!this.isConnected()) {
      console.error("Cannot send event: not connected");
      return false;
    }

    const eventPayload = {
      Action: "SEND_EVENT",
      EventName: eventName,
      Attributes: {
        username: this.config?.username || "Unknown",
        timestamp: new Date().toISOString(),
        ...attributes,
      },
    };

    this.ws?.send(JSON.stringify(eventPayload));
    console.log("Event sent:", eventName, attributes);
    return true;
  }

  /**
   * Delete a message (requires appropriate permissions)
   */
  async deleteMessage(messageId: string, reason?: string): Promise<boolean> {
    if (!this.client || !this.config) {
      console.error("Cannot delete message: client not initialized");
      return false;
    }

    try {
      const command = new DeleteMessageCommand({
        roomIdentifier: this.config.roomId,
        id: messageId,
        reason,
      });

      await this.client.send(command);
      console.log("Message deleted:", messageId);
      return true;
    } catch (error) {
      console.error("Error deleting message:", error);
      return false;
    }
  }

  /**
   * Disconnect a user (requires appropriate permissions)
   */
  async disconnectUser(userId: string, reason?: string): Promise<boolean> {
    if (!this.client || !this.config) {
      console.error("Cannot disconnect user: client not initialized");
      return false;
    }

    try {
      const command = new DisconnectUserCommand({
        roomIdentifier: this.config.roomId,
        userId,
        reason,
      });

      await this.client.send(command);
      console.log("User disconnected:", userId);
      return true;
    } catch (error) {
      console.error("Error disconnecting user:", error);
      return false;
    }
  }

  /**
   * Get current connection status
   */
  getConnectionStatus(): ConnectionStatus {
    return this.connectionState;
  }

  /**
   * Check if connected
   */
  isConnected(): boolean {
    return this.connectionState.state === "connected" && this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }

  /**
   * Get current room info
   */
  getRoomInfo(): { roomId?: string; userId?: string; username?: string } {
    return {
      roomId: this.config?.roomId,
      userId: this.config?.userId,
      username: this.config?.username,
    };
  }

  private setupWebSocketHandlers(): void {
    if (!this.ws) return;

    this.ws.onopen = () => {
      // console.log("IVS Chat WebSocket connected");
      this.updateConnectionState({ state: "connected", message: "Connected to IVS Chat" });
      this.startHeartbeat();
    };

    this.ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        this.handleIncomingMessage(data);
      } catch (error) {
        console.error("Error parsing message:", error);
      }
    };

    this.ws.onclose = (event) => {
      console.log(`WebSocket closed: ${event.code} - ${event.reason}`);
      this.updateConnectionState({
        state: "disconnected",
        message: `Connection closed: ${event.code} ${event.reason}`,
      });
      this.ws = null;
      this.stopHeartbeat();

      // No longer auto-reconnect here - let useChat.ts handle all reconnections
      // This prevents conflicts between reconnection systems
      console.log("WebSocket disconnected, deferring reconnection to useChat.ts");
    };

    this.ws.onerror = (error) => {
      console.error("WebSocket error:", error);
      this.updateConnectionState({ state: "error", message: "Connection error" });
    };
  }

  private handleIncomingMessage(data: IVSIncomingMessage): void {
    switch (data.Type) {
      case "MESSAGE": {
        const message: ChatMessage = {
          id: data.Id || `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          content: data.Content || "",
          userId: data.Sender?.UserId || "unknown",
          username:
            data.Sender?.Attributes?.nickname || data.Sender?.Attributes?.username || data.Sender?.UserId || "unknown",
          timestamp: data.SendTime || new Date().toISOString(),
          attributes: data.Attributes || {},
          sender: data.Sender
            ? {
                userId: data.Sender.UserId ?? "unknown",
                attributes: data.Sender.Attributes,
              }
            : undefined,
        };

        this.emit("message", message);
        break;
      }

      case "EVENT": {
        const event: ChatEvent = {
          eventName: data.EventName || "unknown",
          attributes: data.Attributes || {},
          timestamp: data.SendTime || new Date().toISOString(),
          sender: data.Sender
            ? {
                userId: data.Sender.UserId ?? "unknown",
                attributes: data.Sender.Attributes,
              }
            : undefined,
        };

        this.emit("event", event);
        break;
      }

      case "ERROR":
        console.error("IVS Chat error:", data.Reason || "Unknown error");
        this.emit("error", new Error(data.Reason || "Unknown IVS Chat error"));
        break;

      default:
        console.log("Unknown message type:", data.Type, data);
        this.emit("unknown", data);
    }
  }

  private startHeartbeat(): void {
    this.heartbeatInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        // IVS Chat doesn't require manual ping, but we can log connection status
        console.log("Heartbeat: connection alive");
      }
    }, 30000); // 30 seconds
  }

  private stopHeartbeat(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
    }
  }

  private updateConnectionState(newState: ConnectionStatus): void {
    this.connectionState = newState;
    this.emit("connectionStatusChange", newState);
  }
}
