# OURS / FRONTEND

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh


## Set Environment variables for VITE

```js
VITE_API_URL=https://api.domain.com
VITE_EMBED_URL="${VITE_API_URL}/videos/embed/"
```

## ROLLUP

If you are on a mac, you may need to install the rollup binary:

```sh
npm install -g @rollup/rollup-darwin-arm64@4.46.2
```
