import type { ProxyOptions } from "vite";

export const getProxyConfig = (proxyUrl: string): Record<string, string | ProxyOptions> => {
  return {
    "/api": {
      target: proxyUrl,
      changeOrigin: true,
    },
  };
};
