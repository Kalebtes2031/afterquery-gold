# Testing Suite

This directory contains comprehensive testing infrastructure for the OURS PeerTube frontend application.

## Test Structure

```
repo-root/
├── e2e/                    # End-to-end tests with Playwright (relocated)
│   ├── playwright.config.ts
│   ├── early-signup.spec.ts
│   ├── landing.spec.ts
│   └── stream.spec.ts
└── packages/frontend/tests/
    ├── fixtures/           # Test data and fixtures
    │   └── test-data.json
    └── load/               # Load testing with Artillery
        ├── artillery.yml
        ├── helpers.js
        └── README.md
```

## Quick Start

### Install test dependencies
```bash
npm run install:test-deps
```

### Run the full E2E suite
```bash
npm run test:e2e
```

This root-level script executes the Playwright suite (Chromium + Firefox) using the shared `e2e/` configuration.

### Other available tests
```bash
# Run load tests
npm run test:load

# Run load tests with HTML report
npm run test:load:report
```

## Test Features

### Streaming Tests (`stream.spec.ts`)
- Validates password-protected streams render modals correctly
- Confirms error states for missing streams
- Uses mocked IVS chat and presence services to verify public stream layout without real network dependencies

### Landing Tests (`early-signup.spec.ts`, `landing.spec.ts`)
- Cover marketing funnel copy, form validation, and submission success states
- Assert footer links and community touchpoints remain accurate

### Load Testing (`artillery.yml`)
- **Phases**: Warm-up, Load test, Stress test
- **Scenarios**: Homepage, Stream page, API endpoints
- **Custom Functions**: User interaction simulation and response validation

## Configuration

- **Playwright**: Cross-browser testing (Chromium, Firefox)
- **Artillery**: Configurable load patterns and target URLs
- **Base URL**: `http://localhost:5173` (development server)

## Continuous Integration

Tests are configured for CI environments with:
- Automatic retries on failure
- Multiple output formats (HTML, JSON, JUnit)
- Video recording on failure
- Screenshot capture on failure
