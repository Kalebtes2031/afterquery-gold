function simulateUserInteraction(
  /** @type {{vars: {scrollTime: number}}} */ context,
  /** @type {{emit: (string, string) => void}} */ events,
  /** @type {() => void} */ done,
) {
  // Simulate user scrolling behavior
  context.vars.scrollTime = Math.floor(Math.random() * 5000) + 1000;

  // Add custom metrics
  events.emit("counter", "user.interactions", 1);

  return done();
}

function validateResponse(
  /** @type {{vars: {scrollTime: number}}} */ _requestParams,
  /** @type {{statusCode: number, body: string}} */ response,
  /** @type {{vars: {scrollTime: number}}} */ _context,
  /** @type {{emit: (string, string) => void}} */ ee,
  /** @type {() => void} */ next,
) {
  // Custom response validation
  if (response.statusCode !== 200) {
    ee.emit("error", `Expected 200 but got ${response.statusCode}`);
  }

  // Check for specific content
  if (response.body && !response.body.includes("OURS")) {
    ee.emit("error", "Page does not contain expected branding");
  }

  return next();
}

module.exports = {
  simulateUserInteraction,
  validateResponse,
};
