# Load Testing with Artillery

## Overview
This directory contains Artillery load testing configuration for the OURS PeerTube frontend application.

## Setup
```bash
npm install -g artillery
```

## Running Tests

### Basic load test
```bash
artillery run artillery.yml
```

### Generate HTML report
```bash
artillery run artillery.yml --output report.json
artillery report report.json
```

### Override target URL
```bash
artillery run artillery.yml --target https://your-production-url.com
```

## Test Scenarios

1. **Homepage Load Test** (40% weight)
   - Tests main landing page
   - Exercises marketing content sections
   - Captures page title for validation

2. **Stream Page Load Test** (30% weight)
   - Tests streaming functionality
   - Simulates user interactions

3. **API Endpoints Test** (30% weight)
   - Targets available public endpoints (early access signup is currently paused)
   - Uses random data generation where supported

## Phases

1. **Warm up**: 60s with 5 requests/sec
2. **Load test**: 120s with 10 requests/sec  
3. **Stress test**: 60s with 20 requests/sec

## Custom Functions
- `simulateUserInteraction`: Simulates realistic user behavior
- `validateResponse`: Custom response validation logic

## Metrics
Artillery will report:
- Response times (min, max, median, p95, p99)
- Request rate
- Error rate
- Custom counters (user interactions)