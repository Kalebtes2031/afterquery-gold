import type { NextFunction, Request, Response } from "express";
import { type JWSHeaderParameters, type JWTPayload, jwtVerify } from "jose";

export interface AuthInfo {
  payload: JWTPayload;
  protectedHeader: JWSHeaderParameters;
}

function getJwtSecret(): Uint8Array {
  const secret = process.env.JWT_SECRET || "dev-secret-change-me";
  return new TextEncoder().encode(secret);
}

export async function requireAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization || "";
  const token = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
  if (!token) {
    return res.status(401).json({ error: "Missing Bearer token in Authorization header" });
  }

  const issuer = process.env.JWT_ISSUER || undefined;
  const audience = process.env.JWT_AUDIENCE || undefined;
  const authResp = await (async () => {
    try {
      const { payload, protectedHeader } = await jwtVerify(token, getJwtSecret(), {
        issuer,
        audience,
        clockTolerance: "5s",
      });
      return { payload, protectedHeader };
    } catch {
      return null;
    }
  })();

  if (authResp === null) {
    return res.status(401).json({ error: "Token is invalid" });
  }

  const { payload, protectedHeader } = authResp;
  req.auth = { payload, protectedHeader };
  next();
}
