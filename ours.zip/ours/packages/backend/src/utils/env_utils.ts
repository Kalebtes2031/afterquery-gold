const hasEnvVar = <T extends string | undefined>(val: T): val is Exclude<T, undefined | ""> => {
  return val !== undefined && val !== "";
};

export const checkEnvVar = (key: string, defaultValue?: string) => {
  if (!(key in process.env) || !hasEnvVar(process.env[key])) {
    if (defaultValue !== undefined) {
      return defaultValue;
    }
    throw new Error(`process.env.${key} is not set`);
  }
  return process.env[key];
};
