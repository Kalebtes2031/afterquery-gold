import { createClient, type RedisClientType } from "redis";

let nodeClient: RedisClientType | null = null;

export async function getNodeClient(): Promise<RedisClientType> {
  if (nodeClient?.isOpen) return nodeClient;
  if (!nodeClient) {
    nodeClient = createClient({ url: process.env.REDIS_URL || "redis://localhost:6379" });
    nodeClient.on("error", (err) => console.error("Redis Client Error", err));
  }
  if (!nodeClient.isOpen) {
    await nodeClient.connect();
  }
  return nodeClient;
}

export async function destroyRedisClient(): Promise<void> {
  if (nodeClient?.isOpen) {
    await nodeClient.quit();
  }
  nodeClient = null;
}
