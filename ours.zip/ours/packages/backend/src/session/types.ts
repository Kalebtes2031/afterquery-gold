// Store interface for user session management
import type { UserType } from "#ours/backend/types/chat.ts";

export interface UserSession {
  sessionId: string;
  nickname: string;
  userType: UserType;
  channelId: string;
  joinedAt: number;
  lastActivity: number;
  chatUserId: string;
  id?: string;
  connectionStatus: "active" | "idle" | "disconnected";
}
