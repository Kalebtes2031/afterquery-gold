import { getNodeClient } from "#ours/backend/session/redis.ts";
import type { UserSession } from "#ours/backend/session/types.ts";

const DEFAULT_TTL_SECONDS = 1800;

export async function setUser(
  nickname: string,
  userData: UserSession,
  ttlSeconds = DEFAULT_TTL_SECONDS,
): Promise<string> {
  const client = await getNodeClient();
  const key = `user:${nickname}`;
  const result = await client.setEx(key, ttlSeconds, JSON.stringify(userData));
  return result;
}

export async function getUserByNickname(nickname: string): Promise<UserSession | null> {
  const client = await getNodeClient();
  const key = `user:${nickname}`;
  const userData = await client.get(key);

  if (!userData) return null;

  try {
    return JSON.parse(userData) as UserSession;
  } catch (error) {
    console.error("Error parsing user data from Redis:", error);
    return null;
  }
}

export async function updateUser(nickname: string, userData: UserSession): Promise<string> {
  const client = await getNodeClient();
  const key = `user:${nickname}`;
  const result = await client.setEx(key, 1800, JSON.stringify(userData));
  return result;
}

export async function userExists(nickname: string, userId?: string): Promise<boolean> {
  const client = await getNodeClient();
  const key = `user:${nickname}`;
  const exists = await client.exists(key);
  if (exists === 1) {
    const userData = await getUserByNickname(nickname);
    console.log("userData", userData);
    console.log("userId", userId);
    if (userId && userData?.chatUserId === userId) {
      return false;
    } else {
      return true;
    }
  }
  return false;
}

export async function deleteUser(nickname: string): Promise<boolean> {
  const client = await getNodeClient();
  const key = `user:${nickname}`;
  const result = await client.del(key);
  return result === 1;
}

export async function updateUserActivity(nickname: string): Promise<void> {
  const client = await getNodeClient();
  const key = `user:${nickname}`;
  const userData = await getUserByNickname(nickname);

  if (userData) {
    userData.lastActivity = Date.now();
    await client.setEx(key, DEFAULT_TTL_SECONDS, JSON.stringify(userData));
  }
}

export async function addUserToChannel(channelId: string, nickname: string): Promise<void> {
  const client = await getNodeClient();
  const key = `channel:${channelId}:users`;
  await client.sAdd(key, nickname);
  await client.expire(key, 3600); // 1 hour expiry
}

export async function removeUserFromChannel(channelId: string, nickname: string): Promise<void> {
  const client = await getNodeClient();
  const key = `channel:${channelId}:users`;
  await client.sRem(key, nickname);
}

export async function getChannelUsers(channelId: string): Promise<string[]> {
  const client = await getNodeClient();
  const key = `channel:${channelId}:users`;
  return await client.sMembers(key);
}

export async function getChannelUserCount(channelId: string): Promise<number> {
  const client = await getNodeClient();
  const key = `channel:${channelId}:users`;
  return await client.sCard(key);
}

export async function cleanupExpiredSessions(): Promise<void> {
  const client = await getNodeClient();
  try {
    // Redis automatically handles TTL expiration, but we can do additional cleanup
    const pattern = "user:*";
    const keys = await client.keys(pattern);

    for (const key of keys) {
      const ttl = await client.ttl(key);
      if (ttl === -1) {
        // Key exists but no TTL set
        await client.expire(key, 1800); // Set default TTL
      }
    }
  } catch (error) {
    console.error("Error during Redis cleanup:", error);
  }
}
