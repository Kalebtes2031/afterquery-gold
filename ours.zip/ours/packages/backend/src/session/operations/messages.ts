import type { StoredChatMessage } from "#ours/backend/session/models/message.ts";
import { getNodeClient } from "#ours/backend/session/redis.ts";

const MAX_MESSAGES_PER_CHANNEL = 100;
const MESSAGE_TTL_SECONDS = 24 * 60 * 60; // 24 hours

/**
 * Add a message to a channel's message list
 * Automatically trims to keep only the latest MAX_MESSAGES_PER_CHANNEL messages
 */
export async function addMessage(channelId: string, message: StoredChatMessage): Promise<void> {
  const client = await getNodeClient();
  const key = `channel:${channelId}:messages`;

  // Add message to the beginning of the list (most recent first)
  await client.lPush(key, JSON.stringify(message));

  // Trim the list to keep only the latest MAX_MESSAGES_PER_CHANNEL
  await client.lTrim(key, 0, MAX_MESSAGES_PER_CHANNEL - 1);

  // Set expiry for the key
  await client.expire(key, MESSAGE_TTL_SECONDS);
}

/**
 * Get the latest messages for a channel
 * Returns messages in chronological order (oldest first)
 */
export async function getChannelMessages(channelId: string): Promise<StoredChatMessage[]> {
  const client = await getNodeClient();
  const key = `channel:${channelId}:messages`;

  try {
    // Get all messages (LRANGE 0 -1 gets all elements)
    const messageStrings = await client.lRange(key, 0, -1);

    if (messageStrings.length === 0) return [];

    // Parse messages and reverse to get chronological order (oldest first)
    const messages: StoredChatMessage[] = [];
    for (const messageString of messageStrings.reverse()) {
      try {
        const message = JSON.parse(messageString) as StoredChatMessage;
        messages.push(message);
      } catch (parseError) {
        console.error("Error parsing message from Redis:", parseError);
      }
    }

    return messages;
  } catch (error) {
    console.error("Error retrieving messages from Redis:", error);
    return [];
  }
}

/**
 * Clear all messages for a channel
 */
export async function clearChannelMessages(channelId: string): Promise<void> {
  const client = await getNodeClient();
  const key = `channel:${channelId}:messages`;
  await client.del(key);
}

/**
 * Get message count for a channel
 */
export async function getChannelMessageCount(channelId: string): Promise<number> {
  const client = await getNodeClient();
  const key = `channel:${channelId}:messages`;
  return await client.lLen(key);
}

/**
 * Check if a message exists in a channel (by message ID)
 * Note: This is a more expensive operation as it requires scanning the list
 */
export async function messageExists(channelId: string, messageId: string): Promise<boolean> {
  const messages = await getChannelMessages(channelId);
  return messages.some((msg) => msg.id === messageId);
}

/**
 * Remove a specific message from a channel (by message ID)
 * Note: This is a more expensive operation as it requires finding and removing from list
 */
export async function removeMessage(channelId: string, messageId: string): Promise<boolean> {
  const client = await getNodeClient();
  const key = `channel:${channelId}:messages`;

  try {
    const messageStrings = await client.lRange(key, 0, -1);

    for (let i = 0; i < messageStrings.length; i++) {
      try {
        const message = JSON.parse(messageStrings[i]) as StoredChatMessage;
        if (message.id === messageId) {
          // Remove the message at this position
          // First, set a unique placeholder
          const placeholder = `__DELETE_${Date.now()}_${Math.random()}__`;
          await client.lSet(key, i, placeholder);
          // Then remove all occurrences of the placeholder
          await client.lRem(key, 0, placeholder);
          return true;
        }
      } catch (parseError) {
        console.error("Error parsing message during removal:", parseError);
      }
    }

    return false; // Message not found
  } catch (error) {
    console.error("Error removing message from Redis:", error);
    return false;
  }
}
