// Import all operations
import * as messageOps from "#ours/backend/session/operations/messages.ts";
import * as reactionOps from "#ours/backend/session/operations/reactions.ts";
import * as userOps from "#ours/backend/session/operations/users.ts";

// Export by categories
export const messages = messageOps;
export const reactions = reactionOps;
export const users = userOps;

// Export flat for compatibility (APIs used in other layers)
export const {
  addMessage,
  getChannelMessages,
  clearChannelMessages,
  getChannelMessageCount,
  messageExists,
  removeMessage,
} = messageOps;

export const { addReaction, removeReaction, getMessageReactions, getUserReactionsForMessage, getRoomReactions } =
  reactionOps;

export const {
  setUser,
  getUserByNickname,
  updateUser,
  userExists,
  deleteUser,
  updateUserActivity,
  addUserToChannel,
  removeUserFromChannel,
  getChannelUsers,
  getChannelUserCount,
} = userOps;

// Friendly alias
export const addUser = userOps.setUser;

// Export types
export type { MessageReactions } from "#ours/backend/session/operations/reactions.ts";
