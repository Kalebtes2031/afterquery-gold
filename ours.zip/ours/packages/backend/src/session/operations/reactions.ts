import { createHash } from "node:crypto";
import type { ReactionEventEntity } from "#ours/backend/session/models/index.ts";
import { getNodeClient } from "#ours/backend/session/redis.ts";

export interface MessageReactions {
  messageId: string;
  reactions: Array<{ reaction: string; count: number }>;
  totalCount: number;
}

// Generate a unique ID for the reaction
function generateReactionId(messageId: string, userId: string, reaction: string): string {
  return createHash("sha256").update(`${messageId}:${userId}:${reaction}`).digest("hex").substring(0, 16);
}

// Redis keys for indexing
const KEYS = {
  reaction: (id: string) => `reaction:${id}`,
  messageReactions: (messageId: string) => `message_reactions:${messageId}`,
  userMessageReactions: (userId: string, messageId: string) => `user_message_reactions:${userId}:${messageId}`,
  roomReactions: (roomId: string) => `room_reactions:${roomId}`,
  roomReactionsByTime: (roomId: string) => `room_reactions_by_time:${roomId}`,
};

export async function addReaction(
  messageId: string,
  userId: string,
  reaction: string,
  roomId: string,
): Promise<ReactionEventEntity> {
  const client = await getNodeClient();
  const reactionId = generateReactionId(messageId, userId, reaction);
  const timestamp = new Date();

  // 1. Check if this exact reaction already exists
  const existingKey = KEYS.reaction(reactionId);
  const existing = await client.hGetAll(existingKey);

  if (Object.keys(existing).length > 0) {
    // If it already exists, just update the timestamp
    await client.hSet(existingKey, "timestamp", timestamp.toISOString());
    return {
      messageId,
      userId,
      reaction,
      roomId,
      timestamp,
    };
  }

  // 2. Create the new reaction
  const reactionEntity: ReactionEventEntity = {
    messageId,
    userId,
    reaction,
    roomId,
    timestamp,
  };

  // Use pipeline for atomic operations
  const pipeline = client.multi();

  // Save the reaction data
  pipeline.hSet(existingKey, {
    messageId,
    userId,
    reaction,
    roomId,
    timestamp: timestamp.toISOString(),
  });

  // Add to indices
  pipeline.sAdd(KEYS.messageReactions(messageId), reactionId);
  pipeline.sAdd(KEYS.userMessageReactions(userId, messageId), reactionId);
  pipeline.sAdd(KEYS.roomReactions(roomId), reactionId);

  // Add to sorted set ordered by timestamp
  pipeline.zAdd(KEYS.roomReactionsByTime(roomId), {
    score: timestamp.getTime(),
    value: reactionId,
  });

  await pipeline.exec();

  return reactionEntity;
}

export async function removeReaction(messageId: string, userId: string, reaction: string): Promise<boolean> {
  const client = await getNodeClient();
  const reactionId = generateReactionId(messageId, userId, reaction);

  // Check if the reaction exists
  const reactionKey = KEYS.reaction(reactionId);
  const existing = await client.hGetAll(reactionKey);

  if (Object.keys(existing).length === 0) {
    return false; // The reaction does not exist
  }

  const roomId = existing.roomId;

  // Use pipeline for atomic operations
  const pipeline = client.multi();

  // Delete the reaction
  pipeline.del(reactionKey);

  // Delete from indices
  pipeline.sRem(KEYS.messageReactions(messageId), reactionId);
  pipeline.sRem(KEYS.userMessageReactions(userId, messageId), reactionId);
  pipeline.sRem(KEYS.roomReactions(roomId), reactionId);

  // Delete from sorted set
  pipeline.zRem(KEYS.roomReactionsByTime(roomId), reactionId);

  await pipeline.exec();

  return true;
}

export async function getMessageReactions(messageId: string): Promise<MessageReactions> {
  const client = await getNodeClient();

  // Get all reaction IDs for this message
  const reactionIds = await client.sMembers(KEYS.messageReactions(messageId));

  if (reactionIds.length === 0) {
    return { messageId, reactions: [], totalCount: 0 };
  }

  // Get the data for all reactions
  const pipeline = client.multi();
  for (const reactionId of reactionIds) {
    pipeline.hGetAll(KEYS.reaction(reactionId));
  }

  const results = await pipeline.exec();
  const allReactions: ReactionEventEntity[] = [];

  if (results) {
    for (const result of results) {
      if (result && typeof result === "object" && result !== null) {
        const reactionData = result as unknown as Record<string, string>;
        if (Object.keys(reactionData).length > 0) {
          allReactions.push({
            messageId: reactionData.messageId,
            userId: reactionData.userId,
            reaction: reactionData.reaction,
            roomId: reactionData.roomId,
            timestamp: new Date(reactionData.timestamp),
          });
        }
      }
    }
  }

  // Group and count reactions
  const reactionCounts = new Map<string, number>();
  for (const reactionEntity of allReactions) {
    const current = reactionCounts.get(reactionEntity.reaction) || 0;
    reactionCounts.set(reactionEntity.reaction, current + 1);
  }

  const reactions = Array.from(reactionCounts.entries())
    .map(([reaction, count]) => ({ reaction, count }))
    .sort((a, b) => b.count - a.count);

  const totalCount = reactions.reduce((sum, r) => sum + r.count, 0);

  return { messageId, reactions, totalCount };
}

export async function getUserReactionsForMessage(messageId: string, userId: string): Promise<string[]> {
  const client = await getNodeClient();

  // Get all reaction IDs for this user and message
  const reactionIds = await client.sMembers(KEYS.userMessageReactions(userId, messageId));

  if (reactionIds.length === 0) {
    return [];
  }

  // Get the data for all reactions for this user
  const pipeline = client.multi();
  for (const reactionId of reactionIds) {
    pipeline.hGet(KEYS.reaction(reactionId), "reaction");
  }

  const results = await pipeline.exec();
  const reactions: string[] = [];

  if (results) {
    for (const result of results) {
      if (result && typeof result === "string") {
        reactions.push(result);
      }
    }
  }

  return reactions;
}

export async function getRoomReactions(roomId: string, limit = 100): Promise<ReactionEventEntity[]> {
  const client = await getNodeClient();

  // Get the reaction IDs ordered by timestamp (descending)
  const reactionIds = await client.zRange(KEYS.roomReactionsByTime(roomId), 0, limit - 1, { REV: true });

  if (reactionIds.length === 0) {
    return [];
  }

  // Get the data for all reactions
  const pipeline = client.multi();
  for (const reactionId of reactionIds) {
    pipeline.hGetAll(KEYS.reaction(reactionId));
  }

  const results = await pipeline.exec();
  const reactions: ReactionEventEntity[] = [];

  if (results) {
    for (const result of results) {
      if (result && typeof result === "object" && result !== null) {
        const reactionData = result as unknown as Record<string, string>;
        if (Object.keys(reactionData).length > 0) {
          reactions.push({
            messageId: reactionData.messageId,
            userId: reactionData.userId,
            reaction: reactionData.reaction,
            roomId: reactionData.roomId,
            timestamp: new Date(reactionData.timestamp),
          });
        }
      }
    }
  }

  return reactions;
}

// Advanced search function with time filters
export async function searchRoomReactions(
  roomId: string,
  options?: { since?: number; until?: number; limit?: number },
): Promise<ReactionEventEntity[]> {
  const client = await getNodeClient();
  const limit = options?.limit ?? 100;

  // Define the time range for the search
  let minScore = "-inf";
  let maxScore = "+inf";

  if (options?.since) {
    minScore = options.since.toString();
  }
  if (options?.until) {
    maxScore = options.until.toString();
  }

  // Get the reaction IDs in the specified time range (descending order)
  const reactionIds = await client.zRangeByScore(KEYS.roomReactionsByTime(roomId), minScore, maxScore, {
    LIMIT: { offset: 0, count: limit },
  });

  // Reverse the order to get descending order
  reactionIds.reverse();

  if (reactionIds.length === 0) {
    return [];
  }

  // Get the data for all reactions
  const pipeline = client.multi();
  for (const reactionId of reactionIds) {
    pipeline.hGetAll(KEYS.reaction(reactionId));
  }

  const results = await pipeline.exec();
  const reactions: ReactionEventEntity[] = [];

  if (results) {
    for (const result of results) {
      if (result && typeof result === "object" && result !== null) {
        const reactionData = result as unknown as Record<string, string>;
        if (Object.keys(reactionData).length > 0) {
          reactions.push({
            messageId: reactionData.messageId,
            userId: reactionData.userId,
            reaction: reactionData.reaction,
            roomId: reactionData.roomId,
            timestamp: new Date(reactionData.timestamp),
          });
        }
      }
    }
  }

  return reactions;
}
