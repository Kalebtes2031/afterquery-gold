export interface RoomUserEntity {
  roomId: string;
  arnString?: string;
  nickname?: string;
  joinedAt?: Date;
  isActive?: boolean;
}
