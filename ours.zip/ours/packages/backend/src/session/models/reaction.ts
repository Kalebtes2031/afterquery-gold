export interface ReactionEventEntity {
  messageId: string;
  userId: string;
  reaction: string;
  roomId: string;
  timestamp: Date;
}
