// Chat message entity for session storage
export interface ChatMessageEntity {
  id: string;
  content: string;
  userId: string;
  username: string;
  timestamp: string;
  channelId: string;
  attributes?: Record<string, string>;
  sender?: {
    userId: string;
    attributes?: Record<string, string>;
  };
  reactions?: Array<{
    reaction: string;
    count: number;
    users?: string[];
  }>;
}

// Simplified message for storage (without heavy attributes)
export interface StoredChatMessage {
  id: string;
  content: string;
  userId: string;
  username: string;
  timestamp: string;
  channelId: string;
  // Store essential attributes only
  userType?: string;
  isRegistered?: string;
}
