import type { UserType } from "#ours/backend/types/chat.ts";

export interface UserSessionEntity {
  sessionId: string;
  nickname: string;
  userType: UserType;
  channelId: string;
  joinedAt: Date;
  lastActivity: Date;
  chatUserId: string;
  connectionStatus: "active" | "idle" | "disconnected";
}
