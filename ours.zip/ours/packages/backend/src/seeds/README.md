# Database Seeds

This directory contains seeding files to populate the database with initial data.

## 📁 Available Files

### Individual Seeds
- **`seed_users_new.js`** - Creates initial users (admin, moderator, regular users)
- **`seed_rooms_new.js`** - Creates rooms for live chat
- **`seed_reactions.js`** - Creates example reactions on messages

### Main Seeds
- **`seed_all.js`** - Runs all seeds in the correct order
- **`seed_users.ts`** - (Legacy) Original user seed
- **`seed_rooms.ts`** - (Legacy) Original room seed

## 🚀 Usage

### Run all seeds
```bash
# Complete seed (maintains existing data)
node seeds/seed_all.js

# Complete seed with reset (removes existing data)
node seeds/seed_all.js --reset
```

### Run individual seeds
```bash
# Users only
node seeds/seed_users_new.js

# Rooms only
node seeds/seed_rooms_new.js

# Reactions only (requires existing users and rooms)
node seeds/seed_reactions.js
```

## 📊 Data Created

### Users (`seed_users_new.js`)
- **admin** - Administrator user
- **moderator** - Moderator user  
- **testuser1, testuser2** - Regular test users
- **demo_streamer** - User for streaming demos

### Rooms (`seed_rooms_new.js`)
- **demo** - Demonstration room
- **production** - Production room
- **testing** - Testing room
- **live_concert_1** - Room for live concerts
- **acoustic_session** - Room for acoustic sessions

### Reactions (`seed_reactions.js`)
- Example reactions: 👏, ❤️, 🔥, 😍, 🎵, 🎸, 🎤, ✨
- Distributed across test messages: msg-1 to msg-6
- Created by random users

## ⚙️ Configuration

The seeds use:
- **Sequelize ORM** with functional operations
- **SQLite** as database
- **Automatic duplicate handling** (upsert where possible)
- **Detailed logging** of the process

## 🔧 Customization

To customize the data:

1. **Users**: Edit the `SEED_USERS` array in `seed_users_new.js`
2. **Rooms**: Edit the `SEED_ROOMS` array in `seed_rooms_new.js`  
3. **Reactions**: Edit the `SAMPLE_REACTIONS` and `SAMPLE_MESSAGES` arrays in `seed_reactions.js`

## 📝 Notes

- Seeds are **idempotent** - you can run them multiple times without issues
- Passwords are placeholders - **use bcrypt in production**
- AWS ARNs are examples - **update with your real values**
- The reaction seed requires existing users and rooms

## 🛠️ Troubleshooting

### Error: "Could not initialize database"
- Verify that the configuration file `database/config.js` exists
- Make sure the models are correctly defined

### Error: "No users/rooms in database"
- First run `seed_users_new.js` and `seed_rooms_new.js`
- Or use `seed_all.js` to run everything in order

### Duplicates
- Seeds handle duplicates automatically
- Informative messages indicate if an element already existed