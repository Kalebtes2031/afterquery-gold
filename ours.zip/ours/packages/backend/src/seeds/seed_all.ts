import "dotenv/config";
import { closeDatabase, initializeDatabase } from "#ours/backend/database/config.ts";
import { seedRoomOwners } from "#ours/backend/seeds/seed_room_owners.ts";
import { seedRooms } from "#ours/backend/seeds/seed_rooms.ts";
import { seedUsers } from "#ours/backend/seeds/seed_users.ts";

/**
 * Runs all seeds in the correct order
 */
export async function seedAll(): Promise<void> {
  await seedUsers();
  await seedRooms();
  await seedRoomOwners();
  console.log("🌱 Seeding completed");
}

/**
 * Runs seeding with option to reset the database
 */
export async function seedAllWithReset(shouldReset = false): Promise<void> {
  // Ensure DB is ready
  const dbInitialized = await initializeDatabase();
  if (!dbInitialized) {
    throw new Error("Could not initialize database");
  }
  if (shouldReset) {
    console.log("🔄 Resetting database...");
    const { resetDatabase } = await import("#ours/backend/database/config.ts");
    await resetDatabase();
    console.log("✅ Database reset\n");
  }

  await seedAll();
}

// Run seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const shouldReset = process.argv.includes("--reset");

  if (shouldReset) {
    console.log("⚠️  Reset mode activated - all existing data will be removed");
  }

  seedAllWithReset(shouldReset)
    .then(() => {
      console.log("✅ Seeding successful");
      process.exit(0);
    })
    .catch((error) => {
      console.error("❌ Error in seeding:", error);
      process.exit(1);
    })
    .finally(async () => {
      await closeDatabase();
    });
}
