import "dotenv/config";
import { closeDatabase, initializeDatabase } from "#ours/backend/database/config.ts";
import { rooms, users } from "#ours/backend/database/operations/index.ts";

interface SeedRoomOwnerData {
  roomId: string;
  email: string;
}

// Definitions of owners by room
const SEED_ROOM_OWNERS: SeedRoomOwnerData[] = [{ roomId: "demo", email: "streamer@ours.app" }];

export async function seedRoomOwners(): Promise<void> {
  let createdCount = 0;
  let skippedCount = 0;

  for (const mapping of SEED_ROOM_OWNERS) {
    try {
      const user = await users.getUserByEmail(mapping.email);
      if (!user) {
        console.error(`❌ User not found: '${mapping.email}'. Skipping assignment for room '${mapping.roomId}'.`);
        skippedCount++;
        continue;
      }

      const ok = await rooms.addOwnerToRoom(mapping.roomId, user.id);
      if (ok) createdCount++;
      else skippedCount++;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown error";
      console.error(`❌ Error assigning owner '${mapping.email}' to room '${mapping.roomId}':`, message);
    }
  }

  console.log(
    `👑 Room owners seeding → created: ${createdCount}, skipped: ${skippedCount}, total: ${SEED_ROOM_OWNERS.length}`,
  );
}

// Direct execution of the seed
if (import.meta.url === `file://${process.argv[1]}`) {
  (async () => {
    const dbInitialized = await initializeDatabase();
    if (!dbInitialized) {
      throw new Error("Could not initialize database");
    }
    try {
      await seedRoomOwners();
      console.log("✅ Room owners seeding done");
    } finally {
      await closeDatabase();
    }
  })();
}
