import "dotenv/config";
import { CHAT_USER_TYPES } from "#ours/backend/constants/index.ts";
import { closeDatabase, initializeDatabase } from "#ours/backend/database/config.ts";
import { type CreateUserData, users } from "#ours/backend/database/operations/index.ts";

// User data for seeding
const SEED_USERS: CreateUserData[] = [
  {
    nickname: "admin",
    email: "admin@ours.app",
    userType: CHAT_USER_TYPES.ADMIN,
    passwordHash: "hashed_password_placeholder", // Use bcrypt in production
    isActive: true,
  },
  {
    nickname: "moderator",
    email: "moderator@ours.app",
    userType: CHAT_USER_TYPES.MODERATOR,
    passwordHash: "hashed_password_placeholder",
    isActive: true,
  },
  {
    nickname: "testuser1",
    email: "testuser1@ours.app",
    userType: CHAT_USER_TYPES.REGULAR,
    passwordHash: "hashed_password_placeholder",
    isActive: true,
  },
  {
    nickname: "testuser2",
    email: "testuser2@ours.app",
    userType: CHAT_USER_TYPES.REGULAR,
    passwordHash: "hashed_password_placeholder",
    isActive: true,
  },
  {
    nickname: "demo_streamer",
    email: "streamer@ours.app",
    username: "Streamer DJ",
    userType: CHAT_USER_TYPES.ARTIST,
    passwordHash: "hashed_password_placeholder",
    isActive: true,
  },
];

export async function seedUsers(): Promise<void> {
  let createdCount = 0;
  let existingCount = 0;

  for (const userData of SEED_USERS) {
    try {
      await users.createUser(userData);
      createdCount++;
    } catch (error) {
      const err = error as { name?: string; message?: string } | undefined;
      const name = err?.name ?? "";
      const message = err?.message ?? "";
      if (name === "SequelizeUniqueConstraintError" || message.includes("UNIQUE constraint failed")) {
        existingCount++;
      } else {
        console.error(`❌ Error creating user '${userData.nickname}':`, message || error);
      }
    }
  }

  console.log(`👥 Users seeding → created: ${createdCount}, existing: ${existingCount}, total: ${SEED_USERS.length}`);
}

// Run seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  (async () => {
    const dbInitialized = await initializeDatabase();
    if (!dbInitialized) {
      throw new Error("Could not initialize database");
    }
    try {
      await seedUsers();
      console.log("✅ User seeding done");
    } finally {
      await closeDatabase();
    }
  })();
}
