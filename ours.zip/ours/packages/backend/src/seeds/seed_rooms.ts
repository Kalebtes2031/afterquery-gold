import "dotenv/config";
import { closeDatabase, initializeDatabase } from "#ours/backend/database/config.ts";
import { rooms } from "#ours/backend/database/operations/index.ts";

interface SeedRoomData {
  roomId: string;
  arnString: string;
}

// Room data for seeding
const SEED_ROOMS: SeedRoomData[] = [
  {
    roomId: "demo",
    arnString: "arn:aws:ivschat:us-west-2:132205776066:room/ikLwju6EN8d7",
  },
  {
    roomId: "production",
    arnString: "arn:aws:ivschat:us-west-2:132205776066:room/productionRoomId",
  },
  {
    roomId: "testing",
    arnString: "arn:aws:ivschat:us-west-2:132205776066:room/testingRoomId",
  },
  {
    roomId: "live_concert_1",
    arnString: "arn:aws:ivschat:us-west-2:132205776066:room/liveConcert1",
  },
  {
    roomId: "acoustic_session",
    arnString: "arn:aws:ivschat:us-west-2:132205776066:room/acousticSession",
  },
];

export async function seedRooms(): Promise<void> {
  let processedCount = 0;

  for (const roomData of SEED_ROOMS) {
    try {
      await rooms.createOrUpdateRoom(roomData.roomId, roomData.arnString);
      processedCount++;
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown error";
      console.error(`❌ Error processing room '${roomData.roomId}':`, message);
    }
  }

  const allRooms = await rooms.getAllActiveRooms();
  console.log(`🏠 Rooms seeding → processed: ${processedCount}, active: ${allRooms.length}`);
}

// Run seeding if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  (async () => {
    const dbInitialized = await initializeDatabase();
    if (!dbInitialized) {
      throw new Error("Could not initialize database");
    }
    try {
      await seedRooms();
      console.log("✅ Room seeding done");
    } catch (error) {
      console.error("❌ Error in room seeding:", error);
      process.exitCode = 1;
    } finally {
      await closeDatabase();
    }
  })();
}
