import express, { type Request, type Response } from "express";
import { userManager } from "#ours/backend/services/user_manager";
import type {
  IErrorResponse,
  INicknameAvailabilityParams,
  INicknameAvailabilityQuery,
  INicknameAvailabilityResponse,
} from "#ours/backend/types/chat.ts";

const router = express.Router();

// Check nickname availability
router.get(
  "/nickname/:nickname/availability",
  async (
    req: Request<
      INicknameAvailabilityParams,
      INicknameAvailabilityResponse | IErrorResponse,
      Record<string, never>,
      INicknameAvailabilityQuery
    >,
    res: Response<INicknameAvailabilityResponse | IErrorResponse>,
  ) => {
    const { nickname } = req.params;
    const { userType = "temporary" } = req.query;

    // Validate nickname format
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(nickname)) {
      return res.status(400).json({
        error: "Invalid nickname format. Use 3-20 characters, letters, numbers, and underscores only.",
      });
    }

    const parsedUserType =
      userType === "temporary" ||
      userType === "regular" ||
      userType === "artist" ||
      userType === "moderator" ||
      userType === "admin"
        ? (userType as typeof userType)
        : "temporary";

    const availability = await userManager.isNicknameAvailable(nickname, parsedUserType);

    res.json({
      success: true,
      nickname,
      available: availability.available,
      reason: availability.reason,
    });
  },
);

export default router;
