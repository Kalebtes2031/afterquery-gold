import express, { type Request, type Response } from "express";
import { SignJWT } from "jose";
import { users } from "#ours/backend/database/operations/index.ts";
import { requireAuth } from "#ours/backend/middlewares/auth.ts";

const router = express.Router();

function getJwtSecret(): Uint8Array {
  const secret = process.env.JWT_SECRET;
  return new TextEncoder().encode(secret);
}

interface LoginBody {
  email: string;
  password: string;
}

router.post("/login", async (req: Request<unknown, unknown, LoginBody>, res: Response) => {
  const { email } = req.body || ({} as LoginBody);
  const hashedPassword = "hashed_password_placeholder";

  const user = await users.getUserByEmailAndHash(email, hashedPassword);

  const token = await new SignJWT({
    id: user?.id,
    username: user?.username,
    nickname: user?.nickname,
    email: user?.email,
    userType: user?.userType,
    chatUserId: "1234567890",
  })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("24h")
    .sign(getJwtSecret());

  return res.json({ token });
});

router.get("/profile", requireAuth, async (req: Request, res: Response) => {
  if (!req.auth) {
    return res.status(401).json({ error: "Authentication required" });
  }
  const { payload, protectedHeader } = req.auth;
  return res.json({ ok: true, alg: protectedHeader.alg, payload });
});

export default router;
