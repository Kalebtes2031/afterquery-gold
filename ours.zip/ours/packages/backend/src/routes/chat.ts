import { ChatTokenCapability } from "@aws-sdk/client-ivschat";
import { clerkClient, getAuth, requireAuth } from "@clerk/express";
import express, { type Request, type Response } from "express";
import { v4 as uuidv4 } from "uuid";
import { CHAT_CHANNEL_ROLES, CHAT_USER_TYPES } from "#ours/backend/constants/index.ts";
import { roomOwners, rooms, users } from "#ours/backend/database/operations/index.ts";
import { createIVSChatService, type IVSChatConfig } from "#ours/backend/services/ivs_chat_client.ts";
import { userManager } from "#ours/backend/services/user_manager";
import type { UserSession } from "#ours/backend/session/types.ts";
import type {
  IActivityUpdateRequest,
  IActivityUpdateResponse,
  IChatTokenResponse,
  IConnectReadOnlyRequest,
  IErrorResponse,
  IJoinChatRequest,
  ILeaveChatRequest,
  ILeaveChatResponse,
} from "#ours/backend/types/chat.ts";
import { checkEnvVar } from "#ours/backend/utils/env_utils.ts";
import { invalidNicknameMessage, isValidNickname } from "#ours/shared/inputValidation.ts";

const router = express.Router();

const ivsConfig: IVSChatConfig = {
  region: checkEnvVar("IVS_AWS_REGION", "us-east-1"),
  accessKeyId: checkEnvVar("IVS_AWS_ACCESS_KEY_ID"),
  secretAccessKey: checkEnvVar("IVS_AWS_SECRET_ACCESS_KEY"),
};

const chatService = createIVSChatService(ivsConfig);

type RegisteredUserRecord = Awaited<ReturnType<typeof users.getUserById>>;

const loadRegisteredUser = async (
  clerkId: string,
  email?: string,
  preferredUsername?: string | null,
): Promise<RegisteredUserRecord> => {
  let user = await users.getUserById(clerkId);
  if (user) {
    return user;
  }
  user = await users.getUserByToken(clerkId);
  if (user) {
    return user;
  }
  if (email) {
    user = await users.getUserByEmail(email);
    if (user) {
      return user;
    }
  }
  if (preferredUsername) {
    user = await users.getUserByNickname(preferredUsername);
    if (user) {
      return user;
    }
  }
  return null;
};

const ensureRegisteredUser = async (
  clerkId: string,
  displayName: string,
  email?: string,
  preferredUsername?: string | null,
): Promise<RegisteredUserRecord> => {
  let user = await loadRegisteredUser(clerkId, email, preferredUsername);

  if (!user) {
    await users.createUser({
      nickname: displayName,
      email,
      userType: CHAT_USER_TYPES.REGULAR,
      token: clerkId,
      username: preferredUsername ?? null,
    });
    user = await loadRegisteredUser(clerkId, email, preferredUsername);
  } else {
    const updates: { nickname?: string; username?: string | null; email?: string; token?: string } = {};
    if (user.nickname !== displayName) {
      updates.nickname = displayName;
    }
    if (preferredUsername !== undefined && preferredUsername !== null && user.username !== preferredUsername) {
      updates.username = preferredUsername;
    }
    if (email && user.email !== email) {
      updates.email = email;
    }
    if (user.token !== clerkId) {
      updates.token = clerkId;
    }
    if (Object.keys(updates).length > 0) {
      await users.updateUser(user.id, updates);
      user = await loadRegisteredUser(clerkId, email, preferredUsername);
    }
  }

  if (user) {
    await users.updateLastLogin(user.id);
  }

  return user;
};

router.post("/connect-registered", requireAuth(), async (req, res) => {
  const auth = getAuth(req);
  if (!auth || !auth.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }

  const { channelId } = req.body;

  if (typeof channelId !== "string" || channelId.trim() === "") {
    return res.status(400).json({ error: "Missing required parameter: channelId" });
  }

  const room = await rooms.getRoomByArn(channelId);
  if (!room) {
    return res.status(404).json({ error: "Room not found" });
  }

  const clerkUser = await clerkClient.users.getUser(auth.userId);

  const email = clerkUser.primaryEmailAddress?.emailAddress ?? undefined;
  const preferredUsername = clerkUser.username ?? clerkUser.primaryEmailAddress?.emailAddress?.split("@")[0];
  const displayName =
    preferredUsername ?? clerkUser.firstName ?? clerkUser.lastName ?? clerkUser.id.replace("user_", "");

  const registeredUser = await ensureRegisteredUser(auth.userId, displayName, email, preferredUsername);

  if (!registeredUser) {
    return res.status(500).json({ error: "Unable to load user profile" });
  }

  const chatNickname = registeredUser.nickname;
  const chatUserId = registeredUser.id;
  const isOwner = await roomOwners.getOwnedRoomByUserId(chatUserId, room.id);
  const userType = registeredUser.userType ?? CHAT_USER_TYPES.REGULAR;

  let capabilities: ChatTokenCapability[] = [ChatTokenCapability.SEND_MESSAGE];
  if (isOwner || userType === CHAT_USER_TYPES.MODERATOR || userType === CHAT_USER_TYPES.ADMIN) {
    capabilities = [...capabilities, ChatTokenCapability.DISCONNECT_USER, ChatTokenCapability.DELETE_MESSAGE];
  }

  const tokenResponse = await chatService.createChatToken({
    roomIdentifier: room.arnString,
    userId: chatUserId,
    capabilities,
    sessionDurationInMinutes: 60,
    attributes: {
      username: registeredUser.username ?? chatNickname,
      nickname: chatNickname,
      userType,
      channelRole: isOwner ? CHAT_CHANNEL_ROLES.OWNER : CHAT_CHANNEL_ROLES.VIEWER,
      isRegistered: "true",
      chatUserId,
    },
  });

  if (!tokenResponse.token) {
    return res.status(500).json({ error: "Failed to generate chat token" });
  }

  const response: IChatTokenResponse = {
    success: true,
    token: tokenResponse.token || "",
    endpoint: chatService.getWebSocketEndpoint(),
    roomId: room.arnString,
    userId: chatUserId,
    tokenExpirationTime: tokenResponse.tokenExpirationTime,
    sessionExpirationTime: tokenResponse.sessionExpirationTime,
    user: {
      id: chatUserId,
      nickname: chatNickname,
      username: registeredUser.username ?? chatNickname,
      userType,
      channelRole: isOwner ? CHAT_CHANNEL_ROLES.OWNER : CHAT_CHANNEL_ROLES.VIEWER,
      isRegistered: true,
      chatUserId,
    },
  };

  res.json(response);
});

// Join chat endpoint - creates user session and IVS token
router.post(
  "/connect-temporary",
  async (
    req: Request<Record<string, never>, IChatTokenResponse | IErrorResponse, IJoinChatRequest>,
    res: Response<IChatTokenResponse | IErrorResponse>,
  ) => {
    const { nickname, channelId: arnString, userId } = req.body;

    // Validate required parameters
    if (!nickname || !arnString) {
      return res.status(400).json({
        error: "Missing required parameters: nickname and channelId are required",
      });
    }

    // Validate nickname format
    if (!isValidNickname(nickname)) {
      return res.status(400).json({
        error: invalidNicknameMessage,
      });
    }

    // Check nickname availability (only temporary users supported)
    const availability = await userManager.isNicknameAvailable(nickname, CHAT_USER_TYPES.TEMPORARY, userId);
    if (!availability.available) {
      return res.status(409).json({
        error: "This username is already in use",
        reason: availability.reason,
      });
    }

    let userResult = null;

    if (userId) {
      const result = await userManager.getUser(nickname);
      const now = Date.now();
      const sessionData = {
        sessionId: userId,
        nickname,
        userType: CHAT_USER_TYPES.TEMPORARY as UserSession["userType"],
        channelId: arnString,
        joinedAt: result?.joinedAt ? new Date(result.joinedAt).getTime() : now,
        lastActivity: now,
        chatUserId: userId,
        connectionStatus: "active" as const,
      };
      userResult = await userManager.updateUser(nickname, sessionData);
    } else {
      // Add user to user manager
      userResult = await userManager.addUser(nickname, arnString, CHAT_USER_TYPES.TEMPORARY);
    }

    if (!userResult?.success) {
      return res.status(400).json({
        error: userResult?.error ?? "Unknown error",
        action: "leave",
      });
    }

    if (!userResult.sessionData || !userResult.user) {
      return res.status(500).json({
        error: "User session could not be created",
        action: "leave",
      });
    }

    // Generate IVS Chat token
    const tokenResponse = await chatService.createChatToken({
      roomIdentifier: arnString,
      userId: userResult.sessionData.chatUserId, // Use proper unique ID
      capabilities: [ChatTokenCapability.SEND_MESSAGE],
      sessionDurationInMinutes: 60,
      attributes: {
        nickname: nickname,
        userType: CHAT_USER_TYPES.TEMPORARY,
        channelRole: CHAT_CHANNEL_ROLES.VIEWER,
        isRegistered: "false",
        chatUserId: userResult.sessionData.chatUserId,
      },
    });

    if (!tokenResponse.token) {
      await userManager.removeUser(nickname, arnString);
      return res.status(500).json({
        error: "Failed to generate chat token",
      });
    }

    res.json(tokenResponse);
  },
);

// Anonymous read-only connection endpoint
router.post(
  "/connect-readonly",
  async (
    req: Request<Record<string, never>, IChatTokenResponse | IErrorResponse, IConnectReadOnlyRequest>,
    res: Response<IChatTokenResponse | IErrorResponse>,
  ) => {
    const { channelId } = req.body;

    // Validate required parameters
    if (!channelId) {
      return res.status(400).json({
        error: "Missing required parameter: channelId is required",
      });
    }

    // Validate AWS credentials
    const isValid = await chatService.validateCredentials();
    if (!isValid) {
      return res.status(500).json({
        error: "Invalid AWS credentials for IVS Chat",
      });
    }

    // Generate anonymous user ID for IVS
    const anonymousUserId = `anonymous_${uuidv4()}`;

    // Generate IVS Chat token with no send capabilities (read-only)
    const tokenResponse = await chatService.createChatToken({
      roomIdentifier: channelId,
      userId: anonymousUserId,
      capabilities: [], // No capabilities = read-only
      sessionDurationInMinutes: 60,
      attributes: {
        userType: CHAT_USER_TYPES.ANONYMOUS,
        isRegistered: "false",
        chatUserId: anonymousUserId,
      },
    });

    if (!tokenResponse.token) {
      return res.status(500).json({
        error: "Failed to generate chat token",
      });
    }

    res.json(tokenResponse);
  },
);

// Leave chat endpoint
router.post(
  "/leave",
  async (
    req: Request<Record<string, never>, ILeaveChatResponse | IErrorResponse, ILeaveChatRequest>,
    res: Response<ILeaveChatResponse | IErrorResponse>,
  ) => {
    const { nickname, channelId } = req.body;

    if (!nickname || !channelId) {
      return res.status(400).json({
        error: "Missing required parameters: nickname and channelId are required",
      });
    }

    await userManager.removeUser(nickname, channelId);

    res.json({
      success: true,
      message: `User ${nickname} left the chat`,
    });
  },
);

// Update user activity (heartbeat)
router.post(
  "/activity",
  async (
    req: Request<Record<string, never>, IActivityUpdateResponse | IErrorResponse, IActivityUpdateRequest>,
    res: Response<IActivityUpdateResponse | IErrorResponse>,
  ) => {
    const { nickname } = req.body;

    if (!nickname) {
      return res.status(400).json({
        error: "Missing required parameter: nickname",
      });
    }

    await userManager.updateUserActivity(nickname);

    res.json({
      success: true,
      message: "Activity updated",
    });
  },
);

export default router;
