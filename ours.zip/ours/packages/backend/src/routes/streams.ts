import { getAuth, requireAuth } from "@clerk/express";
import express, { type Request, type Response } from "express";
import {
  createPaymentMethods,
  deletePaymentMethodsByStreamId,
  getPaymentMethodsByStreamId,
} from "#ours/backend/database/operations/stream_payment_methods.ts";
import * as streamOps from "#ours/backend/database/operations/streams.ts";
import { createIVSStreamService, type IVSStreamConfig } from "#ours/backend/services/ivs_stream_service.ts";
import type {
  ICreateStreamRequest,
  ICreateStreamResponse,
  IStreamAccessQuery,
  IStreamDetailsResponse,
  IStreamErrorResponse,
  IUpdateStreamRequest,
  IUpdateStreamResponse,
} from "#ours/backend/types/streams.ts";
import { checkEnvVar } from "#ours/backend/utils/env_utils.ts";

const router = express.Router();

// Initialize IVS Stream service to fetch channel details
const ivsStreamConfig: IVSStreamConfig = {
  region: checkEnvVar("IVS_STREAMS_AWS_REGION"),
  accessKeyId: checkEnvVar("IVS_STREAMS_AWS_ACCESS_KEY_ID"),
  secretAccessKey: checkEnvVar("IVS_STREAMS_AWS_SECRET_ACCESS_KEY"),
};

const ivsStreamService = createIVSStreamService(ivsStreamConfig);

// GET /streams/my-streams - Get streams owned by authenticated user (MUST come before /:streamName)
router.get(
  "/my-streams",
  requireAuth(),
  async (
    req: Request,
    res: Response<
      | {
          success: true;
          streams: Array<{
            id: number;
            streamName: string;
            unlistedId: string;
            title: string;
            hasPassword: boolean;
            createdAt: Date;
          }>;
        }
      | IStreamErrorResponse
    >,
  ) => {
    try {
      const auth = getAuth(req);

      if (!auth || !("userId" in auth) || !auth.userId) {
        return res.status(401).json({
          error: "Authentication required",
          message: "Valid authentication is required to view your streams",
        });
      }

      const userId = auth.userId;

      const streams = await streamOps.getStreamsByOwner(userId);

      const formattedStreams = await Promise.all(
        streams.map(async (stream) => {
          const paymentMethods = await getPaymentMethodsByStreamId(stream.id);
          const baseStreamData = {
            id: stream.id,
            streamName: stream.streamName,
            unlistedId: stream.unlistedId,
            title: stream.title,
            streamType: stream.streamType,
            hasPassword: !!stream.password,
            paymentMethods: paymentMethods.map((pm) => ({
              paymentType: pm.paymentType,
              handle: pm.handle,
            })),
            createdAt: stream.createdAt,
          };

          if (stream.streamType === "ivs") {
            return {
              ...baseStreamData,
              ivsPlaybackUrl: stream.ivsPlaybackUrl,
              ivsIngestEndpoint: stream.ivsIngestEndpoint,
              ivsStreamKey: stream.ivsStreamKeyValue,
            };
          }

          return baseStreamData;
        }),
      );

      return res.json({
        success: true,
        streams: formattedStreams,
      });
    } catch (error) {
      console.error("Error getting user streams:", error);
      return res.status(500).json({
        error: "Internal server error",
        message: "Failed to retrieve your streams",
      });
    }
  },
);

// POST /streams - Create new stream (requires authentication)
router.post(
  "/",
  requireAuth(),
  async (
    req: Request<Record<string, never>, unknown, ICreateStreamRequest>,
    res: Response<ICreateStreamResponse | IStreamErrorResponse>,
  ) => {
    try {
      const auth = getAuth(req);

      if (!auth || !("userId" in auth) || !auth.userId) {
        return res.status(401).json({
          error: "Authentication required",
          message: "Valid authentication is required to create streams",
        });
      }

      const userId = auth.userId;

      const { streamName, unlistedId, title, password, paymentMethods, streamType } = req.body;

      if (!streamName || !title || !streamType) {
        return res.status(400).json({
          error: "Invalid request",
          message: "streamName, title, and streamType are required",
        });
      }

      // Check if streamName already exists
      const existingStream = await streamOps.getStreamByStreamName(streamName);
      if (existingStream) {
        return res.status(409).json({
          error: "Stream exists",
          message: "A stream with this name already exists",
        });
      }

      let stream: streamOps.StreamModel;
      let ivsChannelData: streamOps.IVSChannelData | undefined;

      if (streamType === "ivs") {
        try {
          const sharedChannelArn = checkEnvVar("IVS_SHARED_CHANNEL_ARN");
          const sharedStreamKeyValue = checkEnvVar("IVS_SHARED_STREAM_KEY");

          let sharedStreamKeyArn = "";
          try {
            sharedStreamKeyArn = checkEnvVar("IVS_SHARED_STREAM_KEY_ARN");
          } catch {
            // Optional: IVS_SHARED_STREAM_KEY_ARN not required
          }

          const channel = await ivsStreamService.getChannel(sharedChannelArn);

          ivsChannelData = {
            ivsChannelArn: channel.arn || sharedChannelArn,
            ivsPlaybackUrl: channel.playbackUrl || "",
            ivsIngestEndpoint: channel.ingestEndpoint || "",
            ivsStreamKeyArn: sharedStreamKeyArn,
            ivsStreamKeyValue: sharedStreamKeyValue,
          };

          // Create stream record using shared channel
          stream = await streamOps.createStream(
            streamName,
            sharedChannelArn,
            title,
            userId,
            streamType,
            password,
            ivsChannelData,
          );
        } catch (ivsError) {
          console.error("Error fetching IVS channel details:", ivsError);
          return res.status(500).json({
            error: "IVS stream setup failed",
            message: ivsError instanceof Error ? ivsError.message : "Failed to fetch IVS channel details from AWS",
          });
        }
      } else {
        // YouTube/Vimeo - require unlistedId
        if (!unlistedId) {
          return res.status(400).json({
            error: "Invalid request",
            message: "unlistedId is required for YouTube/Vimeo streams",
          });
        }

        stream = await streamOps.createStream(streamName, unlistedId, title, userId, streamType, password);
      }

      // Create payment methods if provided
      if (paymentMethods && paymentMethods.length > 0) {
        await createPaymentMethods(stream.id, paymentMethods);
      }

      const response: ICreateStreamResponse = {
        success: true,
        stream: {
          id: stream.id,
          streamName: stream.streamName,
          unlistedId: stream.unlistedId,
          title: stream.title,
          streamType: stream.streamType,
          hasPassword: !!stream.password,
          ownerId: stream.ownerId,
          createdAt: stream.createdAt,
        },
      };

      if (streamType === "ivs" && ivsChannelData) {
        response.stream.ivsIngestEndpoint = ivsChannelData.ivsIngestEndpoint;
        response.stream.ivsStreamKey = ivsChannelData.ivsStreamKeyValue;
        response.stream.ivsPlaybackUrl = ivsChannelData.ivsPlaybackUrl;
      }

      return res.status(201).json(response);
    } catch (error) {
      console.error("Error creating stream:", error);
      return res.status(500).json({
        error: "Internal server error",
        message: "Failed to create stream",
      });
    }
  },
);

// GET /streams/:streamName - Get stream details with password validation
router.get(
  "/:streamName",
  async (
    req: Request<{ streamName: string }, unknown, unknown, IStreamAccessQuery>,
    res: Response<IStreamDetailsResponse | IStreamErrorResponse>,
  ) => {
    try {
      const { streamName } = req.params;
      const { password } = req.query;

      const stream = await streamOps.getStreamByStreamName(streamName);
      if (!stream) {
        return res.status(404).json({
          error: "Stream not found",
          message: "The requested stream does not exist",
        });
      }

      // If stream is password protected and no password provided, return limited data
      if (stream.password && !password) {
        return res.json({
          success: true,
          stream: {
            streamName: stream.streamName,
            title: stream.title,
            streamType: stream.streamType,
            hasPassword: true,
            requiresPassword: true,
          },
        });
      }

      // Validate access if password was provided
      const hasAccess = await streamOps.validateStreamAccess(streamName, password);
      if (!hasAccess) {
        return res.status(401).json({
          error: "Access denied",
          message: "Invalid password",
        });
      }

      const paymentMethods = await getPaymentMethodsByStreamId(stream.id);

      const baseStreamResponse = {
        id: stream.id,
        streamName: stream.streamName,
        unlistedId: stream.unlistedId,
        title: stream.title,
        streamType: stream.streamType,
        hasPassword: !!stream.password,
        paymentMethods: paymentMethods.map((pm) => ({
          paymentType: pm.paymentType,
          handle: pm.handle,
        })),
        createdAt: stream.createdAt,
      };

      const streamResponse =
        stream.streamType === "ivs"
          ? {
              ...baseStreamResponse,
              ivsPlaybackUrl: stream.ivsPlaybackUrl,
              ivsIngestEndpoint: stream.ivsIngestEndpoint,
            }
          : baseStreamResponse;

      return res.json({
        success: true,
        stream: streamResponse,
      });
    } catch (error) {
      console.error("Error getting stream:", error);
      return res.status(500).json({
        error: "Internal server error",
        message: "Failed to retrieve stream",
      });
    }
  },
);

// PUT /streams/:streamName - Update stream (requires authentication)
router.put(
  "/:streamName",
  requireAuth(),
  async (
    req: Request<{ streamName: string }, unknown, IUpdateStreamRequest>,
    res: Response<IUpdateStreamResponse | IStreamErrorResponse>,
  ) => {
    try {
      const auth = getAuth(req);

      if (!auth || !("userId" in auth) || !auth.userId) {
        return res.status(401).json({
          error: "Authentication required",
          message: "Valid authentication is required to update streams",
        });
      }

      const userId = auth.userId;

      const { streamName } = req.params;
      const { title, password } = req.body;

      const stream = await streamOps.getStreamByStreamName(streamName);
      if (!stream) {
        return res.status(404).json({
          error: "Stream not found",
          message: "The requested stream does not exist",
        });
      }

      // Check ownership
      if (stream.ownerId !== userId) {
        return res.status(403).json({
          error: "Access denied",
          message: "Only the stream owner can update this stream",
        });
      }

      const updates: Partial<{ title: string; password: string }> = {};
      if (title !== undefined) updates.title = title;
      if (password !== undefined) updates.password = password;

      if (Object.keys(updates).length === 0) {
        return res.status(400).json({
          error: "Invalid request",
          message: "At least one field (title or password) must be provided for update",
        });
      }

      const success = await streamOps.updateStream(streamName, updates);
      if (!success) {
        return res.status(500).json({
          error: "Update failed",
          message: "Failed to update stream",
        });
      }

      return res.json({
        success: true,
        message: "Stream updated successfully",
      });
    } catch (error) {
      console.error("Error updating stream:", error);
      return res.status(500).json({
        error: "Internal server error",
        message: "Failed to update stream",
      });
    }
  },
);

// DELETE /streams/:streamName - Deactivate stream (requires authentication)
router.delete(
  "/:streamName",
  requireAuth(),
  async (req: Request<{ streamName: string }>, res: Response<IUpdateStreamResponse | IStreamErrorResponse>) => {
    try {
      const auth = getAuth(req);

      if (!auth || !("userId" in auth) || !auth.userId) {
        return res.status(401).json({
          error: "Authentication required",
          message: "Valid authentication is required to delete streams",
        });
      }

      const userId = auth.userId;

      const { streamName } = req.params;

      const stream = await streamOps.getStreamByStreamName(streamName);
      if (!stream) {
        return res.status(404).json({
          error: "Stream not found",
          message: "The requested stream does not exist",
        });
      }

      // Check ownership
      if (stream.ownerId !== userId) {
        return res.status(403).json({
          error: "Access denied",
          message: "Only the stream owner can delete this stream",
        });
      }

      const success = await streamOps.deactivateStream(streamName);
      if (!success) {
        return res.status(500).json({
          error: "Delete failed",
          message: "Failed to delete stream",
        });
      }

      // Also delete associated payment methods
      await deletePaymentMethodsByStreamId(stream.id);

      return res.json({
        success: true,
        message: "Stream deleted successfully",
      });
    } catch (error) {
      console.error("Error deleting stream:", error);
      return res.status(500).json({
        error: "Internal server error",
        message: "Failed to delete stream",
      });
    }
  },
);

export default router;
