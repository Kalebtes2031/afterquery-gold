import path from "node:path";
import dotenv from "dotenv";
import express, { type Request, type Response } from "express";
import { CHAT_REACTIONS } from "#ours/backend/constants/index.ts";
import { rooms } from "#ours/backend/database/operations/index.ts";
import { createIVSChatService } from "#ours/backend/services/ivs_chat_client";
import { createReactionService } from "#ours/backend/services/reaction_service";
import type {
  IErrorResponse,
  IRoomDetailsParams,
  IRoomDetailsResponse,
  ISendEventParams,
  ISendEventRequest,
  ISendEventResponse,
} from "#ours/backend/types/chat.ts";

dotenv.config({ path: path.join(process.cwd(), ".env") });

if (process.env.IVS_AWS_REGION === undefined) {
  throw new Error("IVS_AWS_REGION is not set");
}
if (process.env.IVS_AWS_ACCESS_KEY_ID === undefined) {
  throw new Error("IVS_AWS_ACCESS_KEY_ID is not set");
}
if (process.env.IVS_AWS_SECRET_ACCESS_KEY === undefined) {
  throw new Error("IVS_AWS_SECRET_ACCESS_KEY is not set");
}

const router = express.Router();

const ivsConfig = {
  region: process.env.IVS_AWS_REGION,
  accessKeyId: process.env.IVS_AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.IVS_AWS_SECRET_ACCESS_KEY,
};

const chatService = createIVSChatService(ivsConfig);
const reactionService = createReactionService(chatService);

interface ToggleReactionBody {
  userId: string;
  reaction: string;
}

interface MessageReactionsQuery {
  userId?: string;
}

interface RoomReactionsQuery {
  limit?: string;
}

// Toggle reaction (add/remove)
router.post(
  "/:roomId/messages/:messageId/reactions",
  async (req: Request<{ roomId: string; messageId: string }, unknown, ToggleReactionBody>, res: Response) => {
    const { roomId, messageId } = req.params;
    const { userId, reaction } = req.body;

    if (!userId || !reaction) {
      return res.status(400).json({
        status: "error",
        message: "userId and reaction are required",
      });
    }

    // Validate reaction format (emoji)
    const emojiRegex = new RegExp(`^(${Object.values(CHAT_REACTIONS).join("|")})$`);
    if (!emojiRegex.test(reaction)) {
      return res.status(400).json({
        status: "error",
        message: "Invalid reaction format. Please use a valid emoji.",
      });
    }

    const room = await rooms.getRoomByRoomId(roomId);
    if (!room) {
      return res.status(404).json({
        status: "error",
        message: "Room not found",
      });
    }

    const result = await reactionService.toggleReaction(room.arnString, messageId, userId, reaction);

    res.json({
      status: "ok",
      data: result,
    });
  },
);

// Get reactions for a specific message
router.get(
  "/:roomId/messages/:messageId/reactions",
  async (
    req: Request<{ roomId: string; messageId: string }, unknown, unknown, MessageReactionsQuery>,
    res: Response,
  ) => {
    const { messageId } = req.params;
    const { userId } = req.query;

    const messageReactions = await reactionService.getMessageReactions(messageId);

    let userReactions: string[] = [];
    if (userId) {
      userReactions = await reactionService.getUserReactionsForMessage(messageId, userId);
    }

    res.json({
      status: "ok",
      data: {
        messageId,
        reactions: messageReactions.reactions,
        totalCount: messageReactions.totalCount,
        userReactions: userReactions,
      },
    });
  },
);

// Get all reactions in a room (recent activity)
router.get(
  "/:roomId/reactions",
  async (req: Request<{ roomId: string }, unknown, unknown, RoomReactionsQuery>, res: Response) => {
    const { roomId } = req.params;
    const limit = parseInt(req.query.limit || "50", 10) || 50;

    const roomReactions = await reactionService.getRoomReactions(roomId, Math.min(limit, 100));

    res.json({
      status: "ok",
      data: {
        roomId,
        reactions: roomReactions,
        count: roomReactions.length,
      },
    });
  },
);

// Webhook endpoint for handling IVS Chat events (optional)
router.post("/:roomId/events", async (req: Request, res: Response) => {
  const eventData = req.body;

  // Verify this is a reaction event
  if (eventData.eventName === "reaction") {
    await reactionService.handleIncomingReactionEvent(eventData);
  }

  res.json({
    status: "ok",
    message: "Event processed",
  });
});

// Send event to room (server-side)
router.post(
  "/:roomId/events",
  async (
    req: Request<ISendEventParams, ISendEventResponse | IErrorResponse, ISendEventRequest>,
    res: Response<ISendEventResponse | IErrorResponse>,
  ) => {
    const { roomId } = req.params;
    const { eventName, attributes } = req.body;

    if (!eventName) {
      return res.status(400).json({
        error: "eventName is required",
      });
    }

    const result = await chatService.sendEvent({
      roomIdentifier: roomId,
      eventName,
      attributes,
    });

    res.json({
      success: true,
      eventId: result.id ?? "",
    });
  },
);

// Get specific room details
router.get(
  "/:roomId",
  async (
    req: Request<IRoomDetailsParams, IRoomDetailsResponse | IErrorResponse>,
    res: Response<IRoomDetailsResponse | IErrorResponse>,
  ) => {
    const { roomId } = req.params;
    const room = await rooms.getRoomByRoomId(roomId);
    if (room) {
      return res.status(200).json({
        success: true,
        room: {
          id: room.arnString,
        },
      });
    }

    return res.status(404).json({
      error: "Room not found",
    });
  },
);

export default router;
