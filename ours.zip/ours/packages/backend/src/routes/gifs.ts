import express, { type Request, type Response } from "express";
import { resolveGifByUrl, searchGiphy, searchTenor } from "#ours/backend/services/gif_service.ts";

const router = express.Router();

router.get("/search", (req: Request, res: Response) => {
  const providerQuery = typeof req.query.provider === "string" ? req.query.provider.toLowerCase() : "giphy";
  const q = typeof req.query.q === "string" ? req.query.q.trim() : "";
  const limitQuery = typeof req.query.limit === "string" ? Number.parseInt(req.query.limit, 10) : undefined;
  if (q === "") {
    res.status(400).json({ success: false, error: "Missing search query" });
    return;
  }
  const safeLimit =
    limitQuery !== undefined && Number.isFinite(limitQuery) && limitQuery > 0 ? Math.min(limitQuery, 50) : 24;
  const searchPromise = providerQuery === "tenor" ? searchTenor(q, safeLimit) : searchGiphy(q, safeLimit);
  searchPromise
    .then((results) => {
      res.json({ success: true, results });
    })
    .catch((error: unknown) => {
      const message = error instanceof Error ? error.message : "Failed to fetch GIFs";
      res.status(500).json({ success: false, error: message });
    });
});

router.get("/resolve", (req: Request, res: Response) => {
  const targetUrl = typeof req.query.url === "string" ? req.query.url.trim() : "";
  if (targetUrl === "") {
    res.status(400).json({ success: false, error: "Missing url" });
    return;
  }
  resolveGifByUrl(targetUrl)
    .then((result) => {
      res.json({ success: true, result });
    })
    .catch((error: unknown) => {
      const message = error instanceof Error ? error.message : "Failed to resolve GIF";
      res.status(500).json({ success: false, error: message });
    });
});

export default router;
