import express, { type Request, type Response } from "express";
import { requireAuth } from "#ours/backend/middlewares/auth.ts";
import { createIVSStreamService, type IVSStreamConfig } from "#ours/backend/services/ivs_stream_service.ts";
import { checkEnvVar } from "#ours/backend/utils/env_utils.ts";

const router = express.Router();

const ivsStreamConfig: IVSStreamConfig = {
  region: checkEnvVar("IVS_STREAMS_AWS_REGION"),
  accessKeyId: checkEnvVar("IVS_STREAMS_AWS_ACCESS_KEY_ID"),
  secretAccessKey: checkEnvVar("IVS_STREAMS_AWS_SECRET_ACCESS_KEY"),
};

const ivsStreamService = createIVSStreamService(ivsStreamConfig);

/**
 * POST /api/ivs/channels
 * Create a new IVS channel for streaming
 */
router.post("/channels", requireAuth, async (req: Request, res: Response) => {
  try {
    const { name, latencyMode = "LOW", authorized = false } = req.body;

    if (!name) {
      res.status(400).json({ success: false, error: "Channel name is required" });
      return;
    }

    const result = await ivsStreamService.createChannel({
      name,
      latencyMode,
      authorized,
    });

    res.json({
      success: true,
      channel: {
        arn: result.channel.arn,
        name: result.channel.name,
        playbackUrl: result.channel.playbackUrl,
        ingestEndpoint: result.channel.ingestEndpoint,
        latencyMode: result.channel.latencyMode,
      },
      streamKey: {
        arn: result.streamKey.arn,
        value: result.streamKey.value,
      },
    });
  } catch (error) {
    console.error("Error creating IVS channel:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to create channel",
    });
  }
});

/**
 * GET /api/ivs/channels/:channelArn
 * Get channel information
 */
router.get("/channels/:channelArn", async (req: Request, res: Response) => {
  try {
    const { channelArn } = req.params;
    const decodedArn = decodeURIComponent(channelArn);

    const channel = await ivsStreamService.getChannel(decodedArn);

    res.json({
      success: true,
      channel: {
        arn: channel.arn,
        name: channel.name,
        playbackUrl: channel.playbackUrl,
        ingestEndpoint: channel.ingestEndpoint,
        latencyMode: channel.latencyMode,
        authorized: channel.authorized,
      },
    });
  } catch (error) {
    console.error("Error getting channel:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to get channel",
    });
  }
});

/**
 * GET /api/ivs/streams/:channelArn
 * Get stream status (live/offline, viewer count, etc.)
 */
router.get("/streams/:channelArn", async (req: Request, res: Response) => {
  try {
    const { channelArn } = req.params;
    const decodedArn = decodeURIComponent(channelArn);

    const streamInfo = await ivsStreamService.getStream(decodedArn);

    res.json({
      success: true,
      stream: streamInfo,
    });
  } catch (error) {
    console.error("Error getting stream:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to get stream status",
    });
  }
});

/**
 * POST /api/ivs/streams/:channelArn/stop
 * Stop a live stream
 */
router.post("/streams/:channelArn/stop", requireAuth, async (req: Request, res: Response) => {
  try {
    const { channelArn } = req.params;
    const decodedArn = decodeURIComponent(channelArn);

    await ivsStreamService.stopStream(decodedArn);

    res.json({
      success: true,
      message: "Stream stopped successfully",
    });
  } catch (error) {
    console.error("Error stopping stream:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to stop stream",
    });
  }
});

/**
 * DELETE /api/ivs/channels/:channelArn
 * Delete a channel
 */
router.delete("/channels/:channelArn", requireAuth, async (req: Request, res: Response) => {
  try {
    const { channelArn } = req.params;
    const decodedArn = decodeURIComponent(channelArn);

    await ivsStreamService.deleteChannel(decodedArn);

    res.json({
      success: true,
      message: "Channel deleted successfully",
    });
  } catch (error) {
    console.error("Error deleting channel:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to delete channel",
    });
  }
});

/**
 * GET /api/ivs/channels
 * List all channels
 */
router.get("/channels", requireAuth, async (_req: Request, res: Response) => {
  try {
    const channels = await ivsStreamService.listChannels();

    res.json({
      success: true,
      channels: channels.map((channel) => ({
        arn: channel.arn,
        name: channel.name,
        playbackUrl: channel.playbackUrl,
        latencyMode: channel.latencyMode,
      })),
    });
  } catch (error) {
    console.error("Error listing channels:", error);
    res.status(500).json({
      success: false,
      error: error instanceof Error ? error.message : "Failed to list channels",
    });
  }
});

export default router;
