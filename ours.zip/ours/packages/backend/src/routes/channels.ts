import express, { type Request, type Response } from "express";
import { userManager } from "#ours/backend/services/user_manager";
import type { IChannelUsersParams, IChannelUsersResponse, IErrorResponse } from "#ours/backend/types/chat.ts";

const router = express.Router();

// Get channel users
router.get(
  "/:channelId/users",
  async (
    req: Request<IChannelUsersParams, IChannelUsersResponse | IErrorResponse>,
    res: Response<IChannelUsersResponse | IErrorResponse>,
  ) => {
    const { channelId } = req.params;

    const users = await userManager.getChannelUsers(channelId);
    const userCount = await userManager.getChannelUserCount(channelId);

    res.json({
      success: true,
      channelId,
      users,
      userCount,
    });
  },
);

export default router;
