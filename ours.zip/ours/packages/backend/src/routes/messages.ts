import express, { type Request, type Response } from "express";
import type { StoredChatMessage } from "#ours/backend/session/models/message.ts";
import { addMessage, getChannelMessages } from "#ours/backend/session/operations/index.ts";

const router = express.Router();

/**
 * GET /session/messages/:channelId
 * Returns the latest messages for a channel
 */
router.get("/:channelId", async (req: Request, res: Response) => {
  const { channelId } = req.params;
  console.log(`\u{1F4E5} GET /session/messages/${channelId} - Request received`);

  if (!channelId) {
    console.log("\u274C Channel ID is missing");
    return res.status(400).json({
      success: false,
      error: "Channel ID is required",
    });
  }

  console.log(`\u{1F50D} Fetching messages for channel: ${channelId}`);
  const messages: StoredChatMessage[] = await getChannelMessages(channelId);
  console.log(`\u{1F4CA} Found ${messages.length} messages for channel ${channelId}`);

  return res.json({
    success: true,
    messages,
    count: messages.length,
  });
});

/**
 * POST /session/messages
 * Stores a message for a channel
 */
router.post("/", async (req: Request, res: Response) => {
  const message: StoredChatMessage = req.body;
  console.log(`\u{1F4DD} POST /session/messages - Storing message for channel: ${message.channelId}`);

  if (!message.id || !message.channelId || !message.content || !message.userId || !message.username) {
    console.log("\u274C Missing required message fields:", message);
    return res.status(400).json({
      success: false,
      error: "Missing required message fields: id, channelId, content, userId, username",
    });
  }

  console.log(`\u{1F4BE} Storing message: ${message.content.substring(0, 50)}...`);
  await addMessage(message.channelId, message);
  console.log(`\u2705 Message stored successfully for channel: ${message.channelId}`);

  return res.json({
    success: true,
    message: "Message stored successfully",
  });
});

export default router;
