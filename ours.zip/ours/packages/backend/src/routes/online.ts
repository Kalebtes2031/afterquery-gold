import express, { type Request, type Response } from "express";
import { createClient } from "redis";

const router = express.Router();

// Configuration
const ONLINE_WINDOW_SECONDS = parseInt(process.env.ONLINE_WINDOW_SECONDS || "30", 10);
const SSE_PING_SECONDS = parseInt(process.env.SSE_PING_SECONDS || "15", 10);
const RESPECT_DNT = process.env.RESPECT_DNT !== "false";

// Bot detection patterns
const BOT_PATTERNS = /bot|crawler|spider|preview|monitor|uptime/i;

// Helper function to check if request is from a bot
function isBotRequest(req: Request): boolean {
  const userAgent = req.headers["user-agent"] || "";
  const secPurpose = req.headers["sec-purpose"];
  const purpose = req.headers.purpose;

  return BOT_PATTERNS.test(userAgent) || secPurpose === "prefetch" || purpose === "prefetch";
}

// Helper function to check DNT (Do Not Track)
function shouldTrackUser(req: Request): boolean {
  if (!RESPECT_DNT) return true;

  const dnt = req.headers.dnt;
  return dnt !== "1";
}

// Helper function to get Redis client
async function getRedisClient() {
  const client = createClient({
    url: process.env.REDIS_URL || "redis://localhost:6379",
  });

  client.on("error", (err) => {
    console.error("Redis Client Error:", err);
  });

  await client.connect();
  return client;
}

// POST /api/online/heartbeat - Track visitor presence
router.post("/heartbeat", async (req: Request, res: Response) => {
  try {
    // Bot filtering
    if (isBotRequest(req)) {
      return res.status(204).end();
    }

    // DNT check
    if (!shouldTrackUser(req)) {
      return res.status(204).end();
    }

    const { visitorId, slug } = req.body;

    if (!visitorId || !slug) {
      return res.status(400).json({
        error: "Invalid request",
        message: "visitorId and slug are required",
      });
    }

    const client = await getRedisClient();
    const now = Math.floor(Date.now() / 1000);
    const pageKey = `online:page:${slug}`;
    const countChannel = `online:count:${slug}`;

    try {
      // Add/update visitor with current timestamp
      await client.zAdd(pageKey, {
        score: now,
        value: visitorId,
      });

      // Remove expired visitors (older than window)
      await client.zRemRangeByScore(pageKey, 0, now - ONLINE_WINDOW_SECONDS);

      // Get current count
      const count = await client.zCard(pageKey);

      // Publish count update
      await client.publish(countChannel, count.toString());

      res.status(204).end();
    } finally {
      await client.quit();
    }
  } catch (error) {
    console.error("Error in heartbeat:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to update presence",
    });
  }
});

// GET /api/online/stream - SSE endpoint for live count updates
router.get("/stream", async (req: Request, res: Response) => {
  try {
    // Bot filtering
    if (isBotRequest(req)) {
      return res.status(204).end();
    }

    // DNT check
    if (!shouldTrackUser(req)) {
      return res.status(204).end();
    }

    const { slug } = req.query;

    if (!slug || typeof slug !== "string") {
      return res.status(400).json({
        error: "Invalid request",
        message: "slug is required",
      });
    }

    // Set SSE headers
    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "Cache-Control",
    });

    const client = await getRedisClient();
    const subscriber = client.duplicate();
    await subscriber.connect();

    const pageKey = `online:page:${slug}`;
    const countChannel = `online:count:${slug}`;
    const now = Math.floor(Date.now() / 1000);

    // Clean up expired visitors and send initial count
    try {
      await client.zRemRangeByScore(pageKey, 0, now - ONLINE_WINDOW_SECONDS);
      const initialCount = await client.zCard(pageKey);

      res.write(`event: count\ndata: ${initialCount}\n\n`);

      // Subscribe to count updates
      await subscriber.subscribe(countChannel, (message) => {
        res.write(`event: count\ndata: ${message}\n\n`);
      });

      // Send periodic pings to keep connection alive
      const pingInterval = setInterval(() => {
        try {
          res.write(`event: ping\ndata: ${Date.now()}\n\n`);
        } catch (_error) {
          // Client disconnected
          clearInterval(pingInterval);
        }
      }, SSE_PING_SECONDS * 1000);

      // Clean up on client disconnect
      req.on("close", () => {
        clearInterval(pingInterval);
        subscriber.quit();
        client.quit();
      });
    } catch (error) {
      console.error("Error in SSE setup:", error);
      res.end();
    }
  } catch (error) {
    console.error("Error in online stream:", error);
    res.status(500).json({
      error: "Internal server error",
      message: "Failed to establish stream",
    });
  }
});

export default router;
