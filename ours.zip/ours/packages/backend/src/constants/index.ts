export const CHAT_REACTIONS = {
  HEART: "HEART",
  HANDS_UP: "HANDS_UP",
  FIRE: "FIRE",
  MUSIC: "MUSIC",
  SURPRISED: "SURPRISED",
};

export const CHAT_USER_TYPES = {
  TEMPORARY: "temporary",
  REGULAR: "regular",
  ARTIST: "artist",
  ADMIN: "admin",
  MODERATOR: "moderator",
  ANONYMOUS: "anonymous",
} as const;

export const CHAT_CHANNEL_ROLES = {
  OWNER: "owner",
  VIEWER: "viewer",
} as const;
