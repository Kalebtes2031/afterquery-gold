import type { JWSHeaderParameters, JWTPayload } from "jose";

declare global {
  namespace Express {
    interface Request {
      auth?: {
        payload: JWTPayload;
        protectedHeader: JWSHeaderParameters;
      };
    }
  }
}

export {};
