export interface ICreateStreamRequest {
  streamName: string;
  unlistedId: string;
  title: string;
  streamType: "youtube" | "vimeo" | "ivs";
  password?: string;
  paymentMethods?: Array<{
    paymentType: "venmo" | "cashapp" | "paypal";
    handle: string;
  }>;
}

export interface ICreateStreamResponse {
  success: true;
  stream: {
    id: number;
    streamName: string;
    unlistedId: string;
    title: string;
    streamType: "youtube" | "vimeo" | "ivs";
    hasPassword: boolean;
    ownerId: string;
    createdAt: Date;
    // IVS-specific fields (only present when streamType === "ivs")
    ivsIngestEndpoint?: string;
    ivsStreamKey?: string;
    ivsPlaybackUrl?: string;
  };
}

export interface IStreamDetailsResponse {
  success: true;
  stream: {
    id?: number;
    streamName: string;
    unlistedId?: string;
    title: string;
    streamType?: "youtube" | "vimeo" | "ivs";
    hasPassword: boolean;
    requiresPassword?: boolean;
    createdAt?: Date;
    paymentMethods?: Array<{
      paymentType: "venmo" | "cashapp" | "paypal";
      handle: string;
    }>;
    // IVS-specific fields
    ivsPlaybackUrl?: string;
    isLive?: boolean;
  };
}

export interface IUpdateStreamRequest {
  title?: string;
  password?: string;
}

export interface IUpdateStreamResponse {
  success: true;
  message: string;
}

export interface IStreamAccessQuery {
  password?: string;
}

export interface IStreamErrorResponse {
  error: string;
  message: string;
  statusCode?: number;
}
