import type { ChatTokenCapability } from "@aws-sdk/client-ivschat";
import type { CHAT_CHANNEL_ROLES, CHAT_USER_TYPES } from "#ours/backend/constants/index.ts";

export type UserType = (typeof CHAT_USER_TYPES)[keyof typeof CHAT_USER_TYPES];
export type ChannelRole = (typeof CHAT_CHANNEL_ROLES)[keyof typeof CHAT_CHANNEL_ROLES];

export interface ITokenAttributes {
  id?: string;
  chatUserId?: string;
  nickname?: string;
  userType?: UserType;
  channelRole?: ChannelRole;
  isRegistered?: string;
  username?: string;
}

export interface IChatTokenRequest {
  roomIdentifier: string;
  userId: string;
  capabilities?: ChatTokenCapability[];
  sessionDurationInMinutes?: number;
  attributes?: ITokenAttributes;
}

export interface IChatTokenResponse {
  success: true;
  token: string;
  endpoint: string;
  roomId: string;
  userId: string;
  tokenExpirationTime?: Date;
  sessionExpirationTime?: Date;
  isReadOnly?: boolean;
  user: {
    id?: string;
    nickname?: string;
    username?: string;
    userType: UserType;
    channelRole: ChannelRole;
    isRegistered?: boolean;
    chatUserId: string;
  };
}

export interface IJoinChatRequest {
  nickname: string;
  channelId: string;
  userType?: UserType;
  authToken?: string;
  userId?: string;
}

export interface IConnectReadOnlyRequest {
  channelId: string;
}

export interface ILeaveChatRequest {
  nickname: string;
  channelId: string;
}

export interface ILeaveChatResponse {
  success: true;
  message: string;
}

export interface INicknameAvailabilityParams {
  nickname: string;
}

export interface INicknameAvailabilityResponse {
  success: true;
  nickname: string;
  available: boolean;
  reason?: string;
}

export interface IChannelUsersParams {
  channelId: string;
}

export interface IChannelUsersResponse {
  success: true;
  channelId: string;
  users: unknown[];
  userCount: number;
}

export interface IActivityUpdateRequest {
  nickname: string;
}

export interface IActivityUpdateResponse {
  success: true;
  message: string;
}

export interface INicknameAvailabilityQuery {
  userType?: string;
}

export interface IRoomDetailsParams {
  roomId: string;
}

export interface IRoomDetailsResponse {
  success: true;
  room: {
    id: string;
  };
}

export interface ISendEventParams {
  roomId: string;
}

export interface ISendEventRequest {
  eventName: string;
  attributes?: Record<string, string>;
}

export interface ISendEventResponse {
  success: true;
  eventId: string;
  eventTime?: Date;
}

export interface IErrorResponse {
  error: string;
  details?: string;
  reason?: string;
  action?: string;
}
