import path from "node:path";
import { fileURLToPath } from "node:url";
import { clerkMiddleware } from "@clerk/express";
import cookieParser from "cookie-parser";
import cors from "cors";
import express, { type NextFunction, type Request, type Response } from "express";
import logger from "morgan";
import { initializeDatabase } from "#ours/backend/database/config.ts";
import authRouter from "#ours/backend/routes/auth.ts";
import channelsRouter from "#ours/backend/routes/channels.ts";
import chatRouter from "#ours/backend/routes/chat.ts";
import gifsRouter from "#ours/backend/routes/gifs.ts";
import indexRouter from "#ours/backend/routes/index.ts";
import ivsStreamsRouter from "#ours/backend/routes/ivs_streams.ts";
import messagesRouter from "#ours/backend/routes/messages.ts";
import onlineRouter from "#ours/backend/routes/online.ts";
import roomsRouter from "#ours/backend/routes/rooms.ts";
import streamsRouter from "#ours/backend/routes/streams.ts";
import { getCleanupService } from "#ours/backend/services/cleanup_service";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// CORS configuration
app.use(
  cors({
    origin: [
      "http://localhost:5173", // Vite dev server
      "http://localhost:3000", // Alternative frontend port
      "https://*.clerk.accounts.dev", // Clerk domains
    ],
    credentials: true,
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "x-clerk-session", "x-clerk-publishable-key"],
  }),
);

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

app.use(clerkMiddleware());

app.use("/", indexRouter);
app.use("/api/chat", chatRouter);
app.use("/api/channels", channelsRouter);
app.use("/api/rooms", roomsRouter);
app.use("/api/auth", authRouter);
app.use("/api/messages", messagesRouter);
app.use("/api/streams", streamsRouter);
app.use("/api/ivs", ivsStreamsRouter);
app.use("/api/online", onlineRouter);
app.use("/api/gifs", gifsRouter);

// Function to initialize all services
async function initializeServices(): Promise<boolean> {
  // 1. Initialize database
  console.log("⏳ Starting database...");
  const dbInitialized = await initializeDatabase();

  if (!dbInitialized) {
    console.error("❌ Database initialization failed");
    return false;
  }

  console.log("✅ Database initialized successfully");

  // 2. Initialize cleanup service
  getCleanupService();

  // 3. Seed initial data only in development
  if (process.env.NODE_ENV === "development") {
    try {
      const [{ seedUsers }, { seedRooms }, { seedRoomOwners }] = await Promise.all([
        import("#ours/backend/seeds/seed_users.ts"),
        import("#ours/backend/seeds/seed_rooms.ts"),
        import("#ours/backend/seeds/seed_room_owners.ts"),
      ]);
      await seedUsers();
      await seedRooms();
      await seedRoomOwners();
      console.log("✅ Initial data loaded (users + rooms + room owners)");
    } catch (seedError) {
      const errorMessage = seedError instanceof Error ? seedError.message : "Unknown error";
      console.warn("⚠️ Error loading initial data:", errorMessage);
      // Don't stop the application due to seeding errors
    }
  }

  console.log("🚀 All services initialized successfully");
  return true;
}

// Initialize services when loading the module
let servicesInitialized = false;
const initPromise = initializeServices().then((success) => {
  servicesInitialized = success;
  return success;
});

// Middleware to verify that services are ready
app.use(async (_req: Request, res: Response, next: NextFunction) => {
  if (!servicesInitialized) {
    // Wait for initialization to complete
    const success = await initPromise;
    if (!success) {
      return res.status(503).json({
        error: "Services not available",
        message: "The application is initializing. Please try again in a few seconds.",
      });
    }
  }
  next();
});

export default app;
