import path from "node:path";
import dotenv from "dotenv";
import pg from "pg";
import { Sequelize } from "sequelize";

dotenv.config({ path: path.join(process.cwd(), ".env") });

if (process.env.DATABASE_URL === undefined || process.env.DATABASE_URL === "") {
  throw new Error("DATABASE_URL is not defined.");
}

const databaseUrl = process.env.DATABASE_URL;

export const sequelize = new Sequelize(databaseUrl, {
  dialect: "postgres",
  dialectModule: pg,
  logging: process.env.NODE_ENV === "development" ? console.log : false,
  define: {
    timestamps: false, // Keep manual timestamps for compatibility
    underscored: false,
  },
  dialectOptions: {
    ssl: {
      // We're on private network on AWS, so SSL wont offer too much added benefit
      require: false,
      rejectUnauthorized: false,
    },
  },
  pool: {
    max: 10,
    min: 0,
    acquire: 30000,
    idle: 10000,
  },
});

// Function to initialize the database
export async function initializeDatabase(): Promise<boolean> {
  try {
    await sequelize.authenticate();
    console.log("✅ Database connection established successfully");

    // Synchronize models (development only)
    if (process.env.NODE_ENV === "development") {
      await sequelize.sync({ alter: true });
      console.log("✅ Models synchronized successfully");
    } else {
      await sequelize.sync();
    }

    return true;
  } catch (error) {
    console.error("❌ Error connecting to database:", error);
    return false;
  }
}

// Function to close the connection
export async function closeDatabase(): Promise<void> {
  try {
    await sequelize.close();
    console.log("✅ Database connection closed successfully");
  } catch (error) {
    console.error("❌ Error closing connection:", error);
  }
}

// Function to reset the database (development only)
export async function resetDatabase(): Promise<boolean> {
  if (process.env.NODE_ENV !== "development") {
    throw new Error("Reset only allowed in development");
  }

  try {
    await sequelize.sync({ force: true });
    console.log("✅ Database reset successfully");
    return true;
  } catch (error) {
    console.error("❌ Error resetting database:", error);
    return false;
  }
}
