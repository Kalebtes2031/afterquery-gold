// Import all operations

import * as reactionOps from "#ours/backend/database/operations/reactions.ts";
import * as roomOwnerOps from "#ours/backend/database/operations/room_owners";
import * as roomOps from "#ours/backend/database/operations/rooms.ts";
import * as streamPaymentMethodOps from "#ours/backend/database/operations/stream_payment_methods.ts";
import * as userOps from "#ours/backend/database/operations/users.ts";

// Export by categories
export const reactions = reactionOps;
export const users = userOps;
export const rooms = roomOps;
export const roomOwners = roomOwnerOps;
export const streamPaymentMethods = streamPaymentMethodOps;

// Also export everything flat for compatibility
export const { addReaction, removeReaction, getMessageReactions, getUserReactionsForMessage, getRoomReactions } =
  reactionOps;

export const {
  createUser,
  getUserByNickname,
  getUserById,
  getUserByToken,
  updateUserToken,
  updateLastLogin,
  isNicknameReserved,
  getAllUsers,
  deactivateUser,
  getUserByEmailAndHash,
  getUserByEmail,
} = userOps;

export const {
  createRoom,
  getRoomByRoomId,
  getRoomByArn,
  updateRoom,
  deactivateRoom,
  getAllActiveRooms,
  createOrUpdateRoom,
  addOwnerToRoom,
  removeOwnerFromRoom,
  listOwnersForRoom,
} = roomOps;

export const { getOwnedRoomByUserId } = roomOwnerOps;

// Export stream payment method operations
export const {
  createPaymentMethod,
  createPaymentMethods,
  getPaymentMethodsByStreamId,
  updatePaymentMethod,
  deletePaymentMethod,
  deletePaymentMethodsByStreamId,
  getPaymentMethodByStreamAndType,
} = streamPaymentMethodOps;

// Export types
export type { MessageReactions } from "#ours/backend/database/operations/reactions.ts";
export type { CreatePaymentMethodInput } from "#ours/backend/database/operations/stream_payment_methods.ts";
export type { CreateUserData } from "#ours/backend/database/operations/users.ts";
