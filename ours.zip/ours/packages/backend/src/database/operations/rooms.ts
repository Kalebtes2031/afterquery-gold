import { Room, type RoomModel, RoomOwner, User } from "#ours/backend/database/models/index.ts";

export async function createRoom(roomId: string, arnString: string): Promise<RoomModel> {
  const room = await Room.create({
    roomId,
    arnString,
    isActive: true,
  });
  return room;
}

export async function getRoomByRoomId(roomId: string): Promise<RoomModel | null> {
  const room = await Room.findOne({
    where: { roomId, isActive: true },
    raw: true,
  });
  return room;
}

export async function getRoomByArn(arnString: string): Promise<RoomModel | null> {
  const room = await Room.findOne({
    where: { arnString, isActive: true },
    raw: true,
  });
  return room;
}

export async function updateRoom(roomId: string, arnString: string): Promise<boolean> {
  const [affectedRows] = await Room.update({ arnString }, { where: { roomId, isActive: true } });
  return affectedRows > 0;
}

export async function deactivateRoom(roomId: string): Promise<boolean> {
  const [affectedRows] = await Room.update({ isActive: false }, { where: { roomId, isActive: true } });
  return affectedRows > 0;
}

export async function getAllActiveRooms(): Promise<RoomModel[]> {
  const rooms = await Room.findAll({
    where: { isActive: true },
    order: [["createdAt", "DESC"]],
    raw: true,
  });
  return rooms;
}

export async function createOrUpdateRoom(roomId: string, arnString: string): Promise<RoomModel> {
  const [room] = await Room.upsert({
    roomId,
    arnString,
    isActive: true,
  });
  return room;
}

// --- Owners helpers ---
export async function addOwnerToRoom(roomId: string, userId: string): Promise<boolean> {
  const room = await Room.findOne({ where: { roomId, isActive: true } });
  if (!room) return false;
  const user = await User.findByPk(userId);
  if (!user) return false;
  try {
    await RoomOwner.create({ userId: user.id, roomId: room.id });
  } catch (_e) {
    // Unique constraint violation (already exists): treat as idempotent success
  }
  return true;
}

export async function removeOwnerFromRoom(roomId: string, userId: string): Promise<boolean> {
  const room = await Room.findOne({ where: { roomId, isActive: true } });
  if (!room) return false;
  const user = await User.findByPk(userId);
  if (!user) return false;
  const deleted = await RoomOwner.destroy({ where: { userId: user.id, roomId: room.id } });
  return deleted > 0;
}

export async function listOwnersForRoom(roomId: string): Promise<Array<{ id: string; nickname: string }>> {
  const room = await Room.findOne({ where: { roomId, isActive: true } });
  if (!room) return [];
  const mappings = await RoomOwner.findAll({ where: { roomId: room.id } });
  if (mappings.length === 0) return [];
  const ownerIds = mappings.map((m) => m.userId);
  const users = await User.findAll({
    where: { id: ownerIds },
    attributes: ["id", "nickname"],
  });
  return users.map((u) => ({ id: u.id, nickname: u.nickname }));
}
