import { Stream, type StreamModel } from "#ours/backend/database/models/stream.ts";

export type { StreamModel };

export interface IVSChannelData {
  ivsChannelArn?: string;
  ivsPlaybackUrl?: string;
  ivsIngestEndpoint?: string;
  ivsStreamKeyArn?: string;
  ivsStreamKeyValue?: string;
}

export async function createStream(
  streamName: string,
  unlistedId: string,
  title: string,
  ownerId: string,
  streamType: "youtube" | "vimeo" | "ivs" = "youtube",
  password?: string,
  ivsData?: IVSChannelData,
): Promise<StreamModel> {
  const stream = await Stream.create({
    streamName,
    unlistedId,
    title,
    ownerId,
    streamType,
    password,
    isActive: true,
    // IVS-specific fields
    ...(ivsData && {
      ivsChannelArn: ivsData.ivsChannelArn,
      ivsPlaybackUrl: ivsData.ivsPlaybackUrl,
      ivsIngestEndpoint: ivsData.ivsIngestEndpoint,
      ivsStreamKeyArn: ivsData.ivsStreamKeyArn,
      ivsStreamKeyValue: ivsData.ivsStreamKeyValue,
      isLive: false,
    }),
  });
  return stream;
}

export async function getStreamByStreamName(streamName: string): Promise<StreamModel | null> {
  const stream = await Stream.findOne({
    where: { streamName, isActive: true },
    raw: true,
  });
  return stream;
}

export async function getStreamByUnlistedId(unlistedId: string): Promise<StreamModel | null> {
  const stream = await Stream.findOne({
    where: { unlistedId, isActive: true },
    raw: true,
  });
  return stream;
}

export async function validateStreamAccess(streamName: string, providedPassword?: string): Promise<boolean> {
  const stream = await getStreamByStreamName(streamName);
  if (!stream) return false;

  // If stream has no password, access is granted
  if (!stream.password) return true;

  // If stream has password but none provided, access denied
  if (!providedPassword) return false;

  // Compare passwords directly
  return providedPassword === stream.password;
}

export async function updateStream(
  streamName: string,
  updates: Partial<Pick<StreamModel, "title" | "password">>,
): Promise<boolean> {
  const [affectedRows] = await Stream.update(updates, {
    where: { streamName, isActive: true },
  });
  return affectedRows > 0;
}

export async function deactivateStream(streamName: string): Promise<boolean> {
  const affectedRows = await Stream.destroy({ where: { streamName, isActive: true } });
  return affectedRows > 0;
}

export async function getStreamsByOwner(ownerId: string): Promise<StreamModel[]> {
  const streams = await Stream.findAll({
    where: { ownerId, isActive: true },
    order: [["createdAt", "DESC"]],
    raw: true,
  });
  return streams;
}
