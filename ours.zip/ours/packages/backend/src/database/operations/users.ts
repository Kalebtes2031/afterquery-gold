import { v4 as uuidv4 } from "uuid";
import { User, type UserModel } from "#ours/backend/database/models/index.ts";
import type { UserType } from "#ours/backend/types/chat.ts";

export interface CreateUserData {
  id?: string;
  nickname: string;
  email?: string;
  passwordHash?: string;
  userType?: UserType;
  isActive?: boolean;
  token?: string;
  username?: string | null;
}

export async function createUser(userData: CreateUserData): Promise<UserModel> {
  const user = await User.create({
    id: userData.id ?? uuidv4(),
    nickname: userData.nickname,
    email: userData.email,
    passwordHash: userData.passwordHash,
    userType: userData.userType || "regular",
    isActive: userData.isActive !== undefined ? userData.isActive : true,
    token: userData.token,
    username: userData.username ?? null,
  });
  return user;
}

export async function getUserByToken(token: string): Promise<UserModel | null> {
  const user = await User.findOne({
    where: { token, isActive: true },
    raw: true,
  });
  return user;
}

export async function updateUser(id: string, data: Partial<UserModel>): Promise<boolean> {
  const [affectedRows] = await User.update(data, { where: { id } });
  return affectedRows > 0;
}

export async function getUserByNickname(nickname: string): Promise<UserModel | null> {
  const user = await User.findOne({
    where: { nickname, isActive: true },
    raw: true,
  });
  return user;
}

export async function getUserById(id: string): Promise<UserModel | null> {
  const user = await User.findOne({
    where: { id, isActive: true },
    raw: true,
  });
  return user;
}

export async function updateUserToken(id: string, token: string): Promise<boolean> {
  const [affectedRows] = await User.update({ token }, { where: { id } });
  return affectedRows > 0;
}

export async function updateLastLogin(id: string): Promise<boolean> {
  const [affectedRows] = await User.update({ lastLogin: new Date() }, { where: { id } });
  return affectedRows > 0;
}

export async function isNicknameReserved(nickname: string): Promise<boolean> {
  const user = await User.findOne({
    where: { nickname, isActive: true },
    raw: true,
  });
  return !!user;
}

export async function getAllUsers(): Promise<UserModel[]> {
  const users = await User.findAll({
    where: { isActive: true },
    order: [["createdAt", "DESC"]],
    raw: true,
  });
  return users;
}

export async function deactivateUser(id: string): Promise<boolean> {
  const [affectedRows] = await User.update({ isActive: false }, { where: { id } });
  return affectedRows > 0;
}

export async function getUserByEmailAndHash(email: string, passwordHash: string): Promise<UserModel | null> {
  const user = await User.findOne({
    where: { email, passwordHash, isActive: true },
    raw: true,
  });
  return user;
}

export async function getUserByEmail(email: string): Promise<UserModel | null> {
  const user = await User.findOne({
    where: { email, isActive: true },
    raw: true,
  });
  return user;
}
