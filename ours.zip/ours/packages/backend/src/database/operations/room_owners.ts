import { RoomOwner } from "#ours/backend/database/models/index.ts";

export async function getOwnedRoomByUserId(userId: string, roomId: number): Promise<boolean> {
  const roomOwner = await RoomOwner.findOne({ where: { userId, roomId }, raw: true });
  return roomOwner !== null;
}
