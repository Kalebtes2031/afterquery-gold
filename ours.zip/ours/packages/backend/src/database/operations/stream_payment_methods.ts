import type { StreamPaymentMethodModel } from "#ours/backend/database/models/stream_payment_method.ts";
import { StreamPaymentMethod } from "#ours/backend/database/models/stream_payment_method.ts";

export interface CreatePaymentMethodInput {
  streamId: number;
  paymentType: "venmo" | "cashapp" | "paypal";
  handle: string;
}

export const createPaymentMethod = async (input: CreatePaymentMethodInput): Promise<StreamPaymentMethodModel> => {
  return await StreamPaymentMethod.create(input);
};

export const createPaymentMethods = async (
  streamId: number,
  paymentMethods: Array<{ paymentType: "venmo" | "cashapp" | "paypal"; handle: string }>,
): Promise<StreamPaymentMethodModel[]> => {
  return await StreamPaymentMethod.bulkCreate(
    paymentMethods.map((method) => ({
      streamId,
      paymentType: method.paymentType,
      handle: method.handle,
    })),
  );
};

export const getPaymentMethodsByStreamId = async (streamId: number): Promise<StreamPaymentMethodModel[]> => {
  return await StreamPaymentMethod.findAll({
    where: { streamId },
    order: [["paymentType", "ASC"]],
  });
};

export const updatePaymentMethod = async (
  id: number,
  handle: string,
): Promise<[number, StreamPaymentMethodModel[]]> => {
  return await StreamPaymentMethod.update({ handle }, { where: { id }, returning: true });
};

export const deletePaymentMethod = async (id: number): Promise<number> => {
  return await StreamPaymentMethod.destroy({ where: { id } });
};

export const deletePaymentMethodsByStreamId = async (streamId: number): Promise<number> => {
  return await StreamPaymentMethod.destroy({ where: { streamId } });
};

export const getPaymentMethodByStreamAndType = async (
  streamId: number,
  paymentType: "venmo" | "cashapp" | "paypal",
): Promise<StreamPaymentMethodModel | null> => {
  return await StreamPaymentMethod.findOne({
    where: { streamId, paymentType },
  });
};
