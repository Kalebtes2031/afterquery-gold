import { sequelize } from "#ours/backend/database/config.ts";
import { Reaction, type ReactionModel } from "#ours/backend/database/models/index.ts";

export interface MessageReactions {
  messageId: string;
  reactions: Array<{ reaction: string; count: number }>;
  totalCount: number;
}

interface ReactionCountRow {
  reaction: string;
  count: number;
}

export async function addReaction(
  messageId: string,
  userId: string,
  reaction: string,
  roomId: string,
): Promise<ReactionModel> {
  const transaction = await sequelize.transaction();

  try {
    // 1. Remove any existing reaction for this user and message
    await Reaction.destroy({
      where: { messageId, userId, reaction },
      transaction,
    });

    // 2. Create the new reaction
    const reactionRecord = await Reaction.create(
      {
        messageId,
        userId,
        reaction,
        roomId,
      },
      {
        transaction,
      },
    );

    await transaction.commit();
    return reactionRecord;
  } catch (error) {
    await transaction.rollback();

    const message = error instanceof Error ? error.message : "Unknown error";
    throw new Error(`Error adding reaction: ${message}`);
  }
}

export async function removeReaction(messageId: string, userId: string, reaction: string): Promise<boolean> {
  const deleted = await Reaction.destroy({
    where: { messageId, userId, reaction },
  });
  return deleted > 0;
}

export async function getMessageReactions(messageId: string): Promise<MessageReactions> {
  const reactions = (await Reaction.findAll({
    attributes: ["reaction", [sequelize.fn("COUNT", sequelize.col("reaction")), "count"]],
    where: { messageId },
    group: ["reaction"],
    order: [[sequelize.literal("count"), "DESC"]],
    raw: true,
  })) as unknown as ReactionCountRow[];

  const reactionCounts = reactions.map((row) => ({
    reaction: row.reaction,
    count: row.count,
  }));

  const totalCount = reactionCounts.reduce((sum, r) => sum + r.count, 0);

  return {
    messageId,
    reactions: reactionCounts,
    totalCount,
  };
}

export async function getUserReactionsForMessage(messageId: string, userId: string): Promise<string[]> {
  const reactions = await Reaction.findAll({
    attributes: ["reaction"],
    where: { messageId, userId },
    raw: true,
  });
  return reactions.map((r) => r.reaction);
}

export async function getRoomReactions(roomId: string, limit = 100): Promise<ReactionModel[]> {
  const reactions = await Reaction.findAll({
    where: { roomId },
    order: [["timestamp", "DESC"]],
    limit,
    raw: true,
  });
  return reactions;
}
