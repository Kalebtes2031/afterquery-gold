import {
  type CreationOptional,
  DataTypes,
  type InferAttributes,
  type InferCreationAttributes,
  type Model,
} from "sequelize";
import { sequelize } from "#ours/backend/database/config.ts";

export interface ReactionModel extends Model<InferAttributes<ReactionModel>, InferCreationAttributes<ReactionModel>> {
  id: CreationOptional<number>;
  messageId: string;
  userId: string;
  reaction: string;
  roomId: string;
  timestamp: CreationOptional<Date>;
}

export const Reaction = sequelize.define<ReactionModel>(
  "Reaction",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    messageId: {
      type: DataTypes.TEXT,
      allowNull: false,
      unique: "message_user_reaction_unique",
    },
    userId: {
      type: DataTypes.TEXT,
      allowNull: false,
      unique: "message_user_reaction_unique",
    },
    reaction: {
      type: DataTypes.TEXT,
      allowNull: false,
      unique: "message_user_reaction_unique",
    },
    roomId: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    timestamp: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    tableName: "reactions",
    timestamps: false,
    indexes: [{ fields: ["messageId"] }, { fields: ["roomId"] }],
  },
);
