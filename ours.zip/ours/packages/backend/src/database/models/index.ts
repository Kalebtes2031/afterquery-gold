import { Reaction } from "#ours/backend/database/models/reaction.ts";
import { Room } from "#ours/backend/database/models/room.ts";
import { RoomOwner } from "#ours/backend/database/models/room_owner.ts";
import { Stream } from "#ours/backend/database/models/stream.ts";
import { StreamPaymentMethod } from "#ours/backend/database/models/stream_payment_method.ts";
import { User } from "#ours/backend/database/models/user.ts";

// Define associations for many-to-many relationship between Users and Rooms (owners)
// User <-> Room through RoomOwner
User.belongsToMany(Room, {
  through: RoomOwner,
  as: "ownedRooms",
  foreignKey: "userId",
  otherKey: "roomId",
});

Room.belongsToMany(User, {
  through: RoomOwner,
  as: "owners",
  foreignKey: "roomId",
  otherKey: "userId",
});

// Define association between Stream and StreamPaymentMethod
Stream.hasMany(StreamPaymentMethod, {
  foreignKey: "streamId",
  as: "paymentMethods",
});

StreamPaymentMethod.belongsTo(Stream, {
  foreignKey: "streamId",
});

export { Reaction, User, Room, RoomOwner, Stream, StreamPaymentMethod };
export type { ReactionModel } from "#ours/backend/database/models/reaction.ts";
export type { RoomModel } from "#ours/backend/database/models/room.ts";
export type { StreamModel } from "#ours/backend/database/models/stream.ts";
export type { StreamPaymentMethodModel } from "#ours/backend/database/models/stream_payment_method.ts";
export type { UserModel } from "#ours/backend/database/models/user.ts";
