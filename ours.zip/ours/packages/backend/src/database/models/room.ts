import {
  type CreationOptional,
  DataTypes,
  type InferAttributes,
  type InferCreationAttributes,
  type Model,
} from "sequelize";
import { sequelize } from "#ours/backend/database/config.ts";

export interface RoomModel extends Model<InferAttributes<RoomModel>, InferCreationAttributes<RoomModel>> {
  id: CreationOptional<number>;
  roomId: string;
  arnString: string;
  createdAt: CreationOptional<Date>;
  isActive: CreationOptional<boolean>;
}

export const Room = sequelize.define<RoomModel>(
  "Room",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    roomId: {
      type: DataTypes.TEXT,
      allowNull: false,
      unique: true,
    },
    arnString: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
  },
  {
    tableName: "room_mappings",
    timestamps: false,
    indexes: [{ fields: ["roomId"] }, { fields: ["arnString"] }],
  },
);
