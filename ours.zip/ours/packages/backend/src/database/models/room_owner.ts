import {
  type CreationOptional,
  DataTypes,
  type InferAttributes,
  type InferCreationAttributes,
  type Model,
} from "sequelize";
import { sequelize } from "#ours/backend/database/config.ts";

export interface RoomOwnerModel
  extends Model<InferAttributes<RoomOwnerModel>, InferCreationAttributes<RoomOwnerModel>> {
  id: CreationOptional<number>;
  userId: string; // references User.id (TEXT)
  roomId: number; // references Room.id (INTEGER)
  createdAt: CreationOptional<Date>;
}

export const RoomOwner = sequelize.define<RoomOwnerModel>(
  "RoomOwner",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    userId: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    roomId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    tableName: "room_owners",
    timestamps: false,
    indexes: [{ unique: true, fields: ["userId", "roomId"] }, { fields: ["userId"] }, { fields: ["roomId"] }],
  },
);
