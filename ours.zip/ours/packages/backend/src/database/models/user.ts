import {
  type CreationOptional,
  DataTypes,
  type InferAttributes,
  type InferCreationAttributes,
  type Model,
} from "sequelize";
import { v4 as uuidv4 } from "uuid";
import { CHAT_USER_TYPES } from "#ours/backend/constants/index.ts";
import { sequelize } from "#ours/backend/database/config.ts";
import type { UserType } from "#ours/backend/types/chat.ts";

export interface UserModel extends Model<InferAttributes<UserModel>, InferCreationAttributes<UserModel>> {
  id: CreationOptional<string>;
  nickname: string;
  username?: string | null;
  email?: string;
  passwordHash?: string;
  userType: UserType;
  createdAt: CreationOptional<Date>;
  lastLogin?: Date;
  isActive: CreationOptional<boolean>;
  token?: string;
}

export const User = sequelize.define<UserModel>(
  "User",
  {
    id: {
      type: DataTypes.TEXT,
      primaryKey: true,
      defaultValue: () => uuidv4(),
    },
    nickname: {
      type: DataTypes.TEXT,
      allowNull: false,
      unique: true,
    },
    username: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    email: {
      type: DataTypes.TEXT,
      unique: true,
    },
    passwordHash: {
      type: DataTypes.TEXT,
    },
    userType: {
      type: DataTypes.ENUM(...Object.values(CHAT_USER_TYPES)),
      allowNull: false,
      defaultValue: CHAT_USER_TYPES.REGULAR,
    },
    createdAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    lastLogin: {
      type: DataTypes.DATE,
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    token: {
      type: DataTypes.TEXT,
    },
  },
  {
    tableName: "registered_users",
    indexes: [{ fields: ["nickname"] }, { fields: ["email"] }, { fields: ["userType"] }],
  },
);
