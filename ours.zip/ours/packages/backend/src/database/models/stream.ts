import {
  type CreationOptional,
  DataTypes,
  type InferAttributes,
  type InferCreationAttributes,
  type Model,
} from "sequelize";
import { sequelize } from "#ours/backend/database/config.ts";

export interface StreamModel extends Model<InferAttributes<StreamModel>, InferCreationAttributes<StreamModel>> {
  id: CreationOptional<number>;
  streamName: string;
  unlistedId: string;
  title: string;
  password?: string;
  ownerId: string;
  streamType: "youtube" | "vimeo" | "ivs";
  createdAt: CreationOptional<Date>;
  isActive: CreationOptional<boolean>;
  // IVS-specific fields
  ivsChannelArn?: string;
  ivsPlaybackUrl?: string;
  ivsIngestEndpoint?: string;
  ivsStreamKeyArn?: string;
  ivsStreamKeyValue?: string;
  isLive: CreationOptional<boolean>;
}

export const Stream = sequelize.define<StreamModel>(
  "Stream",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    streamName: {
      type: DataTypes.TEXT,
      allowNull: false,
      unique: true,
    },
    unlistedId: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    title: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    password: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    ownerId: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    streamType: {
      type: DataTypes.TEXT,
      allowNull: false,
      defaultValue: "youtube",
      validate: {
        isIn: [["youtube", "vimeo", "ivs"]],
      },
    },
    createdAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      defaultValue: true,
    },
    // IVS-specific fields
    ivsChannelArn: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    ivsPlaybackUrl: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    ivsIngestEndpoint: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    ivsStreamKeyArn: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    ivsStreamKeyValue: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    isLive: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
  },
  {
    tableName: "streams",
    timestamps: false,
    indexes: [
      { fields: ["streamName"] },
      { fields: ["unlistedId"] },
      { fields: ["ownerId"] },
      { fields: ["isActive"] },
      { fields: ["ivsChannelArn"] },
      { fields: ["isLive"] },
    ],
  },
);
