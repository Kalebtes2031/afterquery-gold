import {
  type CreationOptional,
  DataTypes,
  type InferAttributes,
  type InferCreationAttributes,
  type Model,
} from "sequelize";
import { sequelize } from "#ours/backend/database/config.ts";

export interface StreamPaymentMethodModel
  extends Model<InferAttributes<StreamPaymentMethodModel>, InferCreationAttributes<StreamPaymentMethodModel>> {
  id: CreationOptional<number>;
  streamId: number;
  paymentType: "venmo" | "cashapp" | "paypal";
  handle: string;
  createdAt: CreationOptional<Date>;
}

export const StreamPaymentMethod = sequelize.define<StreamPaymentMethodModel>(
  "StreamPaymentMethod",
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    streamId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: "streams",
        key: "id",
      },
      onDelete: "CASCADE",
    },
    paymentType: {
      type: DataTypes.ENUM("venmo", "cashapp", "paypal"),
      allowNull: false,
    },
    handle: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    createdAt: {
      type: DataTypes.DATE,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    tableName: "stream_payment_methods",
    timestamps: false,
    indexes: [
      { fields: ["streamId"] },
      { fields: ["paymentType"] },
      { fields: ["streamId", "paymentType"], unique: true },
    ],
  },
);
