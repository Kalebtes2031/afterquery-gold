import {
  type Channel,
  type ChannelLatencyMode,
  type ChannelType,
  CreateChannelCommand,
  CreateStreamKeyCommand,
  DeleteChannelCommand,
  DeleteStreamKeyCommand,
  GetChannelCommand,
  GetStreamCommand,
  IvsClient,
  ListChannelsCommand,
  ListStreamKeysCommand,
  StopStreamCommand,
  type StreamKey,
  UpdateChannelCommand,
} from "@aws-sdk/client-ivs";

export interface IVSStreamConfig {
  region: string;
  accessKeyId: string;
  secretAccessKey: string;
}

export interface CreateChannelRequest {
  name: string;
  latencyMode?: ChannelLatencyMode;
  type?: ChannelType;
  authorized?: boolean;
  recordingConfigurationArn?: string;
}

export interface CreateChannelResponse {
  channel: Channel;
  streamKey: StreamKey;
}

export interface StreamInfo {
  channelArn: string;
  streamId?: string;
  state?: string;
  health?: string;
  viewerCount?: number;
  startTime?: Date;
}

export function createIVSStreamService(config: IVSStreamConfig) {
  const client = new IvsClient({
    region: config.region,
    credentials: {
      accessKeyId: config.accessKeyId,
      secretAccessKey: config.secretAccessKey,
    },
  });

  /**
   * Validate AWS credentials
   */
  const validateCredentials = async (): Promise<boolean> => {
    try {
      await client.send(new ListChannelsCommand({ maxResults: 1 }));
      return true;
    } catch (error) {
      console.error("IVS Stream credential validation failed:", error);
      return false;
    }
  };

  /**
   * Create a new IVS channel with stream key
   */
  const createChannel = async (request: CreateChannelRequest): Promise<CreateChannelResponse> => {
    try {
      // Create the channel
      const channelCommand = new CreateChannelCommand({
        name: request.name,
        latencyMode: request.latencyMode || "LOW", // LOW = 2-5s latency
        type: request.type || "STANDARD",
        authorized: request.authorized ?? false,
        recordingConfigurationArn: request.recordingConfigurationArn,
      });

      const channelResponse = await client.send(channelCommand);

      if (!channelResponse.channel?.arn) {
        throw new Error("Failed to create channel");
      }

      // Create stream key for the channel
      const streamKeyCommand = new CreateStreamKeyCommand({
        channelArn: channelResponse.channel.arn,
      });

      const streamKeyResponse = await client.send(streamKeyCommand);

      if (!streamKeyResponse.streamKey) {
        throw new Error("Failed to create stream key");
      }

      return {
        channel: channelResponse.channel,
        streamKey: streamKeyResponse.streamKey,
      };
    } catch (error) {
      console.error("Error creating IVS channel:", error);
      throw error;
    }
  };

  /**
   * Get channel information
   */
  const getChannel = async (channelArn: string): Promise<Channel> => {
    try {
      const command = new GetChannelCommand({ arn: channelArn });
      const response = await client.send(command);

      if (!response.channel) {
        throw new Error("Channel not found");
      }

      return response.channel;
    } catch (error) {
      console.error("Error getting channel:", error);
      throw error;
    }
  };

  /**
   * Get stream information (live status, viewer count, etc.)
   */
  const getStream = async (channelArn: string): Promise<StreamInfo> => {
    try {
      const command = new GetStreamCommand({ channelArn });
      const response = await client.send(command);

      return {
        channelArn,
        streamId: response.stream?.streamId,
        state: response.stream?.state,
        health: response.stream?.health,
        viewerCount: response.stream?.viewerCount,
        startTime: response.stream?.startTime,
      };
    } catch (error) {
      // Stream not found means channel is offline
      if ((error as Error).name === "ResourceNotFoundException") {
        return {
          channelArn,
          state: "OFFLINE",
        };
      }
      console.error("Error getting stream:", error);
      throw error;
    }
  };

  /**
   * Update channel configuration
   */
  const updateChannel = async (
    channelArn: string,
    updates: {
      name?: string;
      latencyMode?: ChannelLatencyMode;
      authorized?: boolean;
    },
  ): Promise<Channel> => {
    try {
      const command = new UpdateChannelCommand({
        arn: channelArn,
        ...updates,
      });
      const response = await client.send(command);

      if (!response.channel) {
        throw new Error("Failed to update channel");
      }

      return response.channel;
    } catch (error) {
      console.error("Error updating channel:", error);
      throw error;
    }
  };

  /**
   * Delete a channel
   */
  const deleteChannel = async (channelArn: string): Promise<void> => {
    try {
      const command = new DeleteChannelCommand({ arn: channelArn });
      await client.send(command);
    } catch (error) {
      console.error("Error deleting channel:", error);
      throw error;
    }
  };

  /**
   * Stop a live stream
   */
  const stopStream = async (channelArn: string): Promise<void> => {
    try {
      const command = new StopStreamCommand({ channelArn });
      await client.send(command);
    } catch (error) {
      console.error("Error stopping stream:", error);
      throw error;
    }
  };

  /**
   * List stream keys for a channel
   */
  const listStreamKeys = async (channelArn: string): Promise<StreamKey[]> => {
    try {
      const command = new ListStreamKeysCommand({ channelArn });
      const response = await client.send(command);
      return response.streamKeys || [];
    } catch (error) {
      console.error("Error listing stream keys:", error);
      throw error;
    }
  };

  /**
   * Delete a stream key
   */
  const deleteStreamKey = async (streamKeyArn: string): Promise<void> => {
    try {
      const command = new DeleteStreamKeyCommand({ arn: streamKeyArn });
      await client.send(command);
    } catch (error) {
      console.error("Error deleting stream key:", error);
      throw error;
    }
  };

  /**
   * List all channels
   */
  const listChannels = async (): Promise<Channel[]> => {
    try {
      const command = new ListChannelsCommand({ maxResults: 50 });
      const response = await client.send(command);
      return response.channels || [];
    } catch (error) {
      console.error("Error listing channels:", error);
      throw error;
    }
  };

  return {
    client,
    validateCredentials,
    createChannel,
    getChannel,
    getStream,
    updateChannel,
    deleteChannel,
    stopStream,
    listStreamKeys,
    deleteStreamKey,
    listChannels,
  };
}

export type IVSStreamService = ReturnType<typeof createIVSStreamService>;
