import { destroyRedisClient } from "#ours/backend/session/redis.ts";

export class CleanupService {
  private cleanupInterval: NodeJS.Timeout | null = null;
  private isRunning = false;

  constructor(private intervalMinutes = 5) {
    this.start();
  }

  start(): void {
    if (this.isRunning) {
      console.log("Cleanup service is already running");
      return;
    }

    this.isRunning = true;
    console.log(`🧹 Starting cleanup service (runs every ${this.intervalMinutes} minutes)`);

    // Run immediately on start
    this.runCleanup();

    // Schedule periodic cleanup
    this.cleanupInterval = setInterval(
      () => {
        this.runCleanup();
      },
      this.intervalMinutes * 60 * 1000,
    );
  }

  stop(): void {
    if (!this.isRunning) {
      return;
    }

    this.isRunning = false;
    console.log("🛑 Stopping cleanup service");

    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }

  private async runCleanup(): Promise<void> {
    console.log("🧹 Running cleanup job...");
    const startTime = Date.now();

    const duration = Date.now() - startTime;
    console.log(`✅ Cleanup completed in ${duration}ms`);
  }

  // Manual cleanup trigger
  async triggerCleanup(): Promise<void> {
    console.log("🧹 Manual cleanup triggered");
    await this.runCleanup();
  }

  // Graceful shutdown
  async shutdown(): Promise<void> {
    console.log("🛑 Shutting down cleanup service...");
    this.stop();

    // Destroy store connections
    destroyRedisClient();

    console.log("✅ Cleanup service shutdown complete");
  }

  getStatus(): { running: boolean; intervalMinutes: number } {
    return {
      running: this.isRunning,
      intervalMinutes: this.intervalMinutes,
    };
  }
}

// Singleton instance
let cleanupServiceInstance: CleanupService | null = null;

export function getCleanupService(): CleanupService {
  if (!cleanupServiceInstance) {
    cleanupServiceInstance = new CleanupService();
  }
  return cleanupServiceInstance;
}

export function shutdownCleanupService(): Promise<void> {
  if (cleanupServiceInstance) {
    return cleanupServiceInstance.shutdown();
  }
  return Promise.resolve();
}

// Handle process termination
process.on("SIGINT", async () => {
  console.log("Received SIGINT, shutting down gracefully...");
  await shutdownCleanupService();
  process.exit(0);
});

process.on("SIGTERM", async () => {
  console.log("Received SIGTERM, shutting down gracefully...");
  await shutdownCleanupService();
  process.exit(0);
});
