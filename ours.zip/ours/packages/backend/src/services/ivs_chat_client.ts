import {
  ChatTokenCapability,
  CreateChatTokenCommand,
  CreateRoomCommand,
  DeleteMessageCommand,
  DisconnectUserCommand,
  GetRoomCommand,
  IvschatClient,
  ListRoomsCommand,
  ListTagsForResourceCommand,
  type MessageReviewHandler,
  SendEventCommand,
  TagResourceCommand,
  UntagResourceCommand,
} from "@aws-sdk/client-ivschat";
import type { ChannelRole, IChatTokenRequest, IChatTokenResponse, UserType } from "#ours/backend/types/chat.js";

export interface IVSChatConfig {
  region: string;
  accessKeyId: string;
  secretAccessKey: string;
}

export interface ChatRoom {
  arn?: string;
  id?: string;
  name?: string;
  createTime?: Date;
  updateTime?: Date;
  messageReviewHandler?: MessageReviewHandler;
  tags?: Record<string, string>;
}

export interface SendEventRequest {
  roomIdentifier: string;
  eventName: string;
  attributes?: Record<string, string>;
}

export interface DisconnectUserRequest {
  roomIdentifier: string;
  userId: string;
  reason?: string;
}

export interface DeleteMessageRequest {
  roomIdentifier: string;
  id: string;
  reason?: string;
}

export interface CreateRoomRequest {
  name?: string;
  maximumMessageRatePerSecond?: number;
  maximumMessageLength?: number;
  messageReviewHandler?: MessageReviewHandler;
  tags?: Record<string, string>;
}

export function createIVSChatService(config: IVSChatConfig) {
  const region = config.region;
  const client = new IvschatClient({
    region: config.region,
    credentials: {
      accessKeyId: config.accessKeyId,
      secretAccessKey: config.secretAccessKey,
    },
  });

  const validateCredentials = async (): Promise<boolean> => {
    try {
      await client.send(new ListRoomsCommand({ maxResults: 1 }));
      return true;
    } catch (error) {
      console.error("IVS Chat credential validation failed:", error);
      return false;
    }
  };

  const createChatToken = async (request: IChatTokenRequest): Promise<IChatTokenResponse> => {
    try {
      const command = new CreateChatTokenCommand({
        roomIdentifier: request.roomIdentifier,
        userId: request.userId,
        capabilities: request.capabilities || [ChatTokenCapability.SEND_MESSAGE],
        sessionDurationInMinutes: request.sessionDurationInMinutes || 60,
        attributes: request.attributes
          ? {
              id: request.attributes.id || "",
              nickname: request.attributes.nickname || "",
              username: request.attributes.username || "",
              userType: request.attributes.userType || "",
              channelRole: request.attributes.channelRole || "",
              isRegistered: request.attributes.isRegistered || "",
              chatUserId: request.attributes.chatUserId || "",
            }
          : undefined,
      });
      const response = await client.send(command);
      return {
        success: true,
        endpoint: getWebSocketEndpoint(),
        roomId: request.roomIdentifier,
        userId: request.userId,
        token: response.token || "",
        tokenExpirationTime: response.tokenExpirationTime,
        sessionExpirationTime: response.sessionExpirationTime,
        user: {
          id: request.attributes?.id || "",
          nickname: request.attributes?.nickname || "",
          username: request.attributes?.username || "",
          userType: (request.attributes?.userType as UserType) || "",
          channelRole: (request.attributes?.channelRole as ChannelRole) || "",
          isRegistered: request.attributes?.isRegistered === "true",
          chatUserId: request.attributes?.chatUserId || "",
        },
      };
    } catch (error) {
      console.error("Failed to create chat token:", error);
      throw error;
    }
  };

  const getRoom = async (identifier: string): Promise<ChatRoom | null> => {
    try {
      const command = new GetRoomCommand({ identifier });
      const response = await client.send(command);
      if (!response.arn) {
        return null;
      }
      return {
        arn: response.arn,
        id: response.id,
        name: response.name,
        createTime: response.createTime,
        updateTime: response.updateTime,
        messageReviewHandler: response.messageReviewHandler,
        tags: response.tags,
      };
    } catch (error) {
      console.error("Failed to get room:", error);
      return null;
    }
  };

  const createRoom = async (request: CreateRoomRequest): Promise<ChatRoom | null> => {
    try {
      const command = new CreateRoomCommand({
        name: request.name,
        maximumMessageRatePerSecond: request.maximumMessageRatePerSecond,
        maximumMessageLength: request.maximumMessageLength,
        messageReviewHandler: request.messageReviewHandler,
        tags: request.tags,
      });
      const response = await client.send(command);
      return {
        arn: response.arn,
        id: response.id,
        name: response.name,
        createTime: response.createTime,
        updateTime: response.updateTime,
        messageReviewHandler: response.messageReviewHandler,
        tags: response.tags,
      };
    } catch (error) {
      console.error("Failed to create room:", error);
      throw error;
    }
  };

  const sendEvent = async (
    request: SendEventRequest,
  ): Promise<{
    id?: string;
  }> => {
    try {
      const command = new SendEventCommand({
        roomIdentifier: request.roomIdentifier,
        eventName: request.eventName,
        attributes: request.attributes,
      });
      const response = await client.send(command);
      return { id: response.id };
    } catch (error) {
      console.error("Failed to send event:", error);
      throw error;
    }
  };

  const disconnectUser = async (request: DisconnectUserRequest): Promise<void> => {
    try {
      const command = new DisconnectUserCommand({
        roomIdentifier: request.roomIdentifier,
        userId: request.userId,
        reason: request.reason,
      });
      await client.send(command);
    } catch (error) {
      console.error("Failed to disconnect user:", error);
      throw error;
    }
  };

  const deleteMessage = async (request: DeleteMessageRequest): Promise<void> => {
    try {
      const command = new DeleteMessageCommand({
        roomIdentifier: request.roomIdentifier,
        id: request.id,
        reason: request.reason,
      });
      await client.send(command);
    } catch (error) {
      console.error("Failed to delete message:", error);
      throw error;
    }
  };

  const getRoomTags = async (resourceArn: string): Promise<Record<string, string>> => {
    try {
      const command = new ListTagsForResourceCommand({ resourceArn });
      const response = await client.send(command);
      return response.tags || {};
    } catch (error) {
      console.error("Failed to get room tags:", error);
      return {};
    }
  };

  const tagRoom = async (resourceArn: string, tags: Record<string, string>): Promise<void> => {
    try {
      const command = new TagResourceCommand({ resourceArn, tags });
      await client.send(command);
    } catch (error) {
      console.error("Failed to tag room:", error);
      throw error;
    }
  };

  const untagRoom = async (resourceArn: string, tagKeys: string[]): Promise<void> => {
    try {
      const command = new UntagResourceCommand({ resourceArn, tagKeys });
      await client.send(command);
    } catch (error) {
      console.error("Failed to untag room:", error);
      throw error;
    }
  };

  const getWebSocketEndpoint = (): string => {
    return `wss://edge.ivschat.${region}.amazonaws.com`;
  };

  const getConnectionInfo = async (
    roomIdentifier: string,
    userId: string,
    username?: string,
  ): Promise<{
    endpoint: string;
    token: string;
    tokenExpirationTime?: Date;
    sessionExpirationTime?: Date;
    room: ChatRoom | null;
  }> => {
    const [tokenResponse, room] = await Promise.all([
      createChatToken({
        roomIdentifier,
        userId,
        capabilities: [ChatTokenCapability.SEND_MESSAGE],
        sessionDurationInMinutes: 60,
        attributes: username ? { username } : undefined,
      }),
      getRoom(roomIdentifier),
    ]);

    if (!tokenResponse.token) {
      throw new Error("Failed to generate token");
    }

    return {
      endpoint: getWebSocketEndpoint(),
      token: tokenResponse.token,
      tokenExpirationTime: tokenResponse.tokenExpirationTime,
      sessionExpirationTime: tokenResponse.sessionExpirationTime,
      room,
    };
  };

  return {
    client,
    validateCredentials,
    createChatToken,
    getRoom,
    createRoom,
    sendEvent,
    disconnectUser,
    deleteMessage,
    getRoomTags,
    tagRoom,
    untagRoom,
    getWebSocketEndpoint,
    getConnectionInfo,
  };
}

export type IVSChatService = ReturnType<typeof createIVSChatService>;
