import { SendEventCommand } from "@aws-sdk/client-ivschat";
import type { IVSChatService } from "#ours/backend/services/ivs_chat_client";
// import { reactions } from "#ours/backend/database/operations/index.ts";
import { reactions } from "#ours/backend/session/operations/index.ts";

export interface ReactionEvent {
  type: "reaction_add" | "reaction_remove";
  messageId: string;
  userId: string;
  reaction: string;
  roomId: string;
  timestamp: Date;
}

export interface ReactionToggleResult {
  success: boolean;
  action: "added" | "removed" | "error";
  currentReactions: string[];
  reactionCounts: { reaction: string; count: number }[];
}

export interface IVSIncomingReactionEvent {
  eventName: string;
  attributes: {
    type: "reaction_add" | "reaction_remove";
    messageId: string;
    userId: string;
    reaction: string;
    roomId: string;
  };
}

async function sendReactionEvent(chatService: IVSChatService, arnString: string, event: ReactionEvent): Promise<void> {
  const command = new SendEventCommand({
    roomIdentifier: arnString,
    eventName: "reaction",
    attributes: {
      type: event.type,
      messageId: event.messageId,
      userId: event.userId,
      reaction: event.reaction,
      timestamp: event.timestamp.toISOString(),
    },
  });

  await chatService.client.send(command);
}

async function performReactionToggle(
  chatService: IVSChatService,
  arnString: string,
  messageId: string,
  userId: string,
  reaction: string,
  hasReaction: boolean,
): Promise<{ success: boolean; action: "added" | "removed" }> {
  try {
    if (hasReaction) {
      const success = await reactions.removeReaction(messageId, userId, reaction);
      if (success) {
        await sendReactionEvent(chatService, arnString, {
          type: "reaction_remove",
          messageId,
          userId,
          reaction,
          roomId: arnString,
          timestamp: new Date(),
        });
      }
      return { success, action: "removed" };
    } else {
      const reactionRecord = await reactions.addReaction(messageId, userId, reaction, arnString);
      const success = !!reactionRecord;
      if (success) {
        await sendReactionEvent(chatService, arnString, {
          type: "reaction_add",
          messageId,
          userId,
          reaction,
          roomId: arnString,
          timestamp: new Date(),
        });
      }
      return { success, action: "added" };
    }
  } catch (error) {
    console.error("Error in performReactionToggle:", error);
    return { success: false, action: hasReaction ? "removed" : "added" };
  }
}

async function toggleReactionInternal(
  chatService: IVSChatService,
  arnString: string,
  messageId: string,
  userId: string,
  reaction: string,
): Promise<ReactionToggleResult> {
  try {
    const userReactions = await reactions.getUserReactionsForMessage(messageId, userId);
    const hasReaction = userReactions.includes(reaction);

    const { success, action } = await performReactionToggle(
      chatService,
      arnString,
      messageId,
      userId,
      reaction,
      hasReaction,
    );

    const currentReactions = await reactions.getUserReactionsForMessage(messageId, userId);
    const messageReactions = await reactions.getMessageReactions(messageId);

    return {
      success,
      action,
      currentReactions,
      reactionCounts: messageReactions.reactions,
    };
  } catch (error) {
    console.error("Error toggling reaction:", error);
    return {
      success: false,
      action: "error",
      currentReactions: [],
      reactionCounts: [],
    };
  }
}

async function getMessageReactionsInternal(messageId: string) {
  return reactions.getMessageReactions(messageId);
}

async function getUserReactionsForMessageInternal(messageId: string, userId: string) {
  return reactions.getUserReactionsForMessage(messageId, userId);
}

async function getRoomReactionsInternal(roomId: string, limit: number = 100) {
  return reactions.getRoomReactions(roomId, limit);
}

async function handleIncomingReactionEventInternal(eventData: IVSIncomingReactionEvent): Promise<void> {
  try {
    const { type, messageId, userId, reaction, roomId } = eventData.attributes;
    if (type === "reaction_add") {
      await reactions.addReaction(messageId, userId, reaction, roomId);
    } else if (type === "reaction_remove") {
      await reactions.removeReaction(messageId, userId, reaction);
    }
  } catch (error) {
    console.error("Error handling incoming reaction event:", error);
  }
}

export function createReactionService(chatService: IVSChatService) {
  return {
    toggleReaction: (arnString: string, messageId: string, userId: string, reaction: string) =>
      toggleReactionInternal(chatService, arnString, messageId, userId, reaction),
    getMessageReactions: (messageId: string) => getMessageReactionsInternal(messageId),
    getUserReactionsForMessage: (messageId: string, userId: string) =>
      getUserReactionsForMessageInternal(messageId, userId),
    getRoomReactions: (roomId: string, limit: number = 100) => getRoomReactionsInternal(roomId, limit),
    handleIncomingReactionEvent: (eventData: IVSIncomingReactionEvent) =>
      handleIncomingReactionEventInternal(eventData),
    close: () => {
      // No need to close anything with the new operations approach
      console.log("ReactionService closed");
    },
  };
}

export type ReactionServiceAPI = ReturnType<typeof createReactionService>;
