import { URLSearchParams } from "node:url";

export type GifProvider = "giphy" | "tenor";

export interface GifSearchResult {
  id: string;
  url: string;
  previewUrl: string;
  pageUrl: string;
  title: string;
  provider: GifProvider;
}

const splitPathSegments = (path: string) => path.split("/").filter((segment) => segment !== "");

type GiphyImage = {
  url?: string;
};

type GiphyItem = {
  id?: string;
  title?: string;
  url?: string;
  images?: {
    original?: GiphyImage;
    preview_gif?: GiphyImage;
    fixed_height_small?: GiphyImage;
  };
};

type TenorMediaFormats = {
  gif?: {
    url?: string;
  };
  mediumgif?: {
    url?: string;
  };
  tinygif?: {
    url?: string;
  };
  nanogif?: {
    url?: string;
  };
};

type TenorItem = {
  id?: string;
  title?: string;
  content_description?: string;
  itemurl?: string;
  media_formats?: TenorMediaFormats;
};

const ensureKey = (value: string | undefined, name: string) => {
  if (value === undefined || value.trim() === "") {
    throw new Error(`${name} is not configured`);
  }
  return value;
};

const giphyApiKey = process.env.GIPHY_API_KEY;
const tenorApiKey = process.env.TENOR_API_KEY;
const tenorClientKey = process.env.TENOR_CLIENT_KEY ?? "ours-app";
const tenorLocale = process.env.TENOR_LOCALE ?? "en_US";

const extractGiphyId = (url: URL) => {
  const hostname = url.hostname.toLowerCase();
  const segments = splitPathSegments(url.pathname);
  if (hostname === "giphy.com" || hostname.endsWith(".giphy.com")) {
    const lastSegment = segments[segments.length - 1];
    if (!lastSegment) {
      return null;
    }
    const parts = lastSegment.split("-").filter((part) => part !== "");
    const candidate = parts[parts.length - 1];
    if (candidate && /^[A-Za-z0-9]+$/.test(candidate)) {
      return candidate;
    }
    return lastSegment;
  }
  if (hostname.startsWith("media") || hostname === "i.giphy.com") {
    const candidate = segments
      .slice()
      .reverse()
      .find((segment) => /^[A-Za-z0-9]+$/.test(segment));
    return candidate ?? null;
  }
  return null;
};

const extractTenorId = (url: URL) => {
  const hostname = url.hostname.toLowerCase();
  const segments = splitPathSegments(url.pathname);
  if (hostname === "tenor.com" || hostname.endsWith(".tenor.com")) {
    const lastSegment = segments[segments.length - 1];
    if (!lastSegment) {
      return null;
    }
    const parts = lastSegment.split("-").filter((part) => part !== "");
    const candidate = parts[parts.length - 1];
    if (candidate && /^[A-Za-z0-9_]+$/.test(candidate) && candidate.length >= 4) {
      return candidate;
    }
    return null;
  }
  if (hostname.startsWith("media")) {
    if (segments[0] === "m") {
      return segments[1] ?? null;
    }
    return segments[0] ?? null;
  }
  return null;
};

const mapGiphyItem = (item: GiphyItem): GifSearchResult | null => {
  if (!item.id) {
    return null;
  }
  const images = item.images;
  const originalUrl = images?.original?.url;
  const previewCandidate = images?.preview_gif?.url ?? images?.fixed_height_small?.url ?? originalUrl;
  if (!originalUrl || !previewCandidate) {
    return null;
  }
  return {
    id: item.id,
    url: originalUrl,
    previewUrl: previewCandidate,
    pageUrl: item.url ?? `https://giphy.com/gifs/${item.id}`,
    title: item.title ?? "",
    provider: "giphy",
  };
};

const mapTenorItem = (item: TenorItem): GifSearchResult | null => {
  if (!item.id) {
    return null;
  }
  const formats = item.media_formats;
  const originalUrl = formats?.gif?.url ?? formats?.mediumgif?.url ?? formats?.tinygif?.url ?? formats?.nanogif?.url;
  const previewCandidate = formats?.tinygif?.url ?? formats?.nanogif?.url ?? originalUrl;
  if (!originalUrl || !previewCandidate) {
    return null;
  }
  return {
    id: item.id,
    url: originalUrl,
    previewUrl: previewCandidate,
    pageUrl: item.itemurl ?? `https://tenor.com/view/${item.id}`,
    title: item.title ?? item.content_description ?? "",
    provider: "tenor",
  };
};

export const searchGiphy = async (query: string, limit: number) => {
  const apiKey = ensureKey(giphyApiKey, "GIPHY_API_KEY");
  const params = new URLSearchParams({
    api_key: apiKey,
    q: query,
    limit: limit.toString(),
    rating: "pg-13",
  });
  const response = await fetch(`https://api.giphy.com/v1/gifs/search?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`Giphy request failed with status ${response.status}`);
  }
  const data = (await response.json()) as { data?: GiphyItem[] };
  const items = Array.isArray(data.data) ? data.data : [];
  return items.map(mapGiphyItem).filter((item): item is GifSearchResult => item !== null);
};

export const searchTenor = async (query: string, limit: number) => {
  const apiKey = ensureKey(tenorApiKey, "TENOR_API_KEY");
  const params = new URLSearchParams({
    key: apiKey,
    q: query,
    limit: limit.toString(),
    media_filter: "gif",
    client_key: tenorClientKey,
    locale: tenorLocale,
  });
  const response = await fetch(`https://tenor.googleapis.com/v2/search?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`Tenor request failed with status ${response.status}`);
  }
  const data = (await response.json()) as { results?: TenorItem[] };
  const items = Array.isArray(data.results) ? data.results : [];
  return items.map(mapTenorItem).filter((item): item is GifSearchResult => item !== null);
};

export const getGiphyById = async (id: string) => {
  const apiKey = ensureKey(giphyApiKey, "GIPHY_API_KEY");
  const params = new URLSearchParams({ api_key: apiKey });
  const response = await fetch(`https://api.giphy.com/v1/gifs/${encodeURIComponent(id)}?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`Giphy request failed with status ${response.status}`);
  }
  const data = (await response.json()) as { data?: GiphyItem };
  if (!data.data) {
    throw new Error("Giphy response missing data");
  }
  const mapped = mapGiphyItem(data.data);
  if (!mapped) {
    throw new Error("Unable to map Giphy response");
  }
  return mapped;
};

export const getTenorById = async (id: string) => {
  const apiKey = ensureKey(tenorApiKey, "TENOR_API_KEY");
  const params = new URLSearchParams({
    key: apiKey,
    ids: id,
    media_filter: "gif",
    client_key: tenorClientKey,
    locale: tenorLocale,
  });
  const response = await fetch(`https://tenor.googleapis.com/v2/posts?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`Tenor request failed with status ${response.status}`);
  }
  const data = (await response.json()) as { results?: TenorItem[] };
  const first = Array.isArray(data.results) ? data.results[0] : undefined;
  if (!first) {
    throw new Error("Tenor response missing data");
  }
  const mapped = mapTenorItem(first);
  if (!mapped) {
    throw new Error("Unable to map Tenor response");
  }
  return mapped;
};

export const resolveGifByUrl = async (rawUrl: string) => {
  const parsed = new URL(rawUrl);
  const hostname = parsed.hostname.toLowerCase();
  const segments = hostname.split(".");
  const baseDomain = segments.slice(-2).join(".");
  if (baseDomain === "giphy.com") {
    if (parsed.pathname.toLowerCase().endsWith(".gif")) {
      const id = extractGiphyId(parsed) ?? parsed.pathname;
      return {
        id,
        url: rawUrl,
        previewUrl: rawUrl,
        pageUrl: rawUrl,
        title: "",
        provider: "giphy",
      };
    }
    const id = extractGiphyId(parsed);
    if (!id) {
      throw new Error("Unable to extract Giphy id");
    }
    return getGiphyById(id);
  }
  if (baseDomain === "tenor.com") {
    if (parsed.pathname.toLowerCase().endsWith(".gif")) {
      const id = extractTenorId(parsed) ?? parsed.pathname;
      return {
        id,
        url: rawUrl,
        previewUrl: rawUrl,
        pageUrl: rawUrl,
        title: "",
        provider: "tenor",
      };
    }
    const id = extractTenorId(parsed);
    if (!id) {
      throw new Error("Unable to extract Tenor id");
    }
    return getTenorById(id);
  }
  throw new Error("Unsupported GIF provider");
};
