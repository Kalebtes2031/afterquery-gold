import { v4 as uuidv4 } from "uuid";
import { CHAT_USER_TYPES } from "#ours/backend/constants/index.ts";
import type { UserModel as RegisteredUser } from "#ours/backend/database/models/index.ts";
import { users as userOps } from "#ours/backend/database/operations/index.ts";
import * as session from "#ours/backend/session/index.ts";
import type { UserSession } from "#ours/backend/session/types.ts";

type UserType = (typeof CHAT_USER_TYPES)[keyof typeof CHAT_USER_TYPES];

interface User {
  id: string;
  nickname: string;
  type: UserType;
  chatUserId: string;
  joinedAt: Date;
  lastActivity: Date;
  connectionStatus: "active" | "idle" | "disconnected";
  isRegistered?: boolean;
}

type UserManagerAPI = {
  addUser: (
    nickname: string,
    channelId: string,
    type?: UserType,
    _authToken?: string,
  ) => Promise<{ success: boolean; error?: string; user?: User; sessionData?: UserSession }>;
  updateUser: (
    nickname: string,
    sessionData: UserSession,
  ) => Promise<{ success: boolean; error?: string; user?: User; sessionData?: UserSession }>;
  updateRegisteredUserById: (userId: string, data: Partial<RegisteredUser>) => Promise<void>;
  removeUser: (nickname: string, channelId?: string) => Promise<User | null>;
  getUser: (nickname: string) => Promise<User | null>;
  getChannelUsers: (channelId: string) => Promise<string[]>;
  getChannelUserCount: (channelId: string) => Promise<number>;
  updateUserActivity: (nickname: string) => Promise<void>;
  isNicknameAvailable: (
    nickname: string,
    userType?: UserType,
    userId?: string,
  ) => Promise<{ available: boolean; reason?: string }>;
  addReservedNickname: (nickname: string) => void;
  removeReservedNickname: (nickname: string) => void;
  getReservedNicknames: () => string[];
  createRegisteredUser: (
    nickname: string,
    userType: "regular" | "moderator" | "admin",
    email?: string,
    passwordHash?: string,
    token?: string,
    _userId?: string,
  ) => Promise<{ success: boolean; error?: string; user?: RegisteredUser }>;
  getRegisteredUser: (nickname: string) => Promise<RegisteredUser | null>;
};

function createUserManager(): UserManagerAPI {
  const hardcodedReserved: Set<string> = new Set(["system", "bot", "api", "service"]);
  const reservedNicknames: Set<string> = new Set();

  async function addUser(
    nickname: string,
    channelId: string,
    type: UserType = CHAT_USER_TYPES.TEMPORARY,
    _authToken?: string, // For registered users
  ): Promise<{ success: boolean; error?: string; user?: User; sessionData?: UserSession }> {
    try {
      // Check if nickname is already taken by an active user
      const exists = await session.users.userExists(nickname);
      if (exists) {
        return { success: false, error: "Nickname already taken" };
      }

      let registeredUser: RegisteredUser | null = null;
      let finalUserType = type;

      // Check if user is trying to use a registered nickname
      if (type !== CHAT_USER_TYPES.TEMPORARY) {
        registeredUser = await userOps.getUserByNickname(nickname);
        if (registeredUser) {
          // TODO: Validate authToken here when authentication is implemented
          finalUserType = registeredUser.userType as UserType;
          await userOps.updateLastLogin(registeredUser.id);
        } else {
          return { success: false, error: "User not found in database" };
        }
      } else {
        // For temporary users, check if nickname is reserved in database or hardcoded
        const isReservedInDB = await userOps.isNicknameReserved(nickname);
        const isHardcodedReserved = hardcodedReserved.has(nickname.toLowerCase());
        if (isReservedInDB || isHardcodedReserved) {
          return { success: false, error: "Nickname is reserved" };
        }
      }

      const now = Date.now();
      const userId = uuidv4();

      // Map UserType to store userType
      let storeUserType: "temporary" | "admin" | "moderator";
      switch (finalUserType) {
        case CHAT_USER_TYPES.ADMIN:
          storeUserType = "admin";
          break;
        case CHAT_USER_TYPES.MODERATOR:
          storeUserType = "moderator";
          break;
        default:
          storeUserType = "temporary"; // TEMPORARY and REGULAR both use 'temporary' in store
      }

      const sessionData: UserSession = {
        sessionId: userId,
        nickname,
        userType: storeUserType,
        channelId,
        joinedAt: now,
        lastActivity: now,
        chatUserId: userId,
        connectionStatus: "active",
      };

      const user: User = {
        id: userId,
        nickname,
        type: finalUserType,
        chatUserId: userId,
        joinedAt: new Date(now),
        lastActivity: new Date(now),
        connectionStatus: "active",
        isRegistered: Boolean(registeredUser),
      };

      // Store session with different TTL based on user type
      const ttl = 86400; // 24 hours for all users
      await session.users.setUser(nickname, sessionData, ttl);
      console.log("Adding user to channel", channelId, nickname);
      await session.users.addUserToChannel(channelId, nickname);

      return { success: true, user, sessionData };
    } catch (error) {
      console.error("Error adding user:", error);
      return { success: false, error: "Internal server error" };
    }
  }

  async function updateUser(
    nickname: string,
    sessionData: UserSession,
  ): Promise<{ success: boolean; error?: string; user?: User; sessionData?: UserSession }> {
    try {
      await session.users.updateUser(nickname, sessionData);
      const user: User = {
        id: sessionData.chatUserId,
        nickname,
        type: sessionData.userType as UserType,
        chatUserId: sessionData.chatUserId || "",
        joinedAt: new Date(sessionData.joinedAt),
        lastActivity: new Date(sessionData.lastActivity),
        connectionStatus: "active",
        isRegistered: Boolean(sessionData.userType !== CHAT_USER_TYPES.TEMPORARY),
      };
      return { success: true, user, sessionData };
    } catch (error) {
      console.error("Error updating user:", error);
      return { success: false, error: "Internal server error" };
    }
  }

  async function updateRegisteredUserById(userId: string, data: Partial<RegisteredUser>): Promise<void> {
    await userOps.updateUser(userId, data);
  }

  async function removeUser(nickname: string, channelId?: string): Promise<User | null> {
    try {
      const sessionData = await session.users.getUserByNickname(nickname);
      if (!sessionData) {
        return null;
      }

      // Map store userType back to UserType
      let userType: UserType;
      switch (sessionData.userType) {
        case "admin":
          userType = CHAT_USER_TYPES.ADMIN;
          break;
        case "moderator":
          userType = CHAT_USER_TYPES.MODERATOR;
          break;
        default: {
          // Check if user is registered to determine if REGULAR or TEMPORARY
          const registeredUser = await userOps.getUserByNickname(nickname);
          userType = registeredUser ? CHAT_USER_TYPES.REGULAR : CHAT_USER_TYPES.TEMPORARY;
        }
      }

      const user: User = {
        id: sessionData.sessionId,
        nickname: sessionData.nickname,
        type: userType,
        chatUserId: sessionData.chatUserId,
        joinedAt: new Date(sessionData.joinedAt),
        lastActivity: new Date(sessionData.lastActivity),
        connectionStatus: sessionData.connectionStatus,
        isRegistered: userType !== CHAT_USER_TYPES.TEMPORARY,
      };

      await session.users.deleteUser(nickname);

      if (channelId) {
        await session.users.removeUserFromChannel(channelId, nickname);
      } else if (sessionData.channelId) {
        await session.users.removeUserFromChannel(sessionData.channelId, nickname);
      }

      return user;
    } catch (error) {
      console.error("Error removing user:", error);
      return null;
    }
  }

  async function getUser(nickname: string): Promise<User | null> {
    try {
      const sessionData = await session.users.getUserByNickname(nickname);
      if (!sessionData) {
        return null;
      }

      let userType: UserType;
      switch (sessionData.userType) {
        case "admin":
          userType = CHAT_USER_TYPES.ADMIN;
          break;
        case "moderator":
          userType = CHAT_USER_TYPES.MODERATOR;
          break;
        default: {
          // Check if user is registered to determine if REGULAR or TEMPORARY
          const registeredUser = await userOps.getUserByNickname(nickname);
          userType = registeredUser ? CHAT_USER_TYPES.REGULAR : CHAT_USER_TYPES.TEMPORARY;
        }
      }

      return {
        id: sessionData.sessionId,
        nickname: sessionData.nickname,
        type: userType,
        chatUserId: sessionData.chatUserId,
        joinedAt: new Date(sessionData.joinedAt),
        lastActivity: new Date(sessionData.lastActivity),
        connectionStatus: sessionData.connectionStatus,
        isRegistered: userType !== CHAT_USER_TYPES.TEMPORARY,
      };
    } catch (error) {
      console.error("Error getting user:", error);
      return null;
    }
  }

  async function getChannelUsers(channelId: string): Promise<string[]> {
    try {
      return await session.users.getChannelUsers(channelId);
    } catch (error) {
      console.error("Error getting channel users:", error);
      return [];
    }
  }

  async function getChannelUserCount(channelId: string): Promise<number> {
    try {
      return await session.users.getChannelUserCount(channelId);
    } catch (error) {
      console.error("Error getting channel user count:", error);
      return 0;
    }
  }

  async function updateUserActivity(nickname: string): Promise<void> {
    try {
      await session.users.updateUserActivity(nickname);
    } catch (error) {
      console.error("Error updating user activity:", error);
    }
  }

  async function isNicknameAvailable(
    nickname: string,
    userType: UserType = CHAT_USER_TYPES.TEMPORARY,
    userId?: string,
  ): Promise<{ available: boolean; reason?: string }> {
    try {
      // Check if nickname is already taken by an active user
      const exists = await session.users.userExists(nickname, userId);
      if (exists) {
        return { available: false, reason: "in_use" };
      }

      // For temporary users, check if nickname is reserved
      if (userType === CHAT_USER_TYPES.TEMPORARY) {
        const isReservedInDB = await userOps.isNicknameReserved(nickname);
        const isHardcodedReserved = hardcodedReserved.has(nickname.toLowerCase());
        if (isReservedInDB || isHardcodedReserved) {
          return { available: false, reason: "reserved" };
        }
      }

      return { available: true };
    } catch (error) {
      console.error("Error checking nickname availability:", error);
      return { available: false, reason: "error" };
    }
  }

  function addReservedNickname(nickname: string): void {
    reservedNicknames.add(nickname.toLowerCase());
  }

  function removeReservedNickname(nickname: string): void {
    reservedNicknames.delete(nickname.toLowerCase());
  }

  function getReservedNicknames(): string[] {
    return Array.from(reservedNicknames);
  }

  // Database management methods
  async function createRegisteredUser(
    nickname: string,
    userType: "regular" | "moderator" | "admin",
    email?: string,
    passwordHash?: string,
    token?: string,
    _userId?: string,
  ): Promise<{ success: boolean; error?: string; user?: RegisteredUser }> {
    try {
      // Check if nickname is already taken
      const availability = await isNicknameAvailable(nickname, CHAT_USER_TYPES.REGULAR);
      if (!availability.available) {
        return { success: false, error: `Nickname ${availability.reason}` };
      }

      const user = await userOps.createUser({
        nickname,
        email,
        passwordHash,
        userType,
        isActive: true,
        token,
      });

      return { success: true, user };
    } catch (error) {
      console.log("error", error);
      console.error("Error creating registered user:", error);
      return { success: false, error: "Failed to create user" };
    }
  }

  async function getRegisteredUser(nickname: string): Promise<RegisteredUser | null> {
    try {
      return await userOps.getUserByNickname(nickname);
    } catch (error) {
      console.error("Error getting registered user:", error);
      return null;
    }
  }

  return {
    addUser,
    updateUser,
    updateRegisteredUserById,
    removeUser,
    getUser,
    getChannelUsers,
    getChannelUserCount,
    updateUserActivity,
    isNicknameAvailable,
    addReservedNickname,
    removeReservedNickname,
    getReservedNicknames,
    createRegisteredUser,
    getRegisteredUser,
  };
}

const userManager = createUserManager();

export { createUserManager, type UserType, userManager, CHAT_USER_TYPES };
export type { User };
