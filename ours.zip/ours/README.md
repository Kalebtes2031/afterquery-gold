# OURS

A modern streaming platform application built with a monorepo architecture using TypeScript, React, and Vite.

## Project Structure

This project is organized as an npm workspace with the following packages:

- **`packages/frontend/`** - React frontend application with Vite build system
- **`packages/backend/`** - TypeScript backend services
- **`packages/shared/`** - Shared utilities and types between frontend and backend

## Requirements

- Node.js >= 22 < 23
- npm (included with Node.js)

## Setup and development

Copy the envs:

```shell
cp packages/backend/.env.example packages/backend/.env
cp packages/frontend/.env.example packages/frontend/.env
```

Start the database

```shell
# The standard config
docker compose up
# Or alternate config
docker compose -f docker-compose.local.yml up
```

Install dependencies

```shell
npm install
```

Install Playwright browsers

```shell
npx playwright install chromium
```

Start the frontend and backend development servers

```shell
npm run dev:backend
npm run dev:frontend
```

Build the frontend project

```shell
npm run build
```

Start the backend server in production mode

```shell
npm run start
```

## Branching Strategy

- **`staging`**: Changes for testing should be merged to the staging branch
- **`main`**: The main branch contains the stable release (after testing)

## Testing the UI

Currently in local development the only chat room which is available is `demo`.
You will need to start at this url: <http://localhost:5173/stream/demo>

## Project Architecture

### Monorepo Structure

- `packages/frontend/`: React 19 application with Vite, Tailwind CSS, and Playwright testing
- `packages/backend/`: Express.js backend with AWS IVS Chat integration, SQLite, and Redis
- `packages/shared/`: Shared types and utilities between frontend and backend

### Frontend Architecture / Atomic Design

- **Atoms** (`components/atoms/`): Basic building blocks (Buttons, BodyText, Icons, etc.)
- **Molecules** (`components/molecules/`): Simple component combinations (FormField, ActionBar, etc.)
- **Organisms** (`components/organisms/`): Complex UI sections (Header, Footer, StreamCard, etc.)
- **Templates** (`components/templates/`): Page layout structures
- **Pages** (`components/pages/`): Top-level route components

### Backend Architecture

- **Express.js server** with WebSocket support for real-time features
- **AWS IVS Chat integration** for live streaming chat functionality
- **Hybrid storage**: SQLite for persistence, Redis for real-time state (production) or in-memory storage (development)
- **Real-time reactions system** with persistent counters
- **User management** with temporary nicknames and session handling

## ROOT PACKAGE COMMANDS

- `npm run typecheck`: Check TypeScript types across all workspaces
- `npm run lint`: Lint JS, TS, and CSS files for use locally
- `npm run lint:ci`: Lint JS, TS, and CSS files for use in CI
- `npm run lint:fix`: Format JS, TS, and CSS files
- `npm run build`: Build production frontend bundle
- `npm run e2e`: Run Playwright end-to-end tests
- `npm run e2e:ci`: Run Playwright end-to-end tests in CI
- `npm run dev:frontend`: Start frontend development server
- `npm run dev:backend`: Start backend development server
- `npm run start`: Start backend server with tsx
- `npm run migrate:run`: Run database migrations
- `npm run clean`: Clean up node module dependencies

## Performance Testing

- Use `npm run test:load` for stress testing
- Monitor response times and error rates
- Test with realistic user loads (5-20 concurrent users)

## DEPLOYMENT NOTES

- Frontend builds to static files suitable for CDN deployment
- Backend requires AWS credentials for IVS Chat integration
- Production environments need Redis instance
- Environment-specific configuration via environment variables

## License

Private project - All rights reserved.
