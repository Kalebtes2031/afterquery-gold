# GitHub Actions Workflows

This directory contains CI/CD workflows for automated testing of the OURS PeerTube frontend.

## Available Workflows

### 1. E2E Tests (`e2e-tests.yml`) - **DISABLED**
**Triggers:**
- Manual dispatch only (automatic triggers disabled)

**Status:** Disabled for CI to reduce noise

### 2. Load Tests (`load-tests.yml`) - **DISABLED**
**Triggers:**
- Manual dispatch only (scheduled runs disabled)

**Status:** Disabled for CI to reduce noise

### 3. Streaming Test (`streaming-test.yml`) - **ACTIVE**
**Triggers:**
- Manual dispatch only

**Features:**
- ✅ **Page validation first** - checks if homepage works correctly
- 10-minute continuous streaming test (only if page works)
- Network monitoring and user simulation
- Configurable duration and target URL
- Test summary in GitHub Actions UI
- 20-minute timeout

**Manual Parameters:**
- `target_url`: Custom URL (default: localhost:5173)
- `duration_minutes`: Test duration (default: 10)

**Smart Logic:**
1. First runs homepage test to verify page works
2. Only proceeds with streaming test if page is functional
3. Fails fast if page has issues

## Usage

### Running Tests Manually

1. **E2E Tests**
   - Go to Actions → E2E Tests → Run workflow

2. **Load Tests**
   ```
   Actions → Load Tests → Run workflow
   - Target URL: https://your-app.com
   - Duration: 120 (seconds)
   ```

3. **Streaming Test**
   ```
   Actions → Streaming Test → Run workflow
   - Target URL: https://your-app.com
   - Duration: 15 (minutes)
   ```

### Viewing Results

- **Test Reports**: Available in workflow artifacts
- **Load Test Results**: HTML reports + PR comments
- **Videos/Screenshots**: Uploaded on test failures

## CI Best Practices

- E2E tests run on every PR to catch regressions
- Load tests scheduled weekly to monitor performance
- Streaming tests run manually for specific validation
- All workflows include proper artifact retention
- Timeouts prevent hanging workflows

## Customization

To modify test behavior:
1. Edit workflow files in `.github/workflows/`
2. Update test configurations in `tests/`
3. Adjust timeout values for longer tests
4. Add environment-specific configurations