#!/bin/bash
# Verifier entrypoint (canonical frame). Patching and grading live in
# tests/grader.py; this script owns the task-specific part: run the suites,
# write machine-readable reports under /logs/verifier/, and apply any report
# fixups before grading. Edit ONLY between the RUN TESTS markers.
set -uo pipefail
trap 'if [ ! -f /logs/verifier/reward.json ] && [ ! -f /logs/verifier/reward.txt ]; then mkdir -p /logs/verifier; echo -1 > /logs/verifier/reward.txt; fi' EXIT
log() { echo "[verifier] $*"; }
cd /app || { mkdir -p /logs/verifier; exit 6; }

python3 /tests/grader.py prepare || exit $?
[ -f /logs/verifier/reward.json ] && exit 0   # model.patch didn't apply -> graded 0

# Canonical raw-output log: send every suite's combined stdout+stderr here
# (use run_log, or pipe through tee -a "$RUN_LOG" when feeding a reporter) so
# the reason a test failed is never lost. Never silence a test run.
export RUN_LOG=/logs/verifier/run.log
: > "$RUN_LOG" 2>/dev/null || true
run_log() { echo "+ $*" >> "$RUN_LOG" 2>/dev/null; "$@" 2>&1 | tee -a "$RUN_LOG"; return "${PIPESTATUS[0]}"; }

# >>> RUN TESTS (task-specific) <<<
set +e

rm -f /logs/verifier/base.xml /logs/verifier/new.xml
export CARGO_TERM_COLOR=never

python3 - <<'PYTEST'
import json
import os
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

APP = Path("/app")
CONFIG = Path("/tests/config.json")
RUN_LOG = Path(os.environ.get("RUN_LOG", "/logs/verifier/run.log"))
BASE_XML = Path("/logs/verifier/base.xml")
NEW_XML = Path("/logs/verifier/new.xml")
WORK = Path("/tmp/stencilworks-verifier-work")
CARGO_HOME = Path("/tmp/stencilworks-verifier-cargo-home")
TARGET = Path("/tmp/stencilworks-verifier-target")

cfg = json.loads(CONFIG.read_text())
p2p = [str(x).strip() for x in cfg.get("p2p_node_ids", []) if str(x).strip()]
f2p = [str(x).strip() for x in cfg.get("f2p_node_ids", []) if str(x).strip()]
expected = list(dict.fromkeys(p2p + f2p))

for path in (WORK, CARGO_HOME, TARGET):
    shutil.rmtree(path, ignore_errors=True)
    path.mkdir(parents=True, exist_ok=True)

# Run Cargo away from the repository with a clean CARGO_HOME and target dir.
# Cargo therefore cannot use repository-controlled .cargo runner/wrapper config,
# and no prebuilt test executable from the submission can be reused.
env = os.environ.copy()
env["CARGO_HOME"] = str(CARGO_HOME)
env["CARGO_TARGET_DIR"] = str(TARGET)
env.pop("RUSTC_WRAPPER", None)
env.pop("RUSTC_WORKSPACE_WRAPPER", None)
env.pop("CARGO_BUILD_RUSTC_WRAPPER", None)
for key in list(env):
    if key.startswith("CARGO_TARGET_") and key.endswith("_RUNNER"):
        env.pop(key, None)


def log(text):
    with RUN_LOG.open("a", errors="replace") as fh:
        fh.write(text)
        if text and not text.endswith("\n"):
            fh.write("\n")


def run(cmd, *, cwd, timeout=None):
    log("+ " + " ".join(cmd))
    try:
        proc = subprocess.run(
            cmd,
            cwd=cwd,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            errors="replace",
            timeout=timeout,
        )
        log(proc.stdout or "")
        return proc.returncode, proc.stdout or ""
    except subprocess.TimeoutExpired as exc:
        output = exc.stdout or ""
        if isinstance(output, bytes):
            output = output.decode(errors="replace")
        log(output)
        log(f"TIMEOUT after {timeout}s")
        return 124, output


def write_report(path, ids, results):
    root = ET.Element("testsuites")
    suite = ET.SubElement(root, "testsuite", name="direct-libtest", tests=str(len(ids)))
    failures = 0
    skipped = 0
    for name in ids:
        status, message = results.get(name, ("failed", "test was not discovered"))
        case = ET.SubElement(suite, "testcase", name=name, classname="")
        if status == "failed":
            failures += 1
            node = ET.SubElement(case, "failure", message=message[:500])
            if message:
                node.text = message[-8000:]
        elif status == "skipped":
            skipped += 1
            ET.SubElement(case, "skipped", message=message[:500])
    suite.set("failures", str(failures))
    suite.set("skipped", str(skipped))
    ET.ElementTree(root).write(path, encoding="unicode", xml_declaration=True)


# Compile tests only. We intentionally do not use `cargo test` to execute them:
# Cargo runners are repository-configurable. The resulting libtest executables
# are discovered from Cargo's JSON artifact stream and invoked directly below.
build_cmd = [
    "cargo", "test",
    "--manifest-path", str(APP / "Cargo.toml"),
    "--no-run",
    "--message-format=json",
    "--locked",
    "--offline",
]
rc, build_output = run(build_cmd, cwd=WORK, timeout=600)

executables = []
if rc == 0:
    for line in build_output.splitlines():
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if obj.get("reason") != "compiler-artifact":
            continue
        exe = obj.get("executable")
        profile = obj.get("profile") or {}
        if exe and profile.get("test") is True:
            p = Path(exe)
            if p.is_file() and p not in executables:
                executables.append(p)

# Discover real libtest names from the compiled executables. Also discover
# ignored tests separately so an ignored/silenced configured test cannot count
# as a pass.
locations = {name: [] for name in expected}
ignored = {name: [] for name in expected}


def listed_names(output):
    names = []
    for raw in output.splitlines():
        line = raw.strip()
        if line.endswith(": test"):
            names.append(line[:-6].strip())
    return names


if rc == 0:
    for exe in executables:
        list_rc, list_out = run([str(exe), "--list"], cwd=APP, timeout=60)
        if list_rc != 0:
            continue
        all_names = set(listed_names(list_out))
        ign_rc, ign_out = run([str(exe), "--list", "--ignored"], cwd=APP, timeout=60)
        ignored_names = set(listed_names(ign_out)) if ign_rc == 0 else set()
        for name in expected:
            if name in all_names:
                locations[name].append(exe)
            if name in ignored_names:
                ignored[name].append(exe)

results = {}
for name in expected:
    if ignored[name]:
        results[name] = ("skipped", "configured test is ignored")
        continue
    bins = locations[name]
    if not bins:
        results[name] = ("failed", "test was not discovered in compiled libtest binaries")
        continue
    failures = []
    for exe in bins:
        test_rc, test_out = run(
            [str(exe), "--exact", name, "--no-capture"],
            cwd=APP,
            timeout=120,
        )
        if test_rc != 0:
            failures.append(test_out or f"test process exited with status {test_rc}")
    if failures:
        results[name] = ("failed", "\n".join(failures))
    else:
        results[name] = ("passed", "")

write_report(BASE_XML, p2p, results)
write_report(NEW_XML, f2p, results)
PYTEST

set -e
# >>> END RUN TESTS <<<

# Surface raw suite output into stdout (the harness captures it) so failures
# stay debuggable even when a framework report omits the reason.
_seen=""
for _rl in "$RUN_LOG" /logs/verifier/*_run.log /logs/verifier/*-run.log /logs/verifier/*.log /logs/verifier/*.out; do
  [ -f "$_rl" ] && [ -s "$_rl" ] || continue
  case " $_seen " in *" $_rl "*) continue ;; esac
  case "${_rl##*/}" in *convert*.log|ctrf*.log|junit*.log) continue ;; esac
  _seen="$_seen $_rl"
  echo "===== raw suite output: ${_rl##*/} ====="
  cat "$_rl"
done 2>/dev/null
echo "===== grade ====="

python3 /tests/grader.py grade
log "reward.json=$(cat /logs/verifier/reward.json 2>/dev/null)"

# Uniform top level: keep only the canonical artifacts in /logs/verifier and
# move every framework-native report/log under reports/.
mkdir -p /logs/verifier/reports 2>/dev/null
for _f in /logs/verifier/*; do
  case "${_f##*/}" in
    reward.json|reward.txt|ctrf.json|run.log|test-stdout.txt|reports) continue ;;
  esac
  [ -f "$_f" ] && mv -f "$_f" /logs/verifier/reports/ 2>/dev/null
done
