I'm looking to introduce a small cycling feature into the templates at two places.

To begin with, we should have loop.cycle(...) available, which will return the next value for the iteration, and will loop back to the beginning after reaching the end. When used without any arguments, it should just return an empty string. The cycle should apply to the present loop in case of nesting. There should be an error during rendering upon calling loop.cycle when no for loop is currently present. The current behavior of the other loops should not be impacted.

Next, I would like to have a {% cycle ... %} tag, which should be unnamed when it denotes the active loop, i.e., if there are several cycles mentioned in that loop, they should all move together. It should be a separate cycle for every nesting. A cycle would move only on its rendering.

The first identifier in a cycle tag must only be interpreted as the name when there are no other expressions following it. Otherwise, treat it as a simple value - numbers, normal expressions, and filter expressions all qualify as values. There may be a comma at the end of a tag, but {% cycle %} by itself is invalid. 

Cycle tags have to work correctly inside the if, with, and filter statements and inside block bodies. Skipped sections of code such as inactive branch code, empty loop body code, or code inside raw must not be counted towards the cycle. 

IMPORTANT: Please work on this in a new branch from main and commit everything when you are done.